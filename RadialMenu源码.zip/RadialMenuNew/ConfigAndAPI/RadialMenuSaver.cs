using System;
using System.IO;
using UnityEngine;
using RadialMenu.Logic;

namespace RadialMenu.ConfigAndAPI
{
    /// <summary>
    /// 径向菜单配置保存和加载类 - 使用新的ConfigAndAPI系统
    /// </summary>
    public static class RadialMenuSaver
    {
        private const string CONFIG_FILE_NAME = "radial_menu_config.json";
        
        /// <summary>
        /// 加载配置文件
        /// </summary>
        public static void Load()
        {
            string configPath = GetConfigPath();
            Log.DebugMsg($"加载径向菜单配置文件: {configPath}");
            
            if (File.Exists(configPath))
            {
                try
                {
                    string json = File.ReadAllText(configPath);
                    RadialMenuSettingData data = JsonUtility.FromJson<RadialMenuSettingData>(json);
                    
                    // 检查数据是否有效（不再检查configToken）
                    RadialMenuSetting.LoadData(data);
                    RadialMenuSetting.ClampDependentValues();
                    Log.DebugMsg("径向菜单配置加载成功");
                    return;
                }
                catch (Exception ex)
                {
                    Log.Warn($"加载径向菜单配置文件失败: {ex.Message}");
                }
            }
            else
            {
                Log.DebugMsg("径向菜单配置文件不存在，使用默认配置");
            }
            
            // 使用默认设置
            SetDefaultValues();
            
            // 创建默认配置文件
            CreateConfigFile();
        }
        
        /// <summary>
        /// 保存配置文件
        /// </summary>
        public static void Save()
        {
            CreateConfigFile();
        }
        
        /// <summary>
        /// 创建配置文件
        /// </summary>
        private static void CreateConfigFile()
        {
            try
            {
                string configPath = GetConfigPath();
                Log.DebugMsg($"创建径向菜单配置文件: {configPath}");
                
                string directory = Path.GetDirectoryName(configPath);
                if (directory == null)
                {
                    Log.Error("配置文件目录不能为null");
                    return;
                }
                
                if (!Directory.Exists(directory))
                    Directory.CreateDirectory(directory);
                
                string json = JsonUtility.ToJson(RadialMenuSetting.GetData(), true);
                File.WriteAllText(configPath, json);
                
                Log.DebugMsg($"径向菜单配置文件创建完成");
            }
            catch (Exception ex)
            {
                Log.Warn($"创建径向菜单配置文件失败: {ex.Message}");
            }
        }
        
        /// <summary>
        /// 获取配置文件路径
        /// </summary>
        private static string GetConfigPath()
        {
            // 使用固定的配置文件名，不再基于configToken
            return Path.Combine(Application.streamingAssetsPath, CONFIG_FILE_NAME);
        }
        
        /// <summary>
        /// 设置默认值
        /// </summary>
        private static void SetDefaultValues()
        {
            RadialMenuSetting.FoodBindSectors = 0; // 修复默认值，从5改为0
            RadialMenuSetting.IgnoreDurabilityValue = 15f;
            RadialMenuSetting.ShowLowValueFood = true;
            RadialMenuSetting.SectorCount = 6;
            RadialMenuSetting.IconSize = 90f;
            RadialMenuSetting.InnerDeadZoneCoefficient = 0.26f;
            RadialMenuSetting.OuterDeadZoneCoefficient = 2.7f;
            RadialMenuSetting.IconDistanceFactor = 71f;
            RadialMenuSetting.UiScalePercent = 0.38f;
            RadialMenuSetting.UI6style = "A";
            RadialMenuSetting.UI8style = "A";
            RadialMenuSetting.ShowIconCount = true;
            RadialMenuSetting.QuickUseLastItemQ = true;
            RadialMenuSetting.LongPressQWaitDuration = 0.25f;
            RadialMenuSetting.IsBulletTimeEnabled = true;
            RadialMenuSetting.BulletTimeMultiplier = 0.2f;
            // ConfigToken 已移除，不再设置
        }
        
        /// <summary>
        /// 尝试从本地文件加载配置（如果存在），并返回是否成功
        /// </summary>
        public static bool TryLoadConfigFromLocal()
        {
            try
            {
                string configPath = GetConfigPath();
                if (!File.Exists(configPath))
                    return false;

                string json = File.ReadAllText(configPath);
                var loaded = JsonUtility.FromJson<RadialMenuSettingData>(json);
                // 不再检查configToken
                RadialMenuSetting.LoadData(loaded);
                RadialMenuSetting.ClampDependentValues();
                Log.DebugMsg("径向菜单配置: 从本地文件加载成功");
                return true;
            }
            catch (Exception e)
            {
                Log.Warn($"径向菜单配置: 从本地文件加载失败: {e.Message}");
                return false;
            }
        }
        
        /// <summary>
        /// 将当前配置以 json 保存到 streamingAssets（用于持久化与调试）
        /// </summary>
        public static void SaveConfigToLocal()
        {
            try
            {
                string configPath = GetConfigPath();
                string json = JsonUtility.ToJson(RadialMenuSetting.GetData(), true);

                // 确保目录存在（StreamingAssets 在某些平台可能只读，但在编辑器/大多数桌面 dev 环境下可写）
                var dir = Path.GetDirectoryName(configPath);
                if (!Directory.Exists(dir))
                    Directory.CreateDirectory(dir);

                File.WriteAllText(configPath, json);
                Log.DebugMsg($"径向菜单配置: 已保存到 {configPath}");
            }
            catch (Exception e)
            {
                Log.Warn($"径向菜单配置: 保存到本地失败: {e.Message}");
            }
        }
    }
}