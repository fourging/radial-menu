using System;
using System.Collections.Generic;
using UnityEngine;
using Duckov.Modding;
using RadialMenu.Logic;
using RadialMenu.Patches;

namespace RadialMenu.ConfigAndAPI
{
    /// <summary>
    /// 径向菜单配置菜单类 - 使用新的ConfigAndAPI系统
    /// 替代旧的ModConfigMenu实现
    /// </summary>
    public static class RadialMenuModConfig
    {
        // 注册时请传入你的 mod 名称（ModBehaviour 中定义的名称）
        private static string _modName = "环形菜单RadialMenu";
        
        // 是否已注册到 ModSetting（防止重复注册）
        private static bool _isSetup = false;
        
        // ModInfo实例，用于ModSetting API
        private static ModInfo _modInfo;

        /// <summary>
        /// 注册 ModSetting 菜单项（由外部 ModBehaviour 在合适时机调用）
        /// </summary>
        public static void SetupModConfig(ModInfo modInfo, string modName = "RadialMenu")
        {
            if (_isSetup)
            {
                Log.DebugMsg($"RadialMenuModConfig: already setup for {_modName}");
                return;
            }

            _modName = string.IsNullOrEmpty(modName) ? "RadialMenu" : modName;
            _modInfo = modInfo;

            // 如果 ModSetting 不可用，也不要崩溃（调用方负责在 ModSetting 可用时调用此函数）
            if (!ModSetting.Init(_modInfo))
            {
                Log.Warn($"RadialMenuModConfig: ModSetting is not available yet for {_modName}. Call SetupModConfig again when available.");
                return;
            }

            Log.DebugMsg($"RadialMenuModConfig: Setting up ModSetting for {_modName}");

            // 初始化背景纹理管理器
            BackgroundTextureManager.Initialize();

            // 添加配置项
            AddUIItems();

            // 从ModSetting加载当前值（如果ModSetting中已有设置）
            LoadConfigFromModSetting();

            // 将当前配置写入本地文件（确保持久化与调试）
            RadialMenuSaver.SaveConfigToLocal();

            _isSetup = true;
            Log.DebugMsg("RadialMenuModConfig: setup completed");
        }

        /// <summary>
        /// 撤销监听（供 ModBehaviour 在 OnDisable/OnDestroy 时调用）
        /// </summary>
        public static void TeardownModConfig()
        {
            if (!_isSetup)
                return;

            // 移除ModSetting中的UI
            ModSetting.RemoveMod();
            
            // 清除事件监听
            RadialMenuSetting.Clear();

            _isSetup = false;
            Log.DebugMsg("RadialMenuModConfig: torn down");
        }

        /// <summary>
        /// 添加UI项到ModSetting
        /// </summary>
        private static void AddUIItems()
        {
            // 1. 扇区数量
            var sectorOptions = new List<string> { "6", "8" };
            ModSetting.AddDropdownList(
                "sectorCount",
                LocalizationHelper.Get("Config_sectorCount"),
                sectorOptions,
                RadialMenuSetting.SectorCount.ToString(),
                value => {
                    int sectorCount = int.Parse(value);
                    RadialMenuSetting.SectorCount = sectorCount;
                    RadialMenuSaver.SaveConfigToLocal();
                }
            );

            // 2. 呼出圆盘使用的按键
            ModSetting.AddKeybinding(
                "radialMenuActivationKey",
                LocalizationHelper.Get("Config_radialMenuActivationKey"),
                RadialMenuSetting.RadialMenuActivationKey,
                value => {
                    RadialMenuSetting.RadialMenuActivationKey = value;
                    RadialMenuSaver.SaveConfigToLocal();
                }
            );

            // 3. 呼出圆盘长按时间
            ModSetting.AddSlider(
                "longPressQWaitDuration",
                LocalizationHelper.Get("Config_longPressQWaitDuration"),
                RadialMenuSetting.LongPressQWaitDuration,
                new Vector2(0.05f, 1f),
                value => {
                    RadialMenuSetting.LongPressQWaitDuration = value;
                    RadialMenuSaver.SaveConfigToLocal();
                }
            );

            // 4. 6扇区UI方案
            var UI6style = GenerateUIStyleOptions(6);
            ModSetting.AddDropdownList(
                "UI6style",
                LocalizationHelper.Get("Config_UI6style"),
                UI6style,
                RadialMenuSetting.UI6style,
                value => {
                    RadialMenuSetting.UI6style = value;
                    RadialMenuSaver.SaveConfigToLocal();
                }
            );

            // 5. 8扇区UI方案
            var UI8style = GenerateUIStyleOptions(8);
            ModSetting.AddDropdownList(
                "UI8style",
                LocalizationHelper.Get("Config_UI8style"),
                UI8style,
                RadialMenuSetting.UI8style,
                value => {
                    RadialMenuSetting.UI8style = value;
                    RadialMenuSaver.SaveConfigToLocal();
                }
            );

            // 6. 是否开启子弹时间
            ModSetting.AddToggle(
                "isBulletTimeEnabled",
                LocalizationHelper.Get("Config_isBulletTimeEnabled"),
                RadialMenuSetting.IsBulletTimeEnabled,
                value => {
                    RadialMenuSetting.IsBulletTimeEnabled = value;
                    RadialMenuSaver.SaveConfigToLocal();
                }
            );
            
            // 7. 子弹时间游戏速度倍率
            ModSetting.AddSlider(
                "bulletTimeMultiplier",
                LocalizationHelper.Get("Config_bulletTimeMultiplier"),
                RadialMenuSetting.BulletTimeMultiplier,
                new Vector2(0.1f, 0.8f),
                value => {
                    RadialMenuSetting.BulletTimeMultiplier = value;
                    RadialMenuSaver.SaveConfigToLocal();
                }
            );

            // 8. 自动绑定食物的扇区编号
            // FoodBindSectors: 可选值 1 .. 8（显示给玩家）
            // 使用下拉菜单而不是滑块，确保值为整数
            Log.DebugMsg($"AddUIItems: 初始化FoodBindSectors配置项，当前扇区数量: {RadialMenuSetting.SectorCount}");
            var foodBindOptions = GenerateFoodBindSectorOptions(RadialMenuSetting.SectorCount);
            Log.DebugMsg($"AddUIItems: 生成的选项数量: {foodBindOptions.Count}, 选项内容: [{string.Join(", ", foodBindOptions)}]");
            // 将存储的索引值转换为显示值（0-7转换为1-8）
            string displayValue = (RadialMenuSetting.FoodBindSectors + 1).ToString();
            Log.DebugMsg($"AddUIItems: 当前FoodBindSectors存储值为 {RadialMenuSetting.FoodBindSectors}，显示值为 {displayValue}");
            
            bool addResult = ModSetting.AddDropdownList(
                "FoodBindSectors",
                LocalizationHelper.Get("Config_FoodBindSectors"),
                foodBindOptions,
                displayValue,
                OnFoodBindSectorsChanged
            );
            
            Log.DebugMsg($"AddUIItems: FoodBindSectors配置项添加结果: {addResult}");

            // 9. 内圈死区系数
            ModSetting.AddSlider(
                "innerDeadZoneCoefficient",
                LocalizationHelper.Get("Config_innerDeadZoneCoefficient"),
                RadialMenuSetting.InnerDeadZoneCoefficient,
                new Vector2(0.1f, 0.4f),
                value => {
                    RadialMenuSetting.InnerDeadZoneCoefficient = value;
                    RadialMenuSaver.SaveConfigToLocal();
                }
            );

            // 10. 外圈死区系数
            ModSetting.AddSlider(
                "outerDeadZoneCoefficient",
                LocalizationHelper.Get("Config_outerDeadZoneCoefficient"),
                RadialMenuSetting.OuterDeadZoneCoefficient,
                new Vector2(1.5f, 3.5f),
                value => {
                    RadialMenuSetting.OuterDeadZoneCoefficient = value;
                    RadialMenuSaver.SaveConfigToLocal();
                }
            );

            // 11. 背景UI缩放百分比
            ModSetting.AddSlider(
                "uiScalePercent",
                LocalizationHelper.Get("Config_uiScalePercent"),
                RadialMenuSetting.UiScalePercent,
                new Vector2(0.1f, 0.5f),
                value => {
                    RadialMenuSetting.UiScalePercent = value;
                    RadialMenuSaver.SaveConfigToLocal();
                }
            );

            // 12. 图标尺寸
            ModSetting.AddSlider(
                "iconSize",
                LocalizationHelper.Get("Config_iconSize"),
                RadialMenuSetting.IconSize,
                new Vector2(40f, 160f),
                value => {
                    RadialMenuSetting.IconSize = value;
                    RadialMenuSaver.SaveConfigToLocal();
                }
            );

            // 13. 图标距离圆心的比例
            ModSetting.AddSlider(
                "iconDistanceFactor",
                LocalizationHelper.Get("Config_iconDistanceFactor"),
                RadialMenuSetting.IconDistanceFactor,
                new Vector2(30f, 120f),
                value => {
                    RadialMenuSetting.IconDistanceFactor = value;
                    RadialMenuSaver.SaveConfigToLocal();
                }
            );

            // 14. 是否开启短按触发快速使用上次物品功能
            ModSetting.AddToggle(
                "quickUseLastItemQ",
                LocalizationHelper.Get("Config_quickUseLastItemQ"),
                RadialMenuSetting.QuickUseLastItemQ,
                value => {
                    RadialMenuSetting.QuickUseLastItemQ = value;
                    RadialMenuSaver.SaveConfigToLocal();
                }
            );

            // 15. 提示提价值物品是否包含食物
            ModSetting.AddToggle(
                "showLowValueFood",
                LocalizationHelper.Get("Config_showLowValueFood"),
                RadialMenuSetting.ShowLowValueFood,
                value => {
                    RadialMenuSetting.ShowLowValueFood = value;
                    RadialMenuSaver.SaveConfigToLocal();
                }
            );

            // 16. 低于多少耐久的急救箱自动略过使用
            ModSetting.AddSlider(
                "ignoreDurabilityValue",
                LocalizationHelper.Get("Config_ignoreDurabilityValue"),
                RadialMenuSetting.IgnoreDurabilityValue,
                new Vector2(0f, 30f),
                value => {
                    RadialMenuSetting.IgnoreDurabilityValue = value;
                    RadialMenuSaver.SaveConfigToLocal();
                }
            );

            // 添加配置变更监听
            RadialMenuSetting.OnSectorCountChanged += OnSectorCountChanged;
            RadialMenuSetting.OnBulletTimeMultiplierChanged += OnBulletTimeMultiplierChanged;
            RadialMenuSetting.OnIsBulletTimeEnabledChanged += OnIsBulletTimeEnabledChanged;
            RadialMenuSetting.OnIconDistanceFactorChanged += OnIconDistanceFactorChanged;
            RadialMenuSetting.OnRadialMenuActivationKeyChanged += OnRadialMenuActivationKeyChanged;
        }

        /// <summary>
        /// 从 ModSetting API 安全读取所有项到 RadialMenuSetting 中
        /// </summary>
        public static void LoadConfigFromModSetting()
        {
            if (!ModSetting.IsInit)
                return;

            // 从ModSetting加载所有配置项
            ModSetting.GetValue<string>("FoodBindSectors", value => {
                if (int.TryParse(value, out int displayValue))
                {
                    // 将显示值（1-8）转换为索引值（0-7）存储
                    RadialMenuSetting.FoodBindSectors = ConvertDisplaySectorToIndex(displayValue);
                }
            });

            ModSetting.GetValue<float>("ignoreDurabilityValue", value => {
                RadialMenuSetting.IgnoreDurabilityValue = value;
            });

            ModSetting.GetValue<bool>("showLowValueFood", value => {
                RadialMenuSetting.ShowLowValueFood = value;
            });

            ModSetting.GetValue<bool>("quickUseLastItemQ", value => {
                RadialMenuSetting.QuickUseLastItemQ = value;
            });

            ModSetting.GetValue<string>("sectorCount", value => {
                if (int.TryParse(value, out int sectorCount))
                {
                    RadialMenuSetting.SectorCount = sectorCount;
                }
            });

            ModSetting.GetValue<float>("iconSize", value => {
                RadialMenuSetting.IconSize = value;
            });

            ModSetting.GetValue<float>("iconDistanceFactor", value => {
                RadialMenuSetting.IconDistanceFactor = value;
            });

            ModSetting.GetValue<float>("innerDeadZoneCoefficient", value => {
                RadialMenuSetting.InnerDeadZoneCoefficient = value;
            });

            ModSetting.GetValue<float>("outerDeadZoneCoefficient", value => {
                RadialMenuSetting.OuterDeadZoneCoefficient = value;
            });

            ModSetting.GetValue<float>("uiScalePercent", value => {
                RadialMenuSetting.UiScalePercent = value;
            });

            ModSetting.GetValue<bool>("isBulletTimeEnabled", value => {
                RadialMenuSetting.IsBulletTimeEnabled = value;
            });

            ModSetting.GetValue<float>("bulletTimeMultiplier", value => {
                RadialMenuSetting.BulletTimeMultiplier = value;
            });

            ModSetting.GetValue<string>("UI8style", value => {
                RadialMenuSetting.UI8style = value;
            });

            ModSetting.GetValue<string>("UI6style", value => {
                RadialMenuSetting.UI6style = value;
            });

            ModSetting.GetValue<KeyCode>("radialMenuActivationKey", value => {
                RadialMenuSetting.RadialMenuActivationKey = value;
            });

            // 移除configToken参数，不再使用

            // 任何依赖关系或非法值修正
            RadialMenuSetting.ClampDependentValues();

            Log.DebugMsg("RadialMenuModConfig: loaded config from ModSetting API");
        }

        /// <summary>
        /// 根据检测到的背景套装动态生成UI样式选项
        /// </summary>
        /// <param name="sectorCount">扇区数量</param>
        /// <returns>UI样式选项列表</returns>
        private static List<string> GenerateUIStyleOptions(int sectorCount)
        {
            var options = new List<string>();
            
            try
            {
                // 获取可用的背景套装
                var availableStyles = BackgroundTextureManager.GetAvailableStyles(sectorCount);
                
                if (availableStyles.Count == 0)
                {
                    // 如果没有检测到任何套装，添加默认选项
                    options.Add("A");
                    Log.Warn($"RadialMenuModConfig: 为{sectorCount}扇区未检测到样式，使用默认样式");
                }
                else
                {
                    // 为每个检测到的套装创建选项
                    foreach (var style in availableStyles)
                    {
                        options.Add(style);
                    }
                    
                    Log.DebugMsg($"RadialMenuModConfig: 为{sectorCount}扇区生成了{availableStyles.Count}个UI样式选项: {string.Join(", ", availableStyles)}");
                }
            }
            catch (Exception ex)
            {
                Log.Error($"RadialMenuModConfig: 生成{sectorCount}扇区UI样式选项失败", ex);
                
                // 出错时添加默认选项
                options.Add("A");
            }
            
            return options;
        }

        /// <summary>
        /// 生成食物绑定扇区选项列表
        /// </summary>
        /// <param name="sectorCount">扇区数量（此参数保留以兼容现有调用，但不再使用）</param>
        /// <returns>扇区选项列表（固定为1-8）</returns>
        private static List<string> GenerateFoodBindSectorOptions(int sectorCount)
        {
            var options = new List<string>();
            
            // 固定生成1到8的选项（显示给玩家的扇区编号）
            for (int i = 1; i <= 8; i++)
            {
                options.Add(i.ToString());
            }
            
            return options;
        }

        /// <summary>
        /// 将显示的扇区编号（1-8）转换为实际的数组索引（0-7）
        /// </summary>
        /// <param name="displaySector">显示给玩家的扇区编号（1-8）</param>
        /// <returns>实际的数组索引（0-7）</returns>
        private static int ConvertDisplaySectorToIndex(int displaySector)
        {
            // 将1-8转换为0-7
            return Mathf.Max(0, displaySector - 1);
        }

        /// <summary>
        /// 根据当前扇区数量和用户设置，获取实际应该使用的扇区索引
        /// </summary>
        /// <param name="userSelectedSector">用户选择的扇区编号（1-8）</param>
        /// <param name="currentSectorCount">当前扇区数量（6或8）</param>
        /// <returns>实际应该使用的扇区索引（0-5或0-7）</returns>
        private static int GetActualFoodBindSectorIndex(int userSelectedSector, int currentSectorCount)
        {
            // 先将用户选择的扇区编号转换为索引
            int sectorIndex = ConvertDisplaySectorToIndex(userSelectedSector);
            
            // 检查索引是否在当前扇区数量范围内
            if (sectorIndex >= currentSectorCount)
            {
                // 如果超出了范围，则使用0号扇区（即显示的1号扇区）
                Log.DebugMsg($"用户选择的扇区{userSelectedSector}（索引{sectorIndex}）超出了当前扇区数量{currentSectorCount}，回退到1号扇区");
                return 0;
            }
            
            return sectorIndex;
        }

        /// <summary>
        /// 食物绑定扇区变更事件处理
        /// </summary>
        private static void OnFoodBindSectorsChanged(string value)
        {
            Log.DebugMsg($"OnFoodBindSectorsChanged: FoodBindSectors值变更为 {value}");
            // 将显示值（1-8）转换为索引值（0-7）存储
            int displaySector = int.Parse(value);
            RadialMenuSetting.FoodBindSectors = ConvertDisplaySectorToIndex(displaySector);
            RadialMenuSaver.SaveConfigToLocal();
        }

        /// <summary>
        /// 扇区数量变更事件处理
        /// </summary>
        private static void OnSectorCountChanged(int value)
        {
            Log.DebugMsg($"OnSectorCountChanged: 扇区数量变更为 {value}，当前FoodBindSectors值为 {RadialMenuSetting.FoodBindSectors}");
            
            // 当扇区数量改变时，需要更新FoodBindSectors的选项
            // 先移除旧的FoodBindSectors配置项
            bool removeResult = ModSetting.RemoveUI("FoodBindSectors");
            Log.DebugMsg($"OnSectorCountChanged: 移除FoodBindSectors配置项结果: {removeResult}");
            
            // 重新添加FoodBindSectors配置项，使用新的选项
            var foodBindOptions = GenerateFoodBindSectorOptions(value);
            // 将存储的索引值转换为显示值（0-7转换为1-8）
            string displayValue = (RadialMenuSetting.FoodBindSectors + 1).ToString();
            Log.DebugMsg($"OnSectorCountChanged: 重新添加FoodBindSectors配置项，显示值为 {displayValue}");
            
            bool addResult = ModSetting.AddDropdownList(
                "FoodBindSectors",
                LocalizationHelper.Get("Config_FoodBindSectors"),
                foodBindOptions,
                displayValue,
                OnFoodBindSectorsChanged
            );
            
            Log.DebugMsg($"OnSectorCountChanged: 添加FoodBindSectors配置项结果: {addResult}");
        }

        /// <summary>
        /// 子弹时间倍率变更事件处理
        /// </summary>
        private static void OnBulletTimeMultiplierChanged(float value)
        {
            // 如果子弹时间配置发生变化，且当前圆盘菜单未激活，则更新子弹时间设置
            try
            {
                // 如果当前没有激活圆盘菜单，但子弹时间处于激活状态，则禁用它
                if (!BulletTimeManager.IsBulletTimeActive)
                {
                    Log.DebugMsg($"子弹时间倍率已更新: {value}");
                }
                else
                {
                    Log.DebugMsg($"子弹时间倍率已更新，但当前圆盘菜单激活中，配置将在下次生效: {value}");
                }
            }
            catch (Exception ex)
            {
                Log.Error("处理子弹时间倍率变更时发生异常", ex);
            }
        }

        /// <summary>
        /// 子弹时间启用状态变更事件处理
        /// </summary>
        private static void OnIsBulletTimeEnabledChanged(bool value)
        {
            // 如果子弹时间配置发生变化，且当前圆盘菜单未激活，则更新子弹时间设置
            try
            {
                // 如果当前没有激活圆盘菜单，但子弹时间处于激活状态，则禁用它
                if (!BulletTimeManager.IsBulletTimeActive)
                {
                    Log.DebugMsg($"子弹时间启用状态已更新: {value}");
                }
                else
                {
                    Log.DebugMsg($"子弹时间启用状态已更新，但当前圆盘菜单激活中，配置将在下次生效: {value}");
                }
            }
            catch (Exception ex)
            {
                Log.Error("处理子弹时间启用状态变更时发生异常", ex);
            }
        }

        /// <summary>
        /// 图标距离因子变更事件处理
        /// </summary>
        private static void OnIconDistanceFactorChanged(float value)
        {
            Log.DebugMsg($"图标距离因子配置已更新: {value}");
        }

        /// <summary>
        /// 呼出圆盘按键变更事件处理
        /// </summary>
        private static void OnRadialMenuActivationKeyChanged(KeyCode value)
        {
            Log.DebugMsg($"呼出圆盘按键已更新: {value}");
        }
    }
}