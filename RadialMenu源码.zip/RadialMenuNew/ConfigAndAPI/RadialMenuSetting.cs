using System;
using UnityEngine;

namespace RadialMenu.ConfigAndAPI
{
    /// <summary>
    /// 径向菜单配置参数类 - 使用新的ConfigAndAPI系统
    /// </summary>
    public static class RadialMenuSetting
    {
        // 自动绑定食物的扇区编号
        // 下拉菜单选择，范围为0到sectorCount-1
        private static int _foodBindSectors = 0;
        public static int FoodBindSectors 
        { 
            get => _foodBindSectors; 
            set 
            { 
                _foodBindSectors = value;
                OnFoodBindSectorsChanged?.Invoke(value);
            }
        }
        public static event Action<int> OnFoodBindSectorsChanged;

        // 低于多少耐久的医疗包自动略过
        // 滑块输入，范围0-30
        private static float _ignoreDurabilityValue = 15f;
        public static float IgnoreDurabilityValue 
        { 
            get => _ignoreDurabilityValue; 
            set 
            { 
                _ignoreDurabilityValue = value;
                OnIgnoreDurabilityValueChanged?.Invoke(value);
            }
        }
        public static event Action<float> OnIgnoreDurabilityValueChanged;

        // 是否显示物品价值
        private static bool _showLowValueFood = true;
        public static bool ShowLowValueFood 
        { 
            get => _showLowValueFood; 
            set 
            { 
                _showLowValueFood = value;
                OnShowLowValueFoodChanged?.Invoke(value);
            }
        }
        public static event Action<bool> OnShowLowValueFoodChanged;

        // 扇区数量（圆盘分为多少个可选区域）
        // 下拉菜单选择6或者8
        private static int _sectorCount = 6;
        public static int SectorCount 
        { 
            get => _sectorCount; 
            set 
            { 
                _sectorCount = value;
                OnSectorCountChanged?.Invoke(value);
            }
        }
        public static event Action<int> OnSectorCountChanged;

        // 图标尺寸大小
        private static float _iconSize = 90f;
        public static float IconSize 
        { 
            get => _iconSize; 
            set 
            { 
                _iconSize = value;
                OnIconSizeChanged?.Invoke(value);
            }
        }
        public static event Action<float> OnIconSizeChanged;

        // 内圈死区大小
        // 范围0.1到0.4
        private static float _innerDeadZoneCoefficient = 0.26f;
        public static float InnerDeadZoneCoefficient 
        { 
            get => _innerDeadZoneCoefficient; 
            set 
            { 
                _innerDeadZoneCoefficient = value;
                OnInnerDeadZoneCoefficientChanged?.Invoke(value);
            }
        }
        public static event Action<float> OnInnerDeadZoneCoefficientChanged;

        // 外圈死区大小
        // 范围1.5到3.5
        // 滑块输入
        private static float _outerDeadZoneCoefficient = 2.7f;
        public static float OuterDeadZoneCoefficient 
        { 
            get => _outerDeadZoneCoefficient; 
            set 
            { 
                _outerDeadZoneCoefficient = value;
                OnOuterDeadZoneCoefficientChanged?.Invoke(value);
            }
        }
        public static event Action<float> OnOuterDeadZoneCoefficientChanged;

        // 控制图标距离圆心的比例（用于确定图标在扇区中的位置）
        // 范围30到120（实际使用时会缩小100倍）
        private static float _iconDistanceFactor = 71f;
        public static float IconDistanceFactor 
        { 
            get => _iconDistanceFactor; 
            set 
            { 
                _iconDistanceFactor = value;
                OnIconDistanceFactorChanged?.Invoke(value);
            }
        }
        public static event Action<float> OnIconDistanceFactorChanged;

        // 背景缩放倍率
        // 范围0.1到0.7
        private static float _uiScalePercent = 0.38f;
        public static float UiScalePercent 
        { 
            get => _uiScalePercent; 
            set 
            { 
                _uiScalePercent = value;
                OnUiScalePercentChanged?.Invoke(value);
            }
        }
        public static event Action<float> OnUiScalePercentChanged;

        // 背景UI方案 - 六扇区下拉菜单选择
        private static string _ui6style = "A";
        public static string UI6style 
        { 
            get => _ui6style; 
            set 
            { 
                _ui6style = value;
                OnUI6styleChanged?.Invoke(value);
            }
        }
        public static event Action<string> OnUI6styleChanged;

        // 背景UI方案 - 八扇区下拉菜单选择
        private static string _ui8style = "A";
        public static string UI8style 
        { 
            get => _ui8style; 
            set 
            { 
                _ui8style = value;
                OnUI8styleChanged?.Invoke(value);
            }
        }
        public static event Action<string> OnUI8styleChanged;

        // 是否在图标上显示堆叠数量（true 显示，false 隐藏）
        private static bool _showIconCount = true;
        public static bool ShowIconCount 
        { 
            get => _showIconCount; 
            set 
            { 
                _showIconCount = value;
                OnShowIconCountChanged?.Invoke(value);
            }
        }
        public static event Action<bool> OnShowIconCountChanged;

        // 是否开启短按Q触发快速使用上次物品功能
        private static bool _quickUseLastItemQ = true;
        public static bool QuickUseLastItemQ 
        { 
            get => _quickUseLastItemQ; 
            set 
            { 
                _quickUseLastItemQ = value;
                OnQuickUseLastItemQChanged?.Invoke(value);
            }
        }
        public static event Action<bool> OnQuickUseLastItemQChanged;

        // 长按Q呼出圆盘前的等待时长
        private static float _longPressQWaitDuration = 0.25f;
        public static float LongPressQWaitDuration 
        { 
            get => _longPressQWaitDuration; 
            set 
            { 
                _longPressQWaitDuration = value;
                OnLongPressQWaitDurationChanged?.Invoke(value);
            }
        }
        public static event Action<float> OnLongPressQWaitDurationChanged;

        // 是否开启子弹时间
        private static bool _isBulletTimeEnabled = true;
        public static bool IsBulletTimeEnabled 
        { 
            get => _isBulletTimeEnabled; 
            set 
            { 
                _isBulletTimeEnabled = value;
                OnIsBulletTimeEnabledChanged?.Invoke(value);
            }
        }
        public static event Action<bool> OnIsBulletTimeEnabledChanged;

        // 子弹时间倍率
        private static float _bulletTimeMultiplier = 0.2f;
        public static float BulletTimeMultiplier 
        { 
            get => _bulletTimeMultiplier; 
            set 
            { 
                _bulletTimeMultiplier = value;
                OnBulletTimeMultiplierChanged?.Invoke(value);
            }
        }
        public static event Action<float> OnBulletTimeMultiplierChanged;

        // 呼出圆盘使用的按键
        private static KeyCode _radialMenuActivationKey = KeyCode.Q;
        public static KeyCode RadialMenuActivationKey
        {
            get => _radialMenuActivationKey;
            set
            {
                _radialMenuActivationKey = value;
                OnRadialMenuActivationKeyChanged?.Invoke(value);
            }
        }
        public static event Action<KeyCode> OnRadialMenuActivationKeyChanged;

        // ConfigToken 已移除，不再使用

        /// <summary>
        /// 获取所有配置数据，用于保存
        /// </summary>
        public static RadialMenuSettingData GetData()
        {
            return new RadialMenuSettingData(
                FoodBindSectors,
                IgnoreDurabilityValue,
                ShowLowValueFood,
                SectorCount,
                IconSize,
                InnerDeadZoneCoefficient,
                OuterDeadZoneCoefficient,
                IconDistanceFactor,
                UiScalePercent,
                UI6style,
                UI8style,
                ShowIconCount,
                QuickUseLastItemQ,
                LongPressQWaitDuration,
                IsBulletTimeEnabled,
                BulletTimeMultiplier,
                RadialMenuActivationKey,
                "" // ConfigToken 已移除，传入空字符串
            );
        }

        /// <summary>
        /// 从数据对象加载配置
        /// </summary>
        public static void LoadData(RadialMenuSettingData data)
        {
            FoodBindSectors = data.foodBindSectors;
            IgnoreDurabilityValue = data.ignoreDurabilityValue;
            ShowLowValueFood = data.showLowValueFood;
            SectorCount = data.sectorCount;
            IconSize = data.iconSize;
            InnerDeadZoneCoefficient = data.innerDeadZoneCoefficient;
            OuterDeadZoneCoefficient = data.outerDeadZoneCoefficient;
            IconDistanceFactor = data.iconDistanceFactor;
            UiScalePercent = data.uiScalePercent;
            UI6style = data.ui6style;
            UI8style = data.ui8style;
            ShowIconCount = data.showIconCount;
            QuickUseLastItemQ = data.quickUseLastItemQ;
            LongPressQWaitDuration = data.longPressQWaitDuration;
            IsBulletTimeEnabled = data.isBulletTimeEnabled;
            BulletTimeMultiplier = data.bulletTimeMultiplier;
            RadialMenuActivationKey = data.radialMenuActivationKey;
            // ConfigToken 已移除，不再加载
        }

        /// <summary>
        /// 清除所有事件监听器
        /// </summary>
        public static void Clear()
        {
            OnFoodBindSectorsChanged = null;
            OnIgnoreDurabilityValueChanged = null;
            OnShowLowValueFoodChanged = null;
            OnSectorCountChanged = null;
            OnIconSizeChanged = null;
            OnInnerDeadZoneCoefficientChanged = null;
            OnOuterDeadZoneCoefficientChanged = null;
            OnIconDistanceFactorChanged = null;
            OnUiScalePercentChanged = null;
            OnUI6styleChanged = null;
            OnUI8styleChanged = null;
            OnShowIconCountChanged = null;
            OnQuickUseLastItemQChanged = null;
            OnLongPressQWaitDurationChanged = null;
            OnIsBulletTimeEnabledChanged = null;
            OnBulletTimeMultiplierChanged = null;
            OnRadialMenuActivationKeyChanged = null;
            // OnConfigTokenChanged 已移除
        }

        /// <summary>
        /// 修正基于 sectorCount 的依赖值等
        /// </summary>
        public static void ClampDependentValues()
        {
            // sectorCount 合法性
            if (SectorCount != 6 && SectorCount != 8)
            {
                Debug.LogWarning($"RadialMenuSetting: illegal sectorCount {SectorCount}, fallback to 6");
                SectorCount = 6;
            }

            // FoodBindSectors 必须在 0 .. sectorCount-1
            int maxSectorIndex = Mathf.Max(0, SectorCount - 1);
            if (FoodBindSectors < 0) FoodBindSectors = 0;
            if (FoodBindSectors > maxSectorIndex) FoodBindSectors = maxSectorIndex;

            // ignoreDurabilityValue 0-30
            IgnoreDurabilityValue = Mathf.Clamp(IgnoreDurabilityValue, 0f, 30f);

            // iconSize 16-128
            IconSize = Mathf.Clamp(IconSize, 20, 300);

            // iconDistanceFactor 30-120 (确保图标距离因子在合理范围内，实际使用时会缩小100倍)
            IconDistanceFactor = Mathf.Clamp(IconDistanceFactor, 30f, 120f);

            // innerDeadZoneCoefficient 0.1-0.4
            InnerDeadZoneCoefficient = Mathf.Clamp(InnerDeadZoneCoefficient, 0.1f, 0.4f);

            // outerDeadZoneCoefficient 1.5-3.5
            OuterDeadZoneCoefficient = Mathf.Clamp(OuterDeadZoneCoefficient, 1.5f, 3.5f);
            
            // bulletTimeMultiplier 0.1-0.8 (确保子弹时间倍率在合理范围内)
            BulletTimeMultiplier = Mathf.Clamp(BulletTimeMultiplier, 0.1f, 0.8f);
        }
    }

    /// <summary>
    /// 径向菜单配置数据结构，用于序列化保存
    /// </summary>
    [Serializable]
    public struct RadialMenuSettingData
    {
        public int foodBindSectors;
        public float ignoreDurabilityValue;
        public bool showLowValueFood;
        public int sectorCount;
        public float iconSize;
        public float innerDeadZoneCoefficient;
        public float outerDeadZoneCoefficient;
        public float iconDistanceFactor;
        public float uiScalePercent;
        public string ui6style;
        public string ui8style;
        public bool showIconCount;
        public bool quickUseLastItemQ;
        public float longPressQWaitDuration;
        public bool isBulletTimeEnabled;
        public float bulletTimeMultiplier;
        public KeyCode radialMenuActivationKey;
        public string configToken;

        public RadialMenuSettingData(
            int foodBindSectors,
            float ignoreDurabilityValue,
            bool showLowValueFood,
            int sectorCount,
            float iconSize,
            float innerDeadZoneCoefficient,
            float outerDeadZoneCoefficient,
            float iconDistanceFactor,
            float uiScalePercent,
            string ui6style,
            string ui8style,
            bool showIconCount,
            bool quickUseLastItemQ,
            float longPressQWaitDuration,
            bool isBulletTimeEnabled,
            float bulletTimeMultiplier,
            KeyCode radialMenuActivationKey,
            string configToken)
        {
            this.foodBindSectors = foodBindSectors;
            this.ignoreDurabilityValue = ignoreDurabilityValue;
            this.showLowValueFood = showLowValueFood;
            this.sectorCount = sectorCount;
            this.iconSize = iconSize;
            this.innerDeadZoneCoefficient = innerDeadZoneCoefficient;
            this.outerDeadZoneCoefficient = outerDeadZoneCoefficient;
            this.iconDistanceFactor = iconDistanceFactor;
            this.uiScalePercent = uiScalePercent;
            this.ui6style = ui6style;
            this.ui8style = ui8style;
            this.showIconCount = showIconCount;
            this.quickUseLastItemQ = quickUseLastItemQ;
            this.longPressQWaitDuration = longPressQWaitDuration;
            this.isBulletTimeEnabled = isBulletTimeEnabled;
            this.bulletTimeMultiplier = bulletTimeMultiplier;
            this.radialMenuActivationKey = radialMenuActivationKey;
            this.configToken = configToken;
        }
    }
}