﻿using System;
using UnityEngine;
using Duckov.Modding;
using RadialMenu.Logic; // 引入绑定流程等逻辑
using Duckov.UI;
using RadialMenu.Patches;
using RadialMenu.ConfigAndAPI;

namespace RadialMenu
{
    /// <summary>
    /// 径向菜单模组主行为类（ModBehaviour）
    /// 负责：UI 创建、输入绑定、ModConfig 注册与清理
    /// </summary>
    public class ModBehaviour : Duckov.Modding.ModBehaviour
    {
        private GameObject? radialRootObj = null;

        public static string MOD_NAME = "环形菜单RadialMenu";

        private RadialMenu.UI.RadialMenu? radialMenu = null;
        private RadialMenu.UI.RadialInputHandler? inputHandler = null;

        void Awake()
        {
            Log.Info("RadialMenu: Awake — 模组加载中");

            // 初始化本地化系统
            try
            {
                LocalizationHelper.Initialize();
                Log.Info("RadialMenu: 本地化系统初始化完成");
            }
            catch (Exception ex)
            {
                Log.Warn("RadialMenu: 本地化系统初始化失败: " + ex.Message);
            }

            // 测试食物数据管理器
            try
            {
                FoodDataManagerTest.RunAllTests();
            }
            catch (Exception ex)
            {
                Log.Warn("RadialMenu: 食物数据管理器测试失败: " + ex.Message);
            }

            // 尝试先从本地加载上次保存的配置（如果有）
            try
            {
                bool loaded = RadialMenuSaver.TryLoadConfigFromLocal();
                if (loaded)
                {
                    Log.Info("RadialMenu: 已从本地加载配置");
                }
                else
                {
                    Log.Info("RadialMenu: 本地无配置，使用默认值");
                }
            }
            catch (Exception ex)
            {
                Log.Warn("RadialMenu: 尝试加载本地配置时发生异常: " + ex.Message);
            }

            // 初始化新的配置系统
            try
            {
                RadialMenuSaver.Load();
                Log.Info("RadialMenu: 新配置系统初始化完成");
            }
            catch (Exception ex)
            {
                Log.Warn("RadialMenu: 初始化新配置系统时出现异常: " + ex.Message);
            }
        }

        void OnEnable()
        {
            Log.Info("ModBehaviour OnEnable — 模组启用");

            // 加载配置
            RadialMenuSaver.Load();

            // 创建根对象用于承载所有菜单相关组件
            radialRootObj = new GameObject("RadialMenuRoot");

            // 添加输入检测组件并绑定事件回调
            inputHandler = radialRootObj.AddComponent<RadialMenu.UI.RadialInputHandler>();
            inputHandler.OnHoldStart += HandleHoldStart;
            inputHandler.OnHoldRelease += HandleHoldRelease;
            inputHandler.OnQuickUse += HandleQuickUse;

            // 添加径向菜单UI组件
            radialMenu = radialRootObj.AddComponent<RadialMenu.UI.RadialMenu>();

            // 添加子弹时间更新器组件，用于全局监听和维持子弹时间状态
            radialRootObj.AddComponent<BulletTimeUpdater>();

            DontDestroyOnLoad(radialRootObj);

            Log.DebugMsg("初始化完成: InputHandler + UI + BulletTimeUpdater 已挂载");

            // 订阅 ModManager 的激活事件（用于捕获 ModSetting 模块何时就绪）
            ModManager.OnModActivated += OnModActivated;
            ModManager.OnModWillBeDeactivated += OnModWillBeDeactivated;
            
            // 订阅配置变更事件，以便在配置更新时同步到输入处理器
            RadialMenuSetting.OnLongPressQWaitDurationChanged += OnLongPressQWaitDurationChanged;
            RadialMenuSetting.OnQuickUseLastItemQChanged += OnQuickUseLastItemQChanged;

            // 防止 ModSetting 已经激活但事件被错过：再次检查
            if (ModSetting.IsInit)
            {
                try
                {
                    Log.Info("ModBehaviour: 发现 ModSetting 已可用（OnEnable 检查），尝试注册");
                    RadialMenuModConfig.SetupModConfig(info, MOD_NAME);
                    RadialMenuModConfig.LoadConfigFromModSetting();
                }
                catch (Exception ex)
                {
                    Log.Warn("ModBehaviour: 在 OnEnable 中 SetupModConfig/LoadConfigFromModSetting 时出错: " + ex.Message);
                }
            }
        }

        void OnDisable()
        {
            Log.Info("ModBehaviour OnDisable — 模组禁用");

            // 清理本地化系统
            try
            {
                LocalizationHelper.Cleanup();
                Log.Info("RadialMenu: 本地化系统已清理");
            }
            catch (Exception ex)
            {
                Log.Warn("RadialMenu: 本地化系统清理失败: " + ex.Message);
            }

            // 解除输入事件绑定
            if (inputHandler != null)
            {
                inputHandler.OnHoldStart -= HandleHoldStart;
                inputHandler.OnHoldRelease -= HandleHoldRelease;
                inputHandler.OnQuickUse -= HandleQuickUse;
            }
            else
            {
                Log.Warn("尝试解除输入事件绑定时，inputHandler 为 null");
            }

            // 卸载 UI 根对象
            if (radialRootObj != null)
            {
                GameObject.Destroy(radialRootObj);
                radialRootObj = null;
                radialMenu = null;
                inputHandler = null;
                Log.DebugMsg("菜单根对象已销毁");
            }
            else
            {
                Log.Warn("尝试销毁菜单根对象时，radialRootObj 已为 null");
            }

            // 解除 ModManager 事件订阅
            ModManager.OnModActivated -= OnModActivated;
            ModManager.OnModWillBeDeactivated -= OnModWillBeDeactivated;
            
            // 解除配置变更事件订阅
            RadialMenuSetting.OnLongPressQWaitDurationChanged -= OnLongPressQWaitDurationChanged;
            RadialMenuSetting.OnQuickUseLastItemQChanged -= OnQuickUseLastItemQChanged;

            // 卸载 ModSetting 注册（移除回调监听）
            try
            {
                RadialMenuModConfig.TeardownModConfig();

                // 同时保存当前配置到本地，防止丢失
                RadialMenuSaver.SaveConfigToLocal();
                Log.Info("ModBehaviour: 已 teardown ModSetting 并保存配置到本地");
            }
            catch (Exception ex)
            {
                Log.Warn("ModBehaviour: TeardownModConfig/SaveConfigToLocal 出错: " + ex.Message);
            }

            // 保存配置并清理设置
            RadialMenuSaver.Save();
            RadialMenuSetting.Clear();
        }

        /// <summary>
        /// 当其他模组（例如 ModSetting）被激活时触发。
        /// 我们关注 ModSetting 被激活的情况。
        /// </summary>
        private void OnModActivated(ModInfo info, Duckov.Modding.ModBehaviour behaviour)
        {
            try
            {
                if (info.Equals(default) || string.IsNullOrEmpty(info.name))
                    return;

                // 判断是否为 ModSetting 模块激活
                if (info.name == ModSetting.MOD_NAME)
                {
                    Log.Info("RadialMenu: 检测到 ModSetting 模块激活，准备注册配置菜单");
                    RadialMenuModConfig.SetupModConfig(info, MOD_NAME);
                    RadialMenuModConfig.LoadConfigFromModSetting();
                }
            }
            catch (Exception ex)
            {
                Log.Warn("RadialMenu: OnModActivated 处理时发生异常: " + ex.Message);
            }
        }

        /// <summary>
        /// 当其他模组将被禁用时触发
        /// </summary>
        private void OnModWillBeDeactivated(ModInfo arg1, Duckov.Modding.ModBehaviour arg2)
        {
            if (arg1.name != ModSetting.MOD_NAME || !ModSetting.Init(info))
                return;
            
            // 禁用ModSetting的时候移除监听
            RadialMenuModConfig.TeardownModConfig();
        }
        
        /// <summary>
        /// 当长按Q等待时长配置发生变化时触发
        /// </summary>
        private void OnLongPressQWaitDurationChanged(float value)
        {
            try
            {
                Log.DebugMsg($"[ModBehaviour] 检测到长按Q等待时长配置变更: {value}，更新输入处理器配置");
                
                // 更新输入处理器的配置
                if (inputHandler != null)
                {
                    // 通过反射调用 UpdateConfigValues 方法
                    var method = typeof(RadialMenu.UI.RadialInputHandler).GetMethod("UpdateConfigValues",
                        System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                    method?.Invoke(inputHandler, null);
                }
            }
            catch (Exception ex)
            {
                Log.Error($"[ModBehaviour] 处理长按Q等待时长配置变更时出错: {ex.Message}", ex);
            }
        }
        
        /// <summary>
        /// 当快速使用最后一个物品配置发生变化时触发
        /// </summary>
        private void OnQuickUseLastItemQChanged(bool value)
        {
            try
            {
                Log.DebugMsg($"[ModBehaviour] 检测到快速使用最后一个物品配置变更: {value}，更新输入处理器配置");
                
                // 更新输入处理器的配置
                if (inputHandler != null)
                {
                    // 通过反射调用 UpdateConfigValues 方法
                    var method = typeof(RadialMenu.UI.RadialInputHandler).GetMethod("UpdateConfigValues",
                        System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                    method?.Invoke(inputHandler, null);
                }
            }
            catch (Exception ex)
            {
                Log.Error($"[ModBehaviour] 处理快速使用最后一个物品配置变更时出错: {ex.Message}", ex);
            }
        }

        private void HandleHoldStart()
        {
            Log.DebugMsg("HandleHoldStart — 呼出菜单");

            try
            {
                if (View.ActiveView is LootView)
                {
                    var selected = ItemUIUtilities.SelectedItem;
                    if (selected != null)
                    {
                        Log.DebugMsg("[ModBehaviour] 场景二：在 LootView 且选中物品，启动绑定流程（BindingManagerdata）");

                        if (radialMenu == null)
                        {
                            Log.Error("[ModBehaviour] radialMenu 为 null，无法启动绑定流程。");
                        }
                        else
                        {
                            BindingManager.StartBind(this, radialMenu);
                        }

                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error("[ModBehaviour] 在尝试启动绑定流程时出现异常，退回到默认显示菜单逻辑", ex);
            }

            radialMenu?.ShowMenu();
        }

        private void HandleHoldRelease()
        {
            Log.DebugMsg("HandleHoldRelease — 松开Q键，关闭菜单");
            radialMenu?.HandleRelease();
        }

        private void HandleQuickUse()
        {
            Log.DebugMsg("HandleQuickUse — 快捷使用上一次物品");
            radialMenu?.QuickUseLastItem();
        }

        /// <summary>
        /// 在Setup之后调用（触发时机:ModSetting在此mod之前启用）
        /// </summary>
        protected override void OnAfterSetup()
        {
            // (触发时机:ModSetting在此mod之前启用)此mod，Setup后,尝试进行初始化
            if (ModSetting.Init(info))
            {
                RadialMenuModConfig.SetupModConfig(info, MOD_NAME);
            }
        }

        /// <summary>
        /// 在禁用之前调用
        /// </summary>
        protected override void OnBeforeDeactivate()
        {
            // 此mod禁用后，移除ModSetting中的UI
            if (ModSetting.IsInit)
            {
                RadialMenuModConfig.TeardownModConfig();
            }
        }
    }
}
