using System;
using UnityEngine;
using RadialMenu.Logic;
using RadialMenu.Logic.Utils;
using Duckov.UI;
using ItemStatsSystem;
using RadialMenu.ConfigAndAPI;
using RadialMenu.Patches;

namespace RadialMenu.UI
{
    /// <summary>
    /// 处理径向菜单相关的按键输入（短按 = 快速使用，长按 = 呼出径向菜单）。
    /// </summary>
    public class RadialInputHandler : MonoBehaviour
    {
        public event Action OnHoldStart;
        public event Action OnHoldRelease;
        public event Action OnQuickUse;
        public event Action OnHoldCanceled;

        [Tooltip("用于激活径向菜单的按键（从配置文件读取）")]
        public KeyCode activationKey;

        [Tooltip("判定为长按所需的秒数（>= 0）")]
        public float holdThreshold = 0.25f;
        
        // 从配置文件获取的长按等待时间
        private float configHoldThreshold = 0.25f;

        private float timer;
        private bool holding;
        private bool holdTriggered;

        // ======================
        // 新增：启动对白只触发一次
        // ======================
        private static bool hasShownStartupDialogue = false;

        void Awake()
        {
            // 从配置文件获取参数值
            UpdateConfigValues();
            
            if (holdThreshold < 0f)
            {
                Log.Warn("[RadialInputHandler] holdThreshold 小于 0，已重置为 0");
                holdThreshold = 0f;
            }

            // 监听配置变更
            RadialMenuSetting.OnRadialMenuActivationKeyChanged += OnActivationKeyChanged;
            RadialMenuSetting.OnLongPressQWaitDurationChanged += OnHoldThresholdChanged;
        }

        void OnDestroy()
        {
            // 移除配置变更监听
            RadialMenuSetting.OnRadialMenuActivationKeyChanged -= OnActivationKeyChanged;
            RadialMenuSetting.OnLongPressQWaitDurationChanged -= OnHoldThresholdChanged;
        }
        
        /// <summary>
        /// 从配置文件更新参数值
        /// </summary>
        private void UpdateConfigValues()
        {
            try
            {
                configHoldThreshold = RadialMenuSetting.LongPressQWaitDuration;
                holdThreshold = configHoldThreshold;
                activationKey = RadialMenuSetting.RadialMenuActivationKey;
                Log.DebugMsg($"[RadialInputHandler] 已从配置更新长按等待时间: {configHoldThreshold}s");
                Log.DebugMsg($"[RadialInputHandler] 已从配置更新激活按键: {activationKey}");
            }
            catch (Exception ex)
            {
                Log.Error("[RadialInputHandler] 更新配置值时出错，使用默认值", ex);
                configHoldThreshold = 0.25f;
                holdThreshold = configHoldThreshold;
                activationKey = KeyCode.Q; // 默认按键
            }
        }

        /// <summary>
        /// 激活按键变更事件处理
        /// </summary>
        private void OnActivationKeyChanged(KeyCode newKey)
        {
            activationKey = newKey;
            Log.DebugMsg($"[RadialInputHandler] 激活按键已更新为: {activationKey}");
        }

        /// <summary>
        /// 长按等待时间变更事件处理
        /// </summary>
        private void OnHoldThresholdChanged(float newThreshold)
        {
            configHoldThreshold = newThreshold;
            holdThreshold = newThreshold;
            Log.DebugMsg($"[RadialInputHandler] 长按等待时间已更新为: {configHoldThreshold}s");
        }

        void Update()
        {
            if (Input.GetKeyDown(activationKey))
            {
                var character = CharacterMainControl.Main;
                if (GameManager.Paused || character == null)
                {
                    Log.DebugMsg("游戏暂停或未检测到玩家角色 — 忽略按键并重置状态");
                    holding = false;
                    timer = 0f;
                    holdTriggered = false;
                    return;
                }

                timer = 0f;
                holding = true;
                holdTriggered = false;
                Log.DebugMsg($"{activationKey} 键按下 — 开始计时");
            }

            if (holding)
            {
                timer += Time.deltaTime;

                // 达到阈值并且还未触发长按事件
                if (!holdTriggered && timer >= holdThreshold)
                {
                    if (IsAllowedToShowRadial())
                    {
                        holdTriggered = true;
                        Log.DebugMsg($"达到阈值 {holdThreshold:F2}s 且条件允许 — 触发 OnHoldStart");
                        
                        // 在打开径向菜单前自动关闭物品详情页面
                        UIHelper.CloseAllItemDetailsWindows();
                        
                        OnHoldStart?.Invoke();

                        // =============================
                        // 新增逻辑：第一次场景一触发时说一句话
                        // =============================
                        TryShowStartupDialogue();
                    }
                    else
                    {
                        Log.DebugMsg($"达到阈值 {holdThreshold:F2}s，但当前不允许显示圆盘 — 等待条件变化或释放按键");
                    }
                }

                if (holdTriggered && !IsAllowedToShowRadial())
                {
                    Log.DebugMsg("长按已触发但条件随后变为不允许 — 触发 OnHoldCanceled 并重置长按标志");
                    OnHoldCanceled?.Invoke();
                    holdTriggered = false;
                }
            }

            if (Input.GetKeyUp(activationKey))
            {
                if (GameManager.Paused)
                {
                    Log.DebugMsg("游戏已暂停 — 忽略按键松开并重置内部状态");
                    holding = false;
                    timer = 0f;
                    holdTriggered = false;
                    return;
                }

                if (holding)
                {
                    if (holdTriggered)
                    {
                        Log.Info($"松开 {activationKey} 键 — 已触发长按，触发 OnHoldRelease");
                        OnHoldRelease?.Invoke();
                    }
                    else
                    {
                        if (timer < holdThreshold)
                        {
                            Log.Info($"短按检测（{timer:F3}s） — 触发快速使用或特定分支逻辑");

                            // 检查是否开启了快速使用上次物品功能
                            bool quickUseEnabled = false;
                            try
                            {
                                quickUseEnabled = RadialMenuSetting.QuickUseLastItemQ;
                                Log.DebugMsg($"[RadialInput] 快速使用上次物品功能配置: {quickUseEnabled}");
                            }
                            catch (Exception ex)
                            {
                                Log.Error("[RadialInput] 获取快速使用配置时出错，默认启用", ex);
                                quickUseEnabled = true;
                            }

                            // ============================
                            // 新增分支：
                            // 如果当前界面是 LootView 且没有选中物品，
                            // 则调用查找"价重比最低"物品的方法，并用 speakup 随机播放带 item.DisplayName 的提示语句。
                            // 匹配此分支时不再触发 OnQuickUse（互斥，以避免重复行为）。
                            // ============================
                            try
                            {
                                if (View.ActiveView is LootView)
                                {
                                    var selected = ItemUIUtilities.SelectedItem;
                                    
                                    if (selected == null)
                                    {
                                        Log.DebugMsg("[RadialInput] LootView 且未选中物品 — 触发价重比最低物品播报逻辑");

                                        // 调用你已提供的查找方法
                                        float lowestRatio;
                                        Item? item = FindLowPriceToWeightItems.GetLowestPriceToWeightItem(out lowestRatio);

                                        var character = CharacterMainControl.Main;
                                        if (character == null)
                                        {
                                            Log.DebugMsg("[RadialInput] 未找到玩家角色，无法播放对白");
                                        }
                                        else
                                        {
                                            if (item != null)
                                            {
                                                // 使用你给的示例调用方式，延迟 1 秒，随机多条语句
                                                try
                                                {
                                                    speakup.ShowRandomDialogue(
                                                        character.transform,
                                                        0f,
                                                        $"价重比最低的是{item.DisplayName}！",
                                                        $"建议先丢掉{item.DisplayName}！",
                                                        $"背不动了，先把{item.DisplayName}扔了吧～",
                                                        $"{item.DisplayName}？这东西不怎么值钱的样子？",
                                                        $"重死了！快把{item.DisplayName}扔了！",
                                                        $"背不动了，先把{item.DisplayName}扔了吧～",
                                                        $"{item.DisplayName}最不值钱～"
                                                        );
                                                    Log.Info($"已触发价重比最低物品播报: {item.DisplayName} (ratio={lowestRatio})");
                                                }
                                                catch (Exception ex)
                                                {
                                                    Log.Error("[RadialInput] 调用 speakup.ShowRandomDialogue 时发生异常", ex);
                                                }
                                            }
                                            else
                                            {
                                                // 没找到不划算的物品，给出友好提示
                                                try
                                                {
                                                    speakup.ShowDialogue(LocalizationHelper.Get("Input_NoLowValueItem"), character.transform, delay: 1f);
                                                    Log.DebugMsg("[RadialInput] 未找到价重比最低物品（返回 null）");
                                                }
                                                catch (Exception ex)
                                                {
                                                    Log.Error("[RadialInput] 调用 speakup.ShowDialogue 时发生异常", ex);
                                                }
                                            }
                                        }

                                        // 既然我们在 LootView 的"未选中"短按分支里处理了语音/提示，
                                        // 就不再继续触发通用的 OnQuickUse（避免重复或误用）。
                                        goto SKIP_QUICKUSE;
                                    } // end selected == null
                                } // end if LootView
                            }
                            catch (Exception ex)
                            {
                                Log.Error("[RadialInput] 在处理 LootView 短按分支时发生异常，回退到正常快速使用逻辑", ex);
                                // 发生异常后，继续执行后面的 OnQuickUse 调用（fallback）
                            }

                            // 如果开启了快速使用功能且没有命中特殊分支，执行默认快速使用事件
                            if (quickUseEnabled)
                            {
                                OnQuickUse?.Invoke();
                            }
                            else
                            {
                                Log.DebugMsg("[RadialInput] 快速使用上次物品功能已禁用，跳过 OnQuickUse");
                            }
                        SKIP_QUICKUSE:;
                        }
                        else
                        {
                            Log.DebugMsg($"松开按键 — 时长 {timer:F3}s >= 阈值但未触发长按（条件未满足），不执行操作");
                        }
                    }
                }

                holding = false;
                timer = 0f;
                holdTriggered = false;
            }
        }

        /// <summary>
        /// 判断是否允许显示径向菜单
        /// </summary>
        private bool IsAllowedToShowRadial()
        {
            try
            {
                var character = CharacterMainControl.Main;
                if (character == null)
                {
                    Log.DebugMsg("[RadialInput] 未检测到玩家角色，禁止呼出圆盘");
                    return false;
                }

                if (GameManager.Paused)
                {
                    Log.DebugMsg("[RadialInput] 游戏已暂停，禁止呼出圆盘");
                    return false;
                }

                if (View.ActiveView == null)
                {
                    Log.DebugMsg("[RadialInput] 无活跃 UI，允许呼出圆盘（场景一）");
                    return true;
                }

                if (View.ActiveView is LootView)
                {
                    var selected = ItemUIUtilities.SelectedItem;
                    if (selected != null)
                    {
                        Log.DebugMsg("[RadialInput] 当前为 LootView 且存在选中物品，允许呼出圆盘（场景二）");
                        return true;
                    }
                    else
                    {
                        Log.DebugMsg("[RadialInput] 当前为 LootView 但没有选中物品，禁止呼出圆盘");
                        speakup.ShowDialogue(LocalizationHelper.Get("Input_SelectItemFirst"), CharacterMainControl.Main?.transform, 2f);
                        return false;
                    }
                }

                Log.DebugMsg("[RadialInput] 存在其他活跃 UI，禁止呼出圆盘");
                speakup.ShowDialogue(LocalizationHelper.Get("Input_NoRadialHere"), CharacterMainControl.Main?.transform, 2f);
                return false;
            }
            catch (Exception ex)
            {
                Log.Error("[RadialInput] 判断是否允许显示圆盘时发生异常，默认为禁止", ex);
                return false;
            }
        }

        // =========================
        // 新增：只在首次触发时说话
        // =========================
        private void TryShowStartupDialogue()
        {
            if (hasShownStartupDialogue)
                return;

            // 检查当前是否为“场景一”触发，即没有任何活跃 UI
            if (View.ActiveView == null)
            {
                var character = CharacterMainControl.Main;
                if (character != null)
                {

                    if (!ModSetting.IsInit)
                    {
                        speakup.ShowDialogue(LocalizationHelper.Get("UI_InstallModConfig"));
                    }
                    else
                    {
                        speakup.ShowDialogue(LocalizationHelper.Get("Input_AuthorRequest"), character.transform, delay: 2.5f);
                        hasShownStartupDialogue = true;
                        Log.Info("[RadialInput] 已显示启动对白，将不再重复触发直到游戏重启。");
                    }
                }
            }
        }
    }
}