// File: UI/RadialMenu.cs
using System;
using System.Reflection;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using RadialMenu.Logic;
using ItemStatsSystem;
using RadialMenu.ConfigAndAPI;
using RadialMenu.Patches;

namespace RadialMenu.UI
{
    public partial class RadialMenu : MonoBehaviour
    {
        //=============================
        // 新配置变量（用户可在配置面板中修改）
        //=============================
        public int sectorCount = 6;
        public float iconSize = 255f;
        public float innerDeadZoneCoefficient = 0.26f;
        public float outerDeadZoneCoefficient = 2.7f;
        public float iconDistanceFactor = 0.71f;
        public bool showIconCount = true;
        public Vector2[]? perIconOffsets = null;

        //=============================
        // 运行时内部字段（不要序列化）
        //=============================
        public Vector2[] IconPositions { get; private set; } = Array.Empty<Vector2>();
        public event Action<Vector2[]>? OnIconPositionsUpdated;

        public bool IsMenuActive => menuActive;
        public int HighlightedIndex => highlightedIndex;
        public int LastConfirmedSector { get; private set; } = -1;

        public event Action<int>? OnSectorConfirmed;
        public event Action? OnMenuOpened;
        public event Action? OnMenuClosed;

        private RectTransform? canvasRect;
        private RectTransform? menuRect;
        private Image? backgroundImage;
        private Image[]? sectorImages;
        private int highlightedIndex = -1;
        private bool menuActive = false;
        private Vector2 initialPos;
        private float innerDeadRadius;
        private float outerDeadRadius;

        // 配置中的“百分比”——来自 ModConfig 的值
        private float configUiScalePercent = 0.38f;

        private float uiScalePercent = 1f;

        private RadialMenuIconRenderer? iconRenderer;

        private BindingEntry? _lastUsedBinding = null;
        private Item? _lastUsedItem = null;
        private int _lastUsedSectorIndex = -1;

        // 移除 DEFAULT 常量依赖（不再用于最终计算）
        private const float minCoeff = 0.6f;
        private const float maxCoeff = 1.4f;

        // 当前已应用的“最终”值（用于比较是否需要重建）
        private int appliedSectorCount = -1;
        private float appliedIconSize = -1f;
        private float appliedInnerDeadCoeff = -1f;
        private float appliedOuterDeadCoeff = -1f;
        private float appliedIconDistanceFactor = -1f;
        private bool appliedShowIconCount = true;

        // 记录背景与 sectors 的原始 native size（用于基于 native size 的稳定缩放）
        private Vector2 backgroundNativeSize = Vector2.zero;
        private Vector2[]? sectorNativeSizes = null;

        void Start()
        {
            Log.Info(LocalizationHelper.Get("Log_RadialMenuInit"));

            // 尝试从 RadialMenuModConfig 读取（若 ModSetting 尚未就绪会被安全忽略）
            try
            {
                RadialMenuModConfig.LoadConfigFromModSetting();
            }
            catch (Exception ex) { Log.Warn("LoadConfigFromModSetting failed in Start: " + ex.Message); }

            // 创建画布与基础 Menu 节点（仅一次）
            CreateCanvasAndMenu();

            // 按配置应用并构建
            ApplyConfigValuesAndBuild(initialBuild: true);

            // 订阅配置变更回调（实现热加载）
            try
            {
                RadialMenuSetting.OnSectorCountChanged += OnSectorCountChanged;
                RadialMenuSetting.OnIconSizeChanged += OnIconSizeChanged;
                RadialMenuSetting.OnInnerDeadZoneCoefficientChanged += OnInnerDeadZoneCoefficientChanged;
                RadialMenuSetting.OnOuterDeadZoneCoefficientChanged += OnOuterDeadZoneCoefficientChanged;
                RadialMenuSetting.OnIconDistanceFactorChanged += OnIconDistanceFactorChanged;
                RadialMenuSetting.OnShowIconCountChanged += OnShowIconCountChanged;
                RadialMenuSetting.OnUiScalePercentChanged += OnUiScalePercentChanged;
                RadialMenuSetting.OnUI6styleChanged += OnUI6styleChanged;
                RadialMenuSetting.OnUI8styleChanged += OnUI8styleChanged;
            }
            catch (Exception ex) { Log.Warn("Failed to add config change delegates: " + ex.Message); }

            Log.Info(LocalizationHelper.Get("Log_RadialMenuComplete"));
            // 初始化后刷新绑定与图标
            RefreshBindingsAndRenderIcons();
        }

        private void OnDestroy()
        {
            // 取消订阅
            try
            {
                RadialMenuSetting.OnSectorCountChanged -= OnSectorCountChanged;
                RadialMenuSetting.OnIconSizeChanged -= OnIconSizeChanged;
                RadialMenuSetting.OnInnerDeadZoneCoefficientChanged -= OnInnerDeadZoneCoefficientChanged;
                RadialMenuSetting.OnOuterDeadZoneCoefficientChanged -= OnOuterDeadZoneCoefficientChanged;
                RadialMenuSetting.OnIconDistanceFactorChanged -= OnIconDistanceFactorChanged;
                RadialMenuSetting.OnShowIconCountChanged -= OnShowIconCountChanged;
                RadialMenuSetting.OnUiScalePercentChanged -= OnUiScalePercentChanged;
                RadialMenuSetting.OnUI6styleChanged -= OnUI6styleChanged;
                RadialMenuSetting.OnUI8styleChanged -= OnUI8styleChanged;
            }
            catch { /* 忽略 */ }
        }

        // ---------- 配置变更回调（热加载入口） ----------
        private void OnSectorCountChanged(int value)
        {
            try
            {
                ApplyConfigValuesAndBuild(initialBuild: false);
                Log.Info($"RadialMenu: SectorCount changed -> {value}");
            }
            catch (Exception ex)
            {
                Log.Warn("OnSectorCountChanged failed: " + ex.Message);
            }
        }

        private void OnIconSizeChanged(float value)
        {
            try
            {
                ApplyConfigValuesAndBuild(initialBuild: false);
                Log.Info($"RadialMenu: IconSize changed -> {value}");
            }
            catch (Exception ex)
            {
                Log.Warn("OnIconSizeChanged failed: " + ex.Message);
            }
        }

        private void OnInnerDeadZoneCoefficientChanged(float value)
        {
            try
            {
                ApplyConfigValuesAndBuild(initialBuild: false);
                Log.Info($"RadialMenu: InnerDeadZoneCoefficient changed -> {value}");
            }
            catch (Exception ex)
            {
                Log.Warn("OnInnerDeadZoneCoefficientChanged failed: " + ex.Message);
            }
        }

        private void OnOuterDeadZoneCoefficientChanged(float value)
        {
            try
            {
                ApplyConfigValuesAndBuild(initialBuild: false);
                Log.Info($"RadialMenu: OuterDeadZoneCoefficient changed -> {value}");
            }
            catch (Exception ex)
            {
                Log.Warn("OnOuterDeadZoneCoefficientChanged failed: " + ex.Message);
            }
        }

        private void OnIconDistanceFactorChanged(float value)
        {
            try
            {
                // 重新计算图标位置
                ComputeIconPositions(sectorCount);
                
                // 更新 IconRenderer 的布局并重新渲染
                if (iconRenderer != null)
                {
                    iconRenderer.UpdateLayout(IconPositions, perIconOffsets, iconSize);
                    iconRenderer.RenderAllIcons();
                }
                
                Log.Info(LocalizationHelper.GetFormatted("Log_IconDistanceUpdated", value));
            }
            catch (Exception ex)
            {
                Log.Warn("OnIconDistanceFactorChanged failed: " + ex.Message);
            }
        }

        private void OnShowIconCountChanged(bool value)
        {
            try
            {
                ApplyConfigValuesAndBuild(initialBuild: false);
                Log.Info($"RadialMenu: ShowIconCount changed -> {value}");
            }
            catch (Exception ex)
            {
                Log.Warn("OnShowIconCountChanged failed: " + ex.Message);
            }
        }

        private void OnUiScalePercentChanged(float value)
        {
            try
            {
                ApplyConfigValuesAndBuild(initialBuild: false);
                Log.Info($"RadialMenu: UiScalePercent changed -> {value}");
            }
            catch (Exception ex)
            {
                Log.Warn("OnUiScalePercentChanged failed: " + ex.Message);
            }
        }

        private void OnUI6styleChanged(string value)
        {
            try
            {
                ApplyConfigValuesAndBuild(initialBuild: false);
                Log.Info($"RadialMenu: UI6style changed -> {value}");
            }
            catch (Exception ex)
            {
                Log.Warn("OnUI6styleChanged failed: " + ex.Message);
            }
        }

        private void OnUI8styleChanged(string value)
        {
            try
            {
                ApplyConfigValuesAndBuild(initialBuild: false);
                Log.Info($"RadialMenu: UI8style changed -> {value}");
            }
            catch (Exception ex)
            {
                Log.Warn("OnUI8styleChanged failed: " + ex.Message);
            }
        }

        // ---------- 创建 Canvas 与根节点（仅一次） ----------
        private void CreateCanvasAndMenu()
        {
            if (canvasRect != null && menuRect != null) return;

            Canvas canvas = new GameObject("RadialMenuCanvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster)).GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            var scaler = canvas.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 0.5f;
            DontDestroyOnLoad(canvas.gameObject);
            canvasRect = canvas.GetComponent<RectTransform>();

            menuRect = new GameObject("RadialMenu").AddComponent<RectTransform>();
            menuRect.SetParent(canvasRect, false);
            menuRect.pivot = new Vector2(0.5f, 0.5f);
            menuRect.localScale = Vector3.one;
            menuRect.gameObject.SetActive(false);
        }

        // ---------- 计算并应用配置；决定是否重建或更新UI ----------
        private void ApplyConfigValuesAndBuild(bool initialBuild)
        {
            // 从 RadialMenuSetting 获取最新配置
            // *** 现在所有 final 值完全由 RadialMenuSetting 决定 ***

            // 读取配置中指定的 uiScalePercent（将作为背景相对于原图的比例）
            // 直接读取值并限制到合理范围，避免极端值导致显示异常
            float rawUiScale = RadialMenuSetting.UiScalePercent;
            // 保留原先你注释过的范围限制 0.1 - 0.7（可调整）
            float finalUiScale = Mathf.Clamp(rawUiScale, 0.1f, 0.7f);
            configUiScalePercent = finalUiScale;

            // 直接使用配置中的其它参数
            int finalSectorCount = Math.Max(1, RadialMenuSetting.SectorCount); // 至少 1 个分区
            float finalIconSize = RadialMenuSetting.IconSize;
            float finalInnerDeadCoeff = RadialMenuSetting.InnerDeadZoneCoefficient;
            float finalOuterDeadCoeff = RadialMenuSetting.OuterDeadZoneCoefficient;
            float finalIconDistanceFactor = RadialMenuSetting.IconDistanceFactor;
            bool finalShowIconCount = RadialMenuSetting.ShowIconCount;

            // 把这些 cfg 值同步回实例字段（以便类中其它地方使用统一的数据）
            sectorCount = finalSectorCount;
            iconSize = finalIconSize;
            innerDeadZoneCoefficient = finalInnerDeadCoeff;
            outerDeadZoneCoefficient = finalOuterDeadCoeff;
            iconDistanceFactor = finalIconDistanceFactor;
            showIconCount = finalShowIconCount;

            // 检查是否需要重建分区（sector count 变化需要重建贴图物体）
            bool needRecreateSectors = (appliedSectorCount != finalSectorCount) || initialBuild || sectorImages == null;
            bool needReinitIconRenderer = (appliedIconSize != finalIconSize) || needRecreateSectors || initialBuild || iconRenderer == null;
            bool needUpdateLayout = (appliedInnerDeadCoeff != finalInnerDeadCoeff) || (appliedOuterDeadCoeff != finalOuterDeadCoeff) || (appliedIconDistanceFactor != finalIconDistanceFactor) || (appliedShowIconCount != finalShowIconCount);

            // 先更新/重建背景与 sectors（如果需要）
            if (needRecreateSectors)
            {
                LoadOrRecreateBackgroundAndSectors(finalSectorCount, finalUiScale);
            }
            else
            {
                // 仍需调整背景及 sector 尺寸（uiScale 可能变化）
                AdjustBackgroundAndSectorScale(finalUiScale);
            }

            // 更新内外死区半径（基于当前背景宽度）
            UpdateDeadZoneRadii(finalInnerDeadCoeff, finalOuterDeadCoeff);

            // 初始化或更新 IconRenderer
            if (needReinitIconRenderer)
            {
                InitOrReinitIconRenderer(finalIconSize, perIconOffsets ?? Array.Empty<Vector2>(), finalShowIconCount);
            }
            else if (needUpdateLayout)
            {
                // 只更新布局参数（不重新创建 renderer）
                try
                {
                    if (iconRenderer != null)
                    {
                        iconRenderer.UpdateLayout(IconPositions, perIconOffsets, finalIconSize);
                        iconRenderer.RenderAllIcons();
                    }
                }
                catch (Exception ex) { Log.Error("IconRenderer 更新布局失败", ex); }
            }

            // 更新应用记录
            appliedSectorCount = finalSectorCount;
            appliedIconSize = finalIconSize;
            appliedInnerDeadCoeff = finalInnerDeadCoeff;
            appliedOuterDeadCoeff = finalOuterDeadCoeff;
            appliedIconDistanceFactor = finalIconDistanceFactor;
            appliedShowIconCount = finalShowIconCount;

            // 记录当前已经应用的 uiScalePercent（供 AdjustBackgroundAndSectorScale 使用）
            uiScalePercent = finalUiScale;

            // 最后触发位置更新回调（供 IconRenderer 使用）
            OnIconPositionsUpdated?.Invoke(IconPositions);
        }

        // ---------- 背景与扇区贴图的加载 / 重建 ----------
        private void LoadOrRecreateBackgroundAndSectors(int finalSectorCount, float finalUiScale)
        {
            // 获取当前配置的UI样式
            string currentStyle = finalSectorCount == 6 ? RadialMenuSetting.UI6style : RadialMenuSetting.UI8style;
            
            // 确保样式有效，如果无效则使用默认样式
            if (!BackgroundTextureManager.IsStyleAvailable(finalSectorCount, currentStyle))
            {
                string defaultStyle = BackgroundTextureManager.GetDefaultStyle(finalSectorCount);
                Log.Warn(LocalizationHelper.GetFormatted("Log_StyleUnavailable", currentStyle, finalSectorCount, defaultStyle));
                currentStyle = defaultStyle;
                
                // 更新配置中的样式
                if (finalSectorCount == 6)
                    RadialMenuSetting.UI6style = currentStyle;
                else
                    RadialMenuSetting.UI8style = currentStyle;
            }

            Log.DebugMsg(LocalizationHelper.GetFormatted("Log_LoadingStyle", finalSectorCount, currentStyle));

            // 加载背景图片
            try
            {
                if (backgroundImage == null)
                {
                    string backgroundPath = BackgroundTextureManager.GetBackgroundPath(finalSectorCount, currentStyle);
                    if (string.IsNullOrEmpty(backgroundPath))
                    {
                        Log.Error($"无法获取 {finalSectorCount} 扇区样式 {currentStyle} 的背景路径");
                        return;
                    }

                    Texture2D bgTex = LoadTexture(backgroundPath);
                    Sprite bgSprite = Sprite.Create(bgTex, new Rect(0, 0, bgTex.width, bgTex.height), new Vector2(0.5f, 0.5f));
                    GameObject bgObj = new GameObject("Background");
                    bgObj.transform.SetParent(menuRect, false);
                    RectTransform bgRect = bgObj.AddComponent<RectTransform>();
                    bgRect.pivot = new Vector2(0.5f, 0.5f);
                    bgRect.sizeDelta = new Vector2(bgTex.width, bgTex.height);
                    bgRect.anchoredPosition = Vector2.zero;
                    backgroundImage = bgObj.AddComponent<Image>();
                    backgroundImage.sprite = bgSprite;
                    backgroundImage.SetNativeSize();

                    // 记录 native size 并按 finalUiScale 设置实际尺寸（避免之后累计放大/缩小误差）
                    backgroundNativeSize = new Vector2(bgTex.width, bgTex.height);
                    bgRect.sizeDelta = backgroundNativeSize * finalUiScale;

                    // 记录当前应用的 uiScalePercent
                    uiScalePercent = finalUiScale;
                }
                else
                {
                    // 已存在背景：重新加载当前样式的背景
                    string backgroundPath = BackgroundTextureManager.GetBackgroundPath(finalSectorCount, currentStyle);
                    if (!string.IsNullOrEmpty(backgroundPath))
                    {
                        Texture2D bgTex = LoadTexture(backgroundPath);
                        Sprite bgSprite = Sprite.Create(bgTex, new Rect(0, 0, bgTex.width, bgTex.height), new Vector2(0.5f, 0.5f));
                        backgroundImage.sprite = bgSprite;
                        backgroundImage.SetNativeSize();
                        
                        // 更新 native size 和尺寸
                        backgroundNativeSize = new Vector2(bgTex.width, bgTex.height);
                        backgroundImage.rectTransform.sizeDelta = backgroundNativeSize * finalUiScale;
                    }
                    
                    // 确保尺寸更新
                    AdjustBackgroundAndSectorScale(finalUiScale);
                }
            }
            catch (Exception ex) { Log.Error("加载背景失败", ex); }

            // 清除旧的 sectorImages（如果数量不匹配）
            if (sectorImages != null)
            {
                foreach (var img in sectorImages)
                {
                    if (img != null && img.gameObject != null)
                    {
                        try { Destroy(img.gameObject); } catch { }
                    }
                }
            }

            // 创建新的 sectors
            sectorImages = new Image[finalSectorCount];
            sectorNativeSizes = new Vector2[finalSectorCount];
            
            // 获取当前样式的所有扇区文件路径
            var sectorPaths = BackgroundTextureManager.GetSectorPaths(finalSectorCount, currentStyle);
            
            for (int i = 0; i < finalSectorCount; i++)
            {
                try
                {
                    Texture2D tex;
                    
                    // 尝试加载对应的扇区纹理
                    if (i < sectorPaths.Count && !string.IsNullOrEmpty(sectorPaths[i]))
                    {
                        tex = LoadTexture(sectorPaths[i]);
                        Log.DebugMsg($"加载扇区 {i} 纹理: {sectorPaths[i]}");
                    }
                    else
                    {
                        // 如果对应的扇区文件不存在，使用第一个扇区文件作为替代
                        if (sectorPaths.Count > 0)
                        {
                            tex = LoadTexture(sectorPaths[0]);
                            Log.DebugMsg($"扇区 {i} 纹理缺失，使用扇区 0 的纹理作为替代");
                        }
                        else
                        {
                            // 如果没有任何扇区文件，创建一个占位纹理
                            Log.Warn($"样式 {currentStyle} 没有任何扇区文件，为扇区 {i} 创建占位纹理");
                            tex = CreatePlaceholderTexture();
                        }
                    }
                    
                    Sprite sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), new Vector2(0.5f, 0.5f));
                    GameObject segObj = new GameObject($"Sector{i}");
                    segObj.transform.SetParent(menuRect, false);
                    RectTransform segRect = segObj.AddComponent<RectTransform>();
                    segRect.pivot = new Vector2(0.5f, 0.5f);
                    segRect.sizeDelta = new Vector2(tex.width, tex.height);
                    segRect.anchoredPosition = Vector2.zero;
                    Image img = segObj.AddComponent<Image>();
                    img.sprite = sprite;
                    img.SetNativeSize();

                    // 记录 native size 并按 finalUiScale 设置实际尺寸
                    sectorNativeSizes[i] = new Vector2(tex.width, tex.height);
                    segRect.sizeDelta = sectorNativeSizes[i] * finalUiScale;

                    img.gameObject.SetActive(false);
                    sectorImages[i] = img;
                }
                catch (Exception ex)
                {
                    Log.Warn($"创建 Sector{i} 失败: {ex.Message}");
                }
            }

            // 生成 IconPositions（基于 final sector count）
            ComputeIconPositions(sectorImages.Length);
        }

        // ---------- 调整 Background / Sector scale（无需重建） ----------
        private void AdjustBackgroundAndSectorScale(float scale)
        {
            // 基于记录的 native size 进行稳定缩放（避免多次缩放累乘）
            if (backgroundImage != null && backgroundNativeSize != Vector2.zero)
            {
                var br = backgroundImage.rectTransform;
                br.sizeDelta = backgroundNativeSize * scale;
            }

            if (sectorImages != null && sectorNativeSizes != null)
            {
                int n = Math.Min(sectorImages.Length, sectorNativeSizes.Length);
                for (int i = 0; i < n; i++)
                {
                    var img = sectorImages[i];
                    if (img == null) continue;
                    var r = img.rectTransform;
                    r.sizeDelta = sectorNativeSizes[i] * scale;
                }
            }

            // 更新记录的 uiScalePercent
            uiScalePercent = scale;
        }

        // ---------- 更新内外死区半径 ----------
        private void UpdateDeadZoneRadii(float finalInnerDeadCoeff, float finalOuterDeadCoeff)
        {
            if (backgroundImage == null) return;
            float radius = backgroundImage.rectTransform.rect.width * 0.5f;
            innerDeadRadius = radius * finalInnerDeadCoeff;
            outerDeadRadius = radius * finalOuterDeadCoeff;
        }

        // ---------- 初始化或重建 IconRenderer ----------
        private void InitOrReinitIconRenderer(float finalIconSize, Vector2[] offsets, bool showCounts)
        {
            try
            {
                if (iconRenderer != null)
                {
                    try { iconRenderer.ClearAllIcons(); } catch { }
                    Destroy(iconRenderer);
                    iconRenderer = null;
                }

                iconRenderer = menuRect.gameObject.AddComponent<RadialMenuIconRenderer>();
                iconRenderer.Initialize(menuRect!, IconPositions, finalIconSize, offsets ?? Array.Empty<Vector2>(), showCounts, responsiveSizing: true);

                OnIconPositionsUpdated = null; // 清除旧订阅，避免重复
                OnIconPositionsUpdated += (positions) =>
                {
                    try
                    {
                        if (iconRenderer != null)
                        {
                            iconRenderer.UpdateLayout(positions, perIconOffsets, finalIconSize);
                            iconRenderer.RenderAllIcons();
                        }
                    }
                    catch (Exception ex) { Log.Error("IconRenderer 渲染时出错", ex); }
                };

                OnMenuClosed = null;
                OnMenuClosed += () =>
                {
                    try
                    {
                        if (iconRenderer != null) iconRenderer.ClearAllIcons();
                    }
                    catch (Exception ex) { Log.Error("IconRenderer 清理时出错", ex); }
                };
                
                // 确保初始化后立即渲染一次图标，这样中心文本容器就会被创建
                if (iconRenderer != null)
                {
                    iconRenderer.RenderAllIcons();
                }
            }
            catch (Exception ex) { Log.Error("初始化 IconRenderer 失败", ex); }
        }

        // ---------- 生成 Icon 位置（供 IconRenderer 使用） ----------
        private void ComputeIconPositions(int finalSectorCount)
        {
            IconPositions = new Vector2[finalSectorCount];
            float radius = (backgroundImage != null) ? backgroundImage.rectTransform.rect.width * 0.5f : 200f;
            // iconDistanceFactor现在存储的是放大100倍的值，使用时需要缩小100倍
            float dist = radius * (iconDistanceFactor / 100f);
            float sectorAngle = 360f / finalSectorCount;
            
            for (int i = 0; i < finalSectorCount; i++)
            {
                // 中轴角度 = i * sectorAngle （第0扇区中心为 0° 即正北）
                float midAngleDeg = sectorAngle * i;
                float rad = midAngleDeg * Mathf.Deg2Rad;
                // 注意：我们使用与 Update 中一致的坐标系：0° 为正北, 顺时针增加，因此 x = sin, y = cos
                float x = Mathf.Sin(rad) * dist;
                float y = Mathf.Cos(rad) * dist;
                IconPositions[i] = new Vector2(x, y);
            }
            
            Log.DebugMsg(LocalizationHelper.GetFormatted("Log_SectorAngle", finalSectorCount, sectorAngle));
        }
    }
}
