// File: UI/RadialMenu.Input.cs
using System;
using UnityEngine;
using RadialMenu.Logic;
using RadialMenu.Patches;
using RadialMenu.ConfigAndAPI;


namespace RadialMenu.UI
{
    public partial class RadialMenu : MonoBehaviour
    {
        public void ShowMenu()
        {
            if (menuActive) return;
            LastConfirmedSector = -1;
            initialPos = Input.mousePosition;
            if (backgroundImage == null || canvasRect == null || menuRect == null)
            {
                Log.Warn("ShowMenu 时 UI 元素未初始化");
                return;
            }
            float radius = backgroundImage.rectTransform.sizeDelta.x * 0.5f;
            Vector2 pos = initialPos;
            pos.x = Mathf.Clamp(pos.x, radius, Screen.width - radius);
            pos.y = Mathf.Clamp(pos.y, radius, Screen.height - radius);
            RectTransformUtility.ScreenPointToLocalPointInRectangle(canvasRect, pos, null, out Vector2 localPos);
            menuRect.anchoredPosition = localPos;
            menuRect.gameObject.SetActive(true);
            menuActive = true;
            
            // 子弹时间功能：当圆盘菜单显示时，如果配置中启用了子弹时间，则激活子弹时间
            try
            {
                if (RadialMenuSetting.IsBulletTimeEnabled)
                {
                    BulletTimeManager.EnableBulletTime();
                    Log.DebugMsg("圆盘菜单已显示，子弹时间已激活");
                }
            }
            catch (Exception ex)
            {
                Log.Error("启用子弹时间时发生异常", ex);
            }
            
            var positionResult = ComputeIconPositions();
            OnIconPositionsUpdated?.Invoke(IconPositions);
            OnMenuOpened?.Invoke();
            RefreshBindingsAndRenderIcons();
            OnIconPositionsUpdated?.Invoke(IconPositions);
            OnMenuOpened?.Invoke();
        }

        void Update()
        {
            if (!menuActive || menuRect == null) return;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(menuRect, Input.mousePosition, null, out Vector2 local);
            float dist = local.magnitude;
            int newIndex = -1;
            if (dist >= innerDeadRadius && dist <= outerDeadRadius)
            {
                // 与 ComputeIconPositions 保持一致：0° 在正北，顺时针角度递增
                float angle = Mathf.Atan2(local.x, local.y) * Mathf.Rad2Deg;
                if (angle < 0) angle += 360f;
                float sectorAngle = 360f / sectorCount;

                // 将角度向前偏移半个扇区，使扇区范围变为:
                // 对于6扇区: sector0: 330..30, sector1: 30..90, sector2:90..150 等
                // 对于8扇区: sector0: 337.5..22.5, sector1: 22.5..67.5, sector2:67.5..112.5 等
                float shifted = angle + sectorAngle * 0.5f;
                if (shifted >= 360f) shifted -= 360f;
                int sector = Mathf.FloorToInt(shifted / sectorAngle);
                newIndex = sector % sectorCount;
                
                Log.DebugMsg($"[Input] 角度: {angle:F1}°, 扇区角度: {sectorAngle:F1}°, 偏移后: {shifted:F1}°, 选中扇区: {newIndex}");
            }
            if (newIndex != highlightedIndex)
            {
                if (highlightedIndex >= 0 && sectorImages?[highlightedIndex] != null)
                    sectorImages[highlightedIndex].gameObject.SetActive(false);
                if (newIndex >= 0 && sectorImages?[newIndex] != null)
                    sectorImages[newIndex].gameObject.SetActive(true);
                highlightedIndex = newIndex;
                
                // 更新中心文本显示物品名称和数量
                if (iconRenderer != null)
                {
                    try
                    {
                        iconRenderer.UpdateCenterTextForSector(highlightedIndex);
                    }
                    catch (Exception ex)
                    {
                        Log.Error("更新中心文本时发生异常", ex);
                    }
                }
            }
        }

        private void HideMenu()
        {
            // 子弹时间功能：当圆盘菜单关闭时，禁用子弹时间
            try
            {
                if (BulletTimeManager.IsBulletTimeActive)
                {
                    BulletTimeManager.DisableBulletTime();
                    Log.DebugMsg("圆盘菜单已关闭，子弹时间已禁用");
                }
            }
            catch (Exception ex)
            {
                Log.Error("禁用子弹时间时发生异常", ex);
            }
            
            if (menuRect != null) menuRect.gameObject.SetActive(false);
            menuActive = false;
            if (sectorImages != null)
            {
                for (int i = 0; i < sectorImages.Length; i++)
                    if (sectorImages[i] != null) sectorImages[i].gameObject.SetActive(false);
            }
            highlightedIndex = -1;
            IconPositions = Array.Empty<Vector2>();
            if (iconRenderer != null)
            {
                try {
                    iconRenderer.ClearAllIcons();
                    // 清空中心文本显示
                    iconRenderer.UpdateCenterTextForSector(-1);
                }
                catch (Exception ex) { Log.Error("HideMenu 清理失败", ex); }
            }
            OnMenuClosed?.Invoke();
        }

        public void CancelSelection()
        {
            if (!menuActive) return;
            LastConfirmedSector = -1;
            HideMenu();
        }
    }
}