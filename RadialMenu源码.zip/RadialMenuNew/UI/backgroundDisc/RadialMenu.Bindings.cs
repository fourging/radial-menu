// File: UI/RadialMenu.Bindings.cs
using System;
using System.Collections.Generic;
using UnityEngine;
using RadialMenu.Logic;
using RadialMenu.Logic.Utils;
using ItemStatsSystem;
using Duckov.UI;
using RadialMenu.Patches;

namespace RadialMenu.UI
{
    public partial class RadialMenu : MonoBehaviour
    {
        // 使用：不再依赖 binding.item（不稳定），而是使用 binding.itemId (TypeID) 去 InventoryHelper 中查找运行时 Item，然后使用之
        public void HandleRelease()
        {
            if (!menuActive) return;
            if (highlightedIndex >= 0)
            {
                LastConfirmedSector = highlightedIndex;
                try
                {
                    // 判断是否为“绑定模式”（来自 LootView 且玩家选中了一个物品）
                    bool isBindingMode = (View.ActiveView is LootView) && (ItemUIUtilities.SelectedItem != null);

                    if (isBindingMode)
                    {
                        var selected = ItemUIUtilities.SelectedItem;
                        if (selected == null)
                        {
                            Log.Warn("绑定模式下未检测到选中物品，终止绑定。");
                            speakup.ShowDialogue(LocalizationHelper.Get("Input_SelectItemFirst"), CharacterMainControl.Main.transform, 2f);
                            HideMenu();
                            return;
                        }

                        try
                        {
                            // 在绑定物品时关闭物品详情页面
                            int closedCount = UIHelper.CloseAllItemDetailsWindows();
                            if (closedCount > 0)
                            {
                                Log.Info($"[RadialMenu] 绑定物品时自动关闭了 {closedCount} 个物品详情页面");
                            }

                            // 这里将 TypeID 转成 string 传入
                            bool saved = TrySaveBindingViaReflection(highlightedIndex, selected.TypeID.ToString());

                            if (saved)
                            {
                                speakup.ShowDialogue(LocalizationHelper.GetFormatted("Binding_Success", selected.DisplayName), CharacterMainControl.Main.transform, 2f);
                            }
                            else
                            {
                                Log.Warn("未能直接写入绑定（反射未找到合适方法）。请在 BindingManagerdata 中实现 SetBindingForSector(int, string) 或等价方法。");
                                Log.DebugMsg($"已在扇区 {highlightedIndex} 选择：{selected.DisplayName}（若未保存请检查 BindingManagerdata）");
                                speakup.ShowDialogue(LocalizationHelper.GetFormatted("Binding_Success_Short", selected.DisplayName), CharacterMainControl.Main.transform, duration: 1f);
                            }
                        }
                        catch (Exception ex)
                        {
                            Log.Error("绑定物品到扇区时发生异常", ex);
                            speakup.ShowDialogue(LocalizationHelper.GetFormatted("Binding_Failed", ex.Message), CharacterMainControl.Main.transform, 2f);
                        }

                        OnSectorConfirmed?.Invoke(highlightedIndex);
                        HideMenu();
                        return;
                    }


                    // 非绑定模式：仍走“读取扇区绑定并尝试使用物品”的逻辑
                    BindingEntry? binding = null;
                    try { binding = BindingQueries.GetBindingForSector(highlightedIndex); }
                    catch (Exception ex) { Log.Error($"获取扇区绑定异常（sector={highlightedIndex}）", ex); }

                    if (binding == null || string.IsNullOrEmpty(binding.itemId))
                    {
                        Log.Info($"扇区 {highlightedIndex} 未绑定任何物品（或 TypeID 为空）。");
                    }
                    else
                    {
                        // 通过 binding.itemId (TypeID) 在玩家和宠物的物品中查找运行时 Item
                        Item? foundItem = FindRuntimeItemByTypeId(binding.itemId);
                        if (foundItem == null)
                        {
                            Log.Warn($"未在玩家/宠物物品中找到 TypeID={binding.itemId} 对应的运行时物品（扇区 {highlightedIndex}）。");
                        }
                        else
                        {
                            var item = foundItem;
                            _lastUsedBinding = binding;
                            _lastUsedItem = item;
                            _lastUsedSectorIndex = highlightedIndex;

                            bool isExplosive = false;
                            try
                            {
                                if (item.Tags != null)
                                {
                                    try
                                    {
                                        if (item.Tags is IList<string> strList) isExplosive = strList.Contains("Explosive");
                                        else
                                        {
                                            foreach (var t in item.Tags)
                                            {
                                                if (t != null && t.ToString() == "Explosive") { isExplosive = true; break; }
                                            }
                                        }
                                    }
                                    catch
                                    {
                                        foreach (var t in item.Tags)
                                        {
                                            if (t != null && t.ToString().Equals("Explosive", StringComparison.OrdinalIgnoreCase)) { isExplosive = true; break; }
                                        }
                                    }
                                }
                            }
                            catch (Exception ex) { Log.Warn($"读取物品 Tags 异常（{item?.DisplayName}）", ex); }

                            bool used = false;
                            try
                            {
                                if (item != null)
                                {
                                    // 调用使用函数，并把结果赋给 used
                                    bool result = ItemUseController.UseItem(item);
                                    used = result;

                                    if (result && (!item.DisplayName.Contains("急救箱")))
                                    {
                                        int Surplusnum = ItemCounter.CountItemsByTypeID(item.TypeID) - 1;
                                        speakup.ShowDialogue(LocalizationHelper.GetFormatted("UI_ItemCount", Surplusnum), CharacterMainControl.Main.transform, 2f, duration:1f);
                                    }
                                }
                                else
                                {
                                    Log.Warn("HandleRelease 中 item 为 null，跳过 UseItem 调用");
                                }
                            }
                            catch (Exception ex)
                            {
                                if (!used && item != null) Log.Error($"使用物品异常：{item.DisplayName}", ex);
                                used = false;
                            }

                            if (!used && item != null) Log.Warn($"使用失败：{item.DisplayName}");
                        }
                    }
                }
                catch (Exception ex) { Log.Error("HandleRelease 异常", ex); }
                OnSectorConfirmed?.Invoke(highlightedIndex);
            }
            HideMenu();
        }

        /// <summary>
        /// 通过反射尝试调用 BindingManagerdata 的若干常见写入绑定方法。
        /// 返回 true 表示找到了合适方法并调用成功；false 表示没有找到或调用失败（错误已记录）。
        /// 该方法尽量兼容常见签名：SetBindingForSector(int,string) 或 SetBindingForSector(int, BindingEntry) 或 SetBinding(int,string) 等。
        /// </summary>
        private bool TrySaveBindingViaReflection(int sectorIndex, string typeId)
        {
            try
            {
                var bmType = typeof(BindingManager);

                // 优先尝试 SetBindingForSector(int, string)
                var m = bmType.GetMethod("SetBindingForSector", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static, null, new Type[] { typeof(int), typeof(string) }, null);
                if (m != null)
                {
                    m.Invoke(null, new object[] { sectorIndex, typeId });
                    return true;
                }

                // 若有 SetBindingForSector(int, BindingEntry)
                m = bmType.GetMethod("SetBindingForSector", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static);
                if (m != null)
                {
                    var ps = m.GetParameters();
                    if (ps.Length == 2 && ps[0].ParameterType == typeof(int))
                    {
                        var secondType = ps[1].ParameterType;
                        // 创建实例并设置 itemId 字段/属性 (宽容处理)
                        var be = Activator.CreateInstance(secondType);
                        var f = secondType.GetField("itemId", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance);
                        if (f != null) f.SetValue(be, typeId);
                        else
                        {
                            var p = secondType.GetProperty("itemId", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance);
                            if (p != null && p.CanWrite) p.SetValue(be, typeId);
                            else
                            {
                                // 暂不支持更复杂的 BindingEntry 构造方式
                                Log.Warn("反射构造 BindingEntry 失败：未找到 itemId 字段或属性");
                                return false;
                            }
                        }
                        m.Invoke(null, new object[] { sectorIndex, be });
                        return true;
                    }
                }

                // 备选常见方法名
                string[] altNames = new[] { "SetBinding", "BindSector", "AssignBinding", "UpdateBindingForSector", "SaveBindingForSector", "SaveBinding" };
                foreach (var name in altNames)
                {
                    var mm = bmType.GetMethod(name, System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static);
                    if (mm == null) continue;
                    var ps = mm.GetParameters();
                    if (ps.Length == 2 && ps[0].ParameterType == typeof(int) && ps[1].ParameterType == typeof(string))
                    {
                        mm.Invoke(null, new object[] { sectorIndex, typeId });
                        return true;
                    }
                    // 如果第二个参数是 BindingEntry，像上面一样尝试构造
                    if (ps.Length == 2 && ps[0].ParameterType == typeof(int))
                    {
                        var entryType = ps[1].ParameterType;
                        var be = Activator.CreateInstance(entryType);
                        var f = entryType.GetField("itemId", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance);
                        if (f != null) f.SetValue(be, typeId);
                        else
                        {
                            var p = entryType.GetProperty("itemId", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance);
                            if (p != null && p.CanWrite) p.SetValue(be, typeId);
                            else continue;
                        }
                        mm.Invoke(null, new object[] { sectorIndex, be });
                        return true;
                    }
                }

                // 没找到任何可用方法
                return false;
            }
            catch (Exception ex)
            {
                Log.Error("TrySaveBindingViaReflection 异常", ex);
                return false;
            }
        }

        public void QuickUseLastItem()
        {
            // 现在优先使用缓存的 runtime item；若为 null 则尝试基于最后保存的 Binding 的 TypeID 恢复运行时 Item
            try
            {
                if (_lastUsedItem != null)
                {
                    bool result = ItemUseController.UseItem(_lastUsedItem);
                    if (result && (!_lastUsedItem.DisplayName.Contains("急救箱")))
                        {
                        int Surplusnum = ItemCounter.CountItemsByTypeID(_lastUsedItem.TypeID) - 1;
                            if (Surplusnum<0)
                            {
                            speakup.ShowRandomDialogue(
                            CharacterMainControl.Main.transform,
                            0f,
                            LocalizationHelper.Get("Item_NoMoreItems_1"),
                            LocalizationHelper.Get("Item_NoMoreItems_2"),
                            LocalizationHelper.Get("Item_NoMoreItems_3"),
                            LocalizationHelper.Get("Item_NoMoreItems_4"),
                            LocalizationHelper.Get("Item_NoMoreItems_5"),
                            LocalizationHelper.Get("Item_NoMoreItems_6")
                            );
                            return;
                            }
                            speakup.ShowDialogue(LocalizationHelper.GetFormatted("Item_RemainingCount", Surplusnum), CharacterMainControl.Main.transform, 2f, duration:1f);
                        }
                        else
                        {
                            Log.Warn($"使用失败：{_lastUsedItem.DisplayName}");
                        }
                    return;
                }

                if (_lastUsedBinding != null && !string.IsNullOrEmpty(_lastUsedBinding.itemId))
                {
                    var found = FindRuntimeItemByTypeId(_lastUsedBinding.itemId);
                    if (found != null)
                    {
                        _lastUsedItem = found;
                        bool result = ItemUseController.UseItem(_lastUsedItem);
                        if (result && (!_lastUsedItem.DisplayName.Contains("急救箱")))
                        {
                            int Surplusnum = ItemCounter.CountItemsByTypeID(_lastUsedItem.TypeID) - 1;
                            speakup.ShowDialogue(LocalizationHelper.GetFormatted("UI_ItemCount", Surplusnum), CharacterMainControl.Main.transform, 2f, duration: 1f);
                        }
                        else
                        {
                            Log.Warn($"使用失败：{_lastUsedItem.DisplayName}");
                        }
                        return;
                    }
                }             
                speakup.ShowRandomDialogue
                (CharacterMainControl.Main.transform,
                0f,
                LocalizationHelper.Get("Item_NoMoreItems_1"),
                LocalizationHelper.Get("Item_NoMoreItems_2"),
                LocalizationHelper.Get("Item_NoMoreItems_3"),
                LocalizationHelper.Get("Item_NoMoreItems_4"),
                LocalizationHelper.Get("Item_NoMoreItems_5"),
                LocalizationHelper.Get("Item_NoMoreItems_6")
                );
                Log.Warn("无上一次物品缓存或无法在背包中恢复该物品");
            }
            catch (Exception ex) { Log.Error("QuickUseLastItem 异常", ex); }
        }

        // 放到 RadialMenu 类里
        // RadialMenu.cs 中：替换之前尝试调用 SetIconForSector 的方法
        public void RefreshBindingsAndRenderIcons()
        {
            try
            {
                if (iconRenderer == null)
                {
                    Log.DebugMsg("[RadialMenu] RefreshBindingsAndRenderIcons: iconRenderer 为空，跳过");
                    return;
                }

                // 更新布局（传入最新的 IconPositions / perIconOffsets / iconPixelSize）
                iconRenderer.UpdateLayout(IconPositions, perIconOffsets ?? Array.Empty<Vector2>(), iconSize);

                // 让 renderer 自己去读取 BindingManagerdata 并渲染图标
                iconRenderer.RenderAllIcons();
            }
            catch (Exception ex)
            {
                Log.Error("[RadialMenu] RefreshBindingsAndRenderIcons 异常", ex);
            }
        }
    }
}