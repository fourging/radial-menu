// File: UI/RadialMenu.IconPositions.cs
using System;
using UnityEngine;
using RadialMenu.Logic;

namespace RadialMenu.UI
{
    /// <summary>
    /// 图标位置计算结果，包含图标位置数组和圆心坐标
    /// </summary>
    public struct IconPositionResult
    {
        public Vector2[] IconPositions;
        public Vector2 CenterPosition;
        
        public IconPositionResult(Vector2[] iconPositions, Vector2 centerPosition)
        {
            IconPositions = iconPositions;
            CenterPosition = centerPosition;
        }
    }

    public partial class RadialMenu : MonoBehaviour
    {
        // 关键改动：计算每个扇区中轴线角度为 i * sectorAngle （0°, 60°, 120°...）
        // 并以正北为 0°，顺时针增加（与 Update 中的角度计算一致）
        private IconPositionResult ComputeIconPositions()
        {
            if (menuRect == null || backgroundImage == null)
            {
                IconPositions = Array.Empty<Vector2>();
                return new IconPositionResult(IconPositions, Vector2.zero);
            }
            int count = Math.Max(1, sectorCount);
            IconPositions = new Vector2[count];
            float baseRadius = backgroundImage.rectTransform.rect.width * 0.5f;
            // iconDistanceFactor现在存储的是放大100倍的值，使用时需要缩小100倍
            float iconDistance = baseRadius * (iconDistanceFactor / 100f);
            float sectorAngle = 360f / count;
            
            // 圆心坐标为菜单矩形的中心点
            Vector2 centerPos = Vector2.zero;
            
            for (int i = 0; i < count; i++)
            {
                // 中轴角度 = i * sectorAngle （第0扇区中心为 0° 即正北）
                float midAngleDeg = sectorAngle * i;
                float rad = midAngleDeg * Mathf.Deg2Rad;
                // 注意：我们使用与 Update 中一致的坐标系：0° 为正北, 顺时针增加，因此 x = sin, y = cos
                float x = Mathf.Sin(rad) * iconDistance;
                float y = Mathf.Cos(rad) * iconDistance;
                IconPositions[i] = new Vector2(x, y);
            }
            
            Log.DebugMsg($"[ComputeIconPositions] 计算了 {count} 个扇区的图标位置，每个扇区角度: {sectorAngle}°");
            
            return new IconPositionResult(IconPositions, centerPos);
        }

        public Vector2[] GetIconScreenPositions(Camera uiCamera = null)
        {
            if (menuRect == null || IconPositions == null || IconPositions.Length == 0) return Array.Empty<Vector2>();
            Vector2[] screenPositions = new Vector2[IconPositions.Length];
            for (int i = 0; i < IconPositions.Length; i++)
            {
                Vector3 worldPos = menuRect.TransformPoint(IconPositions[i]);
                screenPositions[i] = RectTransformUtility.WorldToScreenPoint(uiCamera, worldPos);
            }
            return screenPositions;
        }

        /// <summary>
        /// 获取圆心的屏幕坐标
        /// </summary>
        /// <param name="uiCamera">UI相机</param>
        /// <returns>圆心的屏幕坐标</returns>
        public Vector2 GetCenterScreenPosition(Camera uiCamera = null)
        {
            if (menuRect == null) return Vector2.zero;
            Vector3 worldPos = menuRect.TransformPoint(Vector2.zero);
            return RectTransformUtility.WorldToScreenPoint(uiCamera, worldPos);
        }

        /// <summary>
        /// 获取包含图标位置和圆心位置的完整结果
        /// </summary>
        /// <param name="uiCamera">UI相机</param>
        /// <returns>包含图标屏幕位置和圆心屏幕位置的结果</returns>
        public (Vector2[] iconPositions, Vector2 centerPosition) GetIconAndCenterScreenPositions(Camera uiCamera = null)
        {
            Vector2[] iconPos = GetIconScreenPositions(uiCamera);
            Vector2 centerPos = GetCenterScreenPosition(uiCamera);
            return (iconPos, centerPos);
        }
    }
}