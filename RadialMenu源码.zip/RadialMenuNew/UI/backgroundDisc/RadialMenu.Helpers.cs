// File: UI/RadialMenu.Helpers.cs
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.IO;
using UnityEngine;
using RadialMenu.Logic;
using ItemStatsSystem;

namespace RadialMenu.UI
{
    public partial class RadialMenu : MonoBehaviour
    {
        // ---------- 占位：加载纹理（保留你原有实现） ----------
        public Texture2D LoadTexture(string path)
        {
            // 尝试读取文件并创建 Texture2D（简单实现）
            try
            {
                if (!File.Exists(path))
                    throw new FileNotFoundException($"Texture not found: {path}");

                byte[] bytes = File.ReadAllBytes(path);
                Texture2D tex = new Texture2D(2, 2);
                tex.LoadImage(bytes);
                return tex;
            }
            catch (Exception ex)
            {
                Log.Warn("LoadTexture failed: " + ex.Message);
                // 返回一个 64x64 的占位纹理，避免空引用
                Texture2D fallback = new Texture2D(64, 64);
                var col = new Color32[64 * 64];
                for (int i = 0; i < col.Length; i++) col[i] = new Color32(255, 0, 255, 255);
                fallback.SetPixels32(col);
                fallback.Apply();
                return fallback;
            }
        }

        /// <summary>
        /// 创建占位纹理（当无法加载真实纹理时使用）
        /// </summary>
        /// <returns>64x64的紫色占位纹理</returns>
        public static Texture2D CreatePlaceholderTexture()
        {
            Texture2D fallback = new Texture2D(64, 64);
            var col = new Color32[64 * 64];
            for (int i = 0; i < col.Length; i++) col[i] = new Color32(255, 0, 255, 255);
            fallback.SetPixels32(col);
            fallback.Apply();
            return fallback;
        }

        
        // -------------------- 辅助：在 InventoryHelper 中查找第一个匹配 typeId 的 runtime Item --------------------
        // 返回第一个匹配的 Item（优先玩家物品顺序，由 InventoryHelper 决定）
        private Item? FindRuntimeItemByTypeId(string typeId)
        {
            try
            {
                IEnumerable itemsRaw;
                try
                {
                    itemsRaw = InventoryHelper.GetPlayerAndPetItems();
                }
                catch (Exception ex)
                {
                    Log.Error("[RadialMenu] 调用 InventoryHelper.GetPlayerAndPetItems() 失败", ex);
                    return null;
                }

                if (itemsRaw == null) return null;

                // 将原始结果展开为 Item 列表（兼容不同的返回结构）
                var allItems = new List<Item>();
                foreach (var entry in itemsRaw)
                {
                    ExtractItemsFromEntry(entry, allItems);
                }

                // 尝试匹配 typeId（字符串直接比较）
                foreach (var it in allItems)
                {
                    string tid = GetItemTypeIdAsString(it);
                    if (string.IsNullOrEmpty(tid)) continue;
                    if (tid == typeId) return it;
                }

                // 兜底：尝试按 DisplayName 匹配（如果 typeId 看起来是名字）
                foreach (var it in allItems)
                {
                    try
                    {
                        if (!string.IsNullOrEmpty(it.DisplayName) && it.DisplayName.Equals(typeId, StringComparison.OrdinalIgnoreCase))
                            return it;
                    }
                    catch { }
                }

                return null;
            }
            catch (Exception ex)
            {
                Log.Error("[RadialMenu] FindRuntimeItemByTypeId 异常", ex);
                return null;
            }
        }

        // ExtractItemsFromEntry：把 InventoryHelper 返回的 entry 各种可能类型展开为 Item 并加入 collector
        private static void ExtractItemsFromEntry(object entry, List<Item> collector)
        {
            if (entry == null) return;

            // 如果直接是 Item
            if (entry is Item item)
            {
                collector.Add(item);
                // 展开内部嵌套（Inventory / Slots）以保证不漏子物品
                try
                {
                    foreach (var i in GetAllNestedItemsSafe(item))
                    {
                        if (i != null && !collector.Contains(i)) collector.Add(i);
                    }
                }
                catch { }
                return;
            }

            // 如果 entry 是 IEnumerable（但不是 string），遍历其元素
            if (entry is IEnumerable enumerable && !(entry is string))
            {
                foreach (var e in enumerable)
                {
                    try { ExtractItemsFromEntry(e, collector); } catch { }
                }
                return;
            }

            // 尝试通过常用属性/字段提取 Item（Item / item / Value / Item1）
            var t = entry.GetType();
            PropertyInfo? prop = t.GetProperty("Item") ?? t.GetProperty("item") ?? t.GetProperty("Value");
            if (prop != null)
            {
                try
                {
                    var v = prop.GetValue(entry);
                    ExtractItemsFromEntry(v, collector);
                    return;
                }
                catch { }
            }
            FieldInfo? fld = t.GetField("Item") ?? t.GetField("item") ?? t.GetField("Item1") ?? t.GetField("Value");
            if (fld != null)
            {
                try
                {
                    var v = fld.GetValue(entry);
                    ExtractItemsFromEntry(v, collector);
                    return;
                }
                catch { }
            }

            // 最后：扫描所有 public 属性/字段，找到第一个 Item 或 IEnumerable 并处理（健壮）
            foreach (var p in t.GetProperties(BindingFlags.Public | BindingFlags.Instance))
            {
                if (typeof(Item).IsAssignableFrom(p.PropertyType))
                {
                    try
                    {
                        var v = p.GetValue(entry) as Item;
                        if (v != null) { ExtractItemsFromEntry(v, collector); return; }
                    }
                    catch { }
                }
                else if (typeof(IEnumerable).IsAssignableFrom(p.PropertyType) && p.PropertyType != typeof(string))
                {
                    try
                    {
                        var v = p.GetValue(entry) as IEnumerable;
                        if (v != null) { ExtractItemsFromEntry(v, collector); return; }
                    }
                    catch { }
                }
            }
            foreach (var f in t.GetFields(BindingFlags.Public | BindingFlags.Instance))
            {
                if (typeof(Item).IsAssignableFrom(f.FieldType))
                {
                    try
                    {
                        var v = f.GetValue(entry) as Item;
                        if (v != null) { ExtractItemsFromEntry(v, collector); return; }
                    }
                    catch { }
                }
                else if (typeof(IEnumerable).IsAssignableFrom(f.FieldType) && f.FieldType != typeof(string))
                {
                    try
                    {
                        var v = f.GetValue(entry) as IEnumerable;
                        if (v != null) { ExtractItemsFromEntry(v, collector); return; }
                    }
                    catch { }
                }
            }
        }

        
        
        // 试图获取 Item 的 TypeID 字符串（反射兼容）
        private static string GetItemTypeIdAsString(Item item)
        {
            if (item == null) return "";
            try
            {
                var t = item.GetType();
                var prop = t.GetProperty("TypeID", BindingFlags.Public | BindingFlags.Instance);
                if (prop != null)
                {
                    var v = prop.GetValue(item);
                    if (v != null) return v.ToString();
                }
                var fld = t.GetField("TypeID", BindingFlags.Public | BindingFlags.Instance);
                if (fld != null)
                {
                    var v = fld.GetValue(item);
                    if (v != null) return v.ToString();
                }

                // 兜底 DisplayName
                if (!string.IsNullOrEmpty(item.DisplayName)) return item.DisplayName;
            }
            catch (Exception ex)
            {
                Log.Error("[RadialMenu] GetItemTypeIdAsString 反射失败", ex);
            }
            return "";
        }

        // GetAllNestedItemsSafe：安全地展开 item 的嵌套内容为 IEnumerable<Item>
        // 注意：这个方法不在 try/catch 中直接 yield（避免 CS1626），而是先收集再返回迭代
        private static IEnumerable<Item> GetAllNestedItemsSafe(Item root)
        {
            var results = new List<Item>();
            if (root == null) return results;

            // 尝试反射调用 InventoryHelper.GetAllNestedItems（如果可用）
            try
            {
                var invHelperType = typeof(InventoryHelper);
                var mi = invHelperType.GetMethod("GetAllNestedItems", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Public);
                if (mi != null)
                {
                    object res = null;
                    try
                    {
                        res = mi.Invoke(null, new object[] { root, null });
                    }
                    catch { res = null; }

                    if (res is IEnumerable<Item> colItems)
                    {
                        results.AddRange(colItems);
                        return results;
                    }
                    if (res is IEnumerable colEnum)
                    {
                        foreach (var o in colEnum)
                        {
                            if (o is Item it) results.Add(it);
                        }
                        if (results.Count > 0) return results;
                    }
                }
            }
            catch { /* 忽略，使用备用展开 */ }

            // 备用：显式 DFS 展开 Inventory 和 Slots（避免在 try/catch 中 yield）
            try
            {
                var visited = new HashSet<Item>();
                var stack = new Stack<Item>();
                stack.Push(root);
                while (stack.Count > 0)
                {
                    var cur = stack.Pop();
                    if (cur == null || visited.Contains(cur)) continue;
                    visited.Add(cur);
                    results.Add(cur);

                    try
                    {
                        if (cur.Inventory != null)
                        {
                            foreach (var nested in cur.Inventory)
                            {
                                if (nested != null && !visited.Contains(nested)) stack.Push(nested);
                            }
                        }
                    }
                    catch { }

                    try
                    {
                        if (cur.Slots != null)
                        {
                            foreach (var slot in cur.Slots)
                            {
                                if (slot?.Content != null && !visited.Contains(slot.Content)) stack.Push(slot.Content);
                            }
                        }
                    }
                    catch { }
                }
            }
            catch { /* 最终兜底 */ }

            return results;
        }
    }
}