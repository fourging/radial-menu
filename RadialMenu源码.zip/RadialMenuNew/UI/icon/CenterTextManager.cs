// File: RadialMenu/UI/CenterTextManager.cs
// ---------------------------------------------------------------------------
// 本文件负责管理中心文本显示
// ---------------------------------------------------------------------------

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;
using ItemStatsSystem;
using RadialMenu.Logic;
using RadialMenu.Patches;
using RadialMenu.ConfigAndAPI;

namespace RadialMenu.UI
{
    /// <summary>
    /// 管理中心文本显示
    /// </summary>
    public class CenterTextManager
    {
        private readonly Text centerNameText;
        private readonly Text centerCountText;
        
        public CenterTextManager(Text centerNameText, Text centerCountText)
        {
            this.centerNameText = centerNameText ?? throw new ArgumentNullException(nameof(centerNameText));
            this.centerCountText = centerCountText ?? throw new ArgumentNullException(nameof(centerCountText));
        }

        /// <summary>
        /// 根据当前扇区数量和用户设置，获取实际应该使用的扇区索引
        /// </summary>
        /// <param name="userSelectedSector">用户选择的扇区索引（0-7）</param>
        /// <param name="currentSectorCount">当前扇区数量（6或8）</param>
        /// <returns>实际应该使用的扇区索引（0-5或0-7）</returns>
        private static int GetActualFoodBindSectorIndex(int userSelectedSector, int currentSectorCount)
        {
            // 检查索引是否在当前扇区数量范围内
            if (userSelectedSector >= currentSectorCount)
            {
                // 如果超出了范围，则使用0号扇区（即显示的1号扇区）
                Log.DebugMsg($"用户选择的扇区索引{userSelectedSector}超出了当前扇区数量{currentSectorCount}，回退到0号扇区");
                return 0;
            }
            
            return userSelectedSector;
        }
        
        /// <summary>
        /// 更新圆盘中心的物品名称和数量显示
        /// </summary>
        /// <param name="itemName">物品名称</param>
        /// <param name="count">物品数量</param>
        public void UpdateCenterText(string itemName, int count)
        {
            if (centerNameText != null && centerCountText != null)
            {
                // 显示物品名称，如果名称为空则不显示
                if (!string.IsNullOrEmpty(itemName))
                {
                    centerNameText.text = itemName;
                    centerNameText.gameObject.SetActive(true);
                    
                    // 计算中心字符的位置，使其对齐到圆盘中心
                    CalculateCenterCharacterPosition(centerNameText, itemName);
                }
                else
                {
                    centerNameText.gameObject.SetActive(false);
                }

                // 显示物品数量，只有数量大于1时才显示
                if (count > 1)
                {
                    centerCountText.text = LocalizationHelper.GetFormatted("UI_ItemCount", count);
                    centerCountText.gameObject.SetActive(true);
                }
                else if (count == 1)
                {
                    centerCountText.text = LocalizationHelper.GetFormatted("UI_ItemCount", 1);
                    centerCountText.gameObject.SetActive(true);
                }
                else
                {
                    centerCountText.gameObject.SetActive(false);
                }
            }
        }
        
        /// <summary>
        /// 计算文本中心字符的位置，使其对齐到圆盘中心
        /// 特别处理中文文本的居中问题，使用精确的字符宽度计算
        /// </summary>
        /// <param name="textComponent">文本组件</param>
        /// <param name="text">显示的文本</param>
        private void CalculateCenterCharacterPosition(Text textComponent, string text)
        {
            if (textComponent == null || string.IsNullOrEmpty(text)) return;

            var textRT = textComponent.GetComponent<RectTransform>();
            if (textRT == null) return;

            // 由于文本组件已经设置为 TextAnchor.MiddleCenter，
            // 我们只需要确保 RectTransform 的位置在中心点即可
            // 不需要额外的偏移计算，因为 Unity 的 TextAnchor.MiddleCenter 已经处理了居中
            
            // 重置位置到中心，让 TextAnchor.MiddleCenter 处理居中
            textRT.anchoredPosition = Vector2.zero;
            
            Log.DebugMsg($"文本居中计算: '{text}', 使用 TextAnchor.MiddleCenter 自动居中");
        }
        
        /// <summary>
        /// 获取指定字符的精确宽度
        /// 处理 Unity Text.cachedTextGenerator 的字符宽度计算问题
        /// </summary>
        /// <param name="characters">字符信息列表</param>
        /// <param name="charIndex">字符索引</param>
        /// <returns>字符宽度</returns>
        private float GetCharacterWidth(IList<UICharInfo> characters, int charIndex)
        {
            if (characters == null || charIndex < 0 || charIndex >= characters.Count)
                return 0f;
                
            // 获取当前字符的起始位置
            float currentCharStart = characters[charIndex].cursorPos.x;
            
            // 如果不是最后一个字符，使用下一个字符的起始位置减去当前字符的起始位置
            if (charIndex + 1 < characters.Count)
            {
                return characters[charIndex + 1].cursorPos.x - currentCharStart;
            }
            
            // 如果是最后一个字符，使用字符的宽度信息
            // 对于中文字符，通常使用字体大小的比例作为估算
            return characters[charIndex].charWidth > 0 ? characters[charIndex].charWidth : 20f; // 默认宽度
        }
        
        /// <summary>
        /// 获取指定字符的精确宽度（重载版本）
        /// </summary>
        /// <param name="textGenerator">文本生成器</param>
        /// <param name="charIndex">字符索引</param>
        /// <returns>字符宽度</returns>
        private float GetCharacterWidth(TextGenerator textGenerator, int charIndex)
        {
            if (textGenerator == null || charIndex < 0 || charIndex >= textGenerator.characterCountVisible)
                return 0f;
                
            return GetCharacterWidth(textGenerator.characters, charIndex);
        }
        
        /// <summary>
        /// 清空中心文本显示
        /// </summary>
        public void ClearCenterText()
        {
            if (centerNameText != null)
            {
                centerNameText.text = "";
                centerNameText.gameObject.SetActive(false);
            }

            if (centerCountText != null)
            {
                centerCountText.text = "";
                centerCountText.gameObject.SetActive(false);
            }
        }
        
        /// <summary>
        /// 公共方法：根据扇区索引更新中心文本
        /// </summary>
        /// <param name="sectorIndex">扇区索引，-1表示清空文本</param>
        public void UpdateCenterTextForSector(int sectorIndex)
        {
            if (sectorIndex < 0)
            {
                // 鼠标在死区，清空文本
                ClearCenterText();
                return;
            }

            // 获取扇区对应的物品信息
            BindingEntry be = null;
            try
            {
                be = BindingQueries.GetBindingForSector(sectorIndex);
            }
            catch (Exception ex)
            {
                Log.DebugMsg("[CenterTextManager] GetBindingForSector 异常: " + ex);
            }

            string displayName = "";
            int totalCount = 0;

            if (be != null)
            {
                // 有绑定信息，使用绑定的显示名称
                displayName = !string.IsNullOrEmpty(be.displayName) ? be.displayName.Trim() : "";
                
                // 如果没有显示名称，尝试通过itemId获取
                if (string.IsNullOrEmpty(displayName) && !string.IsNullOrEmpty(be.itemId))
                {
                    try
                    {
                        var itemsByType = GetItemsByType();
                        if (itemsByType != null && itemsByType.TryGetValue(be.itemId.Trim(), out var items))
                        {
                            var item = items?.FirstOrDefault();
                            if (item != null && !string.IsNullOrEmpty(item.DisplayName))
                            {
                                displayName = item.DisplayName.Trim();
                            }
                            // 计算数量
                            foreach (var it in items)
                            {
                                int sc = IconRendererHelpers.GetItemStackCount(it);
                                totalCount += (sc > 0 ? sc : 1);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.DebugMsg("[CenterTextManager] 通过itemId获取物品名称异常: " + ex);
                    }
                }
            }
            else
            {
                // 没有绑定信息，尝试获取自动绑定的物品（使用配置中的FoodBindSectors扇区）
                int userSelectedSector = RadialMenuSetting.FoodBindSectors;
                // 假设最大扇区数量为8（这里无法直接获取当前扇区数量，使用最大值）
                int foodBindSector = GetActualFoodBindSectorIndex(userSelectedSector, 8);
                
                if (sectorIndex == foodBindSector)
                {
                    try
                    {
                        var itemsByType = GetItemsByType();
                        if (itemsByType != null)
                        {
                            var matchedItems = FoodBinder.TryBindFoodForSector(itemsByType, sectorIndex, out string boundTypeId, out string displayNameFromBinding);
                            if (matchedItems != null && matchedItems.Count > 0)
                            {
                                displayName = displayNameFromBinding;
                                // 计算数量
                                foreach (var it in matchedItems)
                                {
                                    int sc = IconRendererHelpers.GetItemStackCount(it);
                                    totalCount += (sc > 0 ? sc : 1);
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.DebugMsg("[CenterTextManager] 获取自动绑定食物名称异常: " + ex);
                    }
                }
            }

            if (!string.IsNullOrEmpty(displayName))
            {
                UpdateCenterText(displayName, totalCount);
            }
            else
            {
                ClearCenterText();
            }
        }
        
        /// <summary>
        /// 获取按类型分组的物品字典
        /// </summary>
        private Dictionary<string, List<Item>> GetItemsByType()
        {
            try
            {
                IEnumerable rawEntries = InventoryHelper.GetPlayerAndPetItems();
                if (rawEntries == null) return null;

                var allItemsSet = new HashSet<Item>(IconRendererHelpers.ReferenceEqualityComparer<Item>.Default);
                foreach (var entry in rawEntries)
                {
                    try
                    {
                        IconRendererHelpers.ExtractItemsFromEntry(entry, allItemsSet);
                    }
                    catch (Exception ex)
                    {
                        Log.DebugMsg("[CenterTextManager] ExtractItemsFromEntry 单个 entry 异常: " + ex);
                    }
                }

                var allItems = allItemsSet.ToList();
                var itemsByType = new Dictionary<string, List<Item>>(StringComparer.OrdinalIgnoreCase);
                
                foreach (var it in allItems)
                {
                    string tid = IconRendererHelpers.GetItemTypeIdAsString(it)?.Trim() ?? "";
                    if (string.IsNullOrEmpty(tid))
                    {
                        try { tid = !string.IsNullOrEmpty(it.DisplayName) ? it.DisplayName.Trim() : ""; } catch { tid = ""; }
                        if (string.IsNullOrEmpty(tid)) continue;
                    }
                    if (!itemsByType.TryGetValue(tid, out var list))
                    {
                        list = new List<Item>();
                        itemsByType[tid] = list;
                    }
                    list.Add(it);
                }
                
                return itemsByType;
            }
            catch (Exception ex)
            {
                Log.Error("[CenterTextManager] GetItemsByType 失败", ex);
                return null;
            }
        }
    }
}