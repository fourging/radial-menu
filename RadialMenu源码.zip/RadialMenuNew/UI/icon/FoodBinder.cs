// File: RadialMenu/UI/FoodBinder.cs
using System;
using System.Collections.Generic;
using ItemStatsSystem;  // Item
using RadialMenu.Logic; // BindingManagerdata
using RadialMenu.Patches;
 
namespace RadialMenu.UI
{
    public static class FoodBinder
    {
        /// <summary>
        /// 在指定扇区尝试绑定最低价值的食物
        /// </summary>
        public static List<Item> TryBindFoodForSector(Dictionary<string, List<Item>> itemsByType, int sectorIndex, out string boundTypeId, out string displayNameFromBinding)
        {
            boundTypeId = "";
            displayNameFromBinding = "";
            List<Item> result = null;

            try
            {
                Log.DebugMsg($"未找到扇区 {sectorIndex} 的绑定或绑定无效，尝试查找最低价值食物以显示");
                Item foodItem = FoodFinder.FindTargetFood();
                if (foodItem != null)
                {
                    try { boundTypeId = IconRendererHelpers.GetItemTypeIdAsString(foodItem) ?? ""; } catch { boundTypeId = ""; }
                    try { displayNameFromBinding = !string.IsNullOrEmpty(foodItem.DisplayName) ? foodItem.DisplayName : ""; } catch { displayNameFromBinding = ""; }

                    // 优先使用当前 itemsByType 中的同 typeId 列表（以便返回所有堆叠/同类型实例）
                    if (!string.IsNullOrEmpty(boundTypeId) && itemsByType != null && itemsByType.TryGetValue(boundTypeId, out var foundList) && foundList != null && foundList.Count > 0)
                    {
                        result = new List<Item>(foundList);
                    }
                    else
                    {
                        // 如果在 itemsByType 中没找到（极端情况），回退到只返回 FoodFinder 选中的单个实例
                        result = new List<Item>() { foodItem };
                    }

                    try
                    {
                        // 将此绑定标记为系统自动绑定（autoBound = true）
                        BindingManager.PerformItemBinding(foodItem, sectorIndex, true);

                        if (CharacterMainControl.Main?.transform != null)
                        {
                            speakup.ShowRandomDialogue(
                            CharacterMainControl.Main.transform,
                            0f,
                            LocalizationHelper.GetFormatted("Food_AutoBindSector", sectorIndex, displayNameFromBinding),
                            LocalizationHelper.GetFormatted("Food_PreviousFoodEaten", displayNameFromBinding),
                            LocalizationHelper.GetFormatted("Food_TiredOfOld", displayNameFromBinding),
                            LocalizationHelper.GetFormatted("Food_FoundBetter", displayNameFromBinding),
                            LocalizationHelper.GetFormatted("Food_CheapDelicious", displayNameFromBinding)
                            );
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.DebugMsg("[RadialMenuIconRenderer] PerformItemBinding 自动绑定时异常: " + ex);
                    }
                }
                else
                {
                    Log.DebugMsg("[RadialMenuIconRenderer] FindTargetFood() 未返回任何物品");
                }
            }
            catch (Exception ex)
            {
                Log.DebugMsg("[RadialMenuIconRenderer] 调用 FoodFinder.FindTargetFood() 发生异常: " + ex);
            }

            return result;
        }

        /// <summary>
        /// 在第5扇区尝试绑定最低价值的食物（保留向后兼容性）
        /// </summary>
        public static List<Item> TryBindFoodForSector5(Dictionary<string, List<Item>> itemsByType, out string boundTypeId, out string displayNameFromBinding)
        {
            return TryBindFoodForSector(itemsByType, 5, out boundTypeId, out displayNameFromBinding);
        }
    }
}