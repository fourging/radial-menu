// File: RadialMenu/UI/ResponsiveIconSizer.cs
// ---------------------------------------------------------------------------
// 本文件负责处理响应式图标大小调整
// ---------------------------------------------------------------------------

using UnityEngine;
using RadialMenu.Logic;

namespace RadialMenu.UI
{
    /// <summary>
    /// 处理响应式图标大小调整
    /// </summary>
    public class ResponsiveIconSizer
    {
        private int lastScreenWidth = 0;
        private int lastScreenHeight = 0;
        private readonly float baselineWidth = 1920f;
        private readonly float baselineHeight = 1080f;
        private readonly float iconSizeOn1080 = 118f;
        private readonly float iconSizeOn1440 = 255f;
        private readonly float minIconSize = 50f;
        private readonly float maxIconSize = 500f;
        
        private float currentIconSize;
        private bool responsiveSizing;
        
        public float CurrentIconSize => currentIconSize;
        public bool ResponsiveSizing 
        { 
            get => responsiveSizing; 
            set => responsiveSizing = value; 
        }
        
        public ResponsiveIconSizer(float initialIconSize, bool responsiveSizing = true)
        {
            this.currentIconSize = Mathf.Max(1f, initialIconSize);
            this.responsiveSizing = responsiveSizing;
            
            if (responsiveSizing)
            {
                this.currentIconSize = DetermineIconSizeBasedOnResolution();
            }
            
            lastScreenWidth = Screen.width;
            lastScreenHeight = Screen.height;
        }
        
        /// <summary>
        /// 检查是否需要更新图标大小（在Update中调用）
        /// </summary>
        /// <returns>如果图标大小已更新则返回true</returns>
        public bool CheckAndUpdateIconSize()
        {
            if (!responsiveSizing) return false;
            
            if (Screen.width != lastScreenWidth || Screen.height != lastScreenHeight)
            {
                lastScreenWidth = Screen.width;
                lastScreenHeight = Screen.height;
                float newSize = DetermineIconSizeBasedOnResolution();
                if (!Mathf.Approximately(newSize, currentIconSize))
                {
                    currentIconSize = newSize;
                    return true;
                }
            }
            return false;
        }
        
        /// <summary>
        /// 根据分辨率确定图标大小
        /// </summary>
        /// <returns>计算得到的图标大小</returns>
        private float DetermineIconSizeBasedOnResolution()
        {
            int w = Screen.width;
            int h = Screen.height;
            Log.DebugMsg($"当前分辨率: {w}x{h}");

            bool is1080 = Mathf.Abs(w - 1920) < 40 && Mathf.Abs(h - 1080) < 40;
            bool is1440 = Mathf.Abs(w - 2560) < 40 && Mathf.Abs(h - 1440) < 40;

            if (is1080) return iconSizeOn1080;
            if (is1440) return iconSizeOn1440;

            float scale = Mathf.Min(w / baselineWidth, h / baselineHeight);
            float candidate = iconSizeOn1080 * scale;
            return Mathf.Clamp(candidate, minIconSize, maxIconSize);
        }
        
        /// <summary>
        /// 手动设置图标大小
        /// </summary>
        /// <param name="newSize">新的图标大小</param>
        public void SetIconSize(float newSize)
        {
            currentIconSize = Mathf.Max(1f, newSize);
        }
        
        /// <summary>
        /// 强制重新计算图标大小（基于当前分辨率）
        /// </summary>
        public void RecalculateIconSize()
        {
            if (responsiveSizing)
            {
                currentIconSize = DetermineIconSizeBasedOnResolution();
            }
        }
    }
}