// File: RadialMenu/UI/IconRendererCore.cs
// ---------------------------------------------------------------------------
// 本文件负责核心渲染逻辑
// ---------------------------------------------------------------------------

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;
using ItemStatsSystem;
using RadialMenu.Logic;
using RadialMenu.Patches;
using RadialMenu.ConfigAndAPI;

namespace RadialMenu.UI
{
    /// <summary>
    /// 核心渲染逻辑
    /// </summary>
    public class IconRendererCore
    {
        private readonly IconContainerManager containerManager;
        private readonly IconPoolManager poolManager;
        private readonly CenterTextManager centerTextManager;
        private readonly ResponsiveIconSizer iconSizer;
        
        private Vector2[] localPositions;
        private Vector2[] perIconOffsets;
        private bool showCount = false;

        /// <summary>
        /// 根据当前扇区数量和用户设置，获取实际应该使用的扇区索引
        /// </summary>
        /// <param name="userSelectedSector">用户选择的扇区索引（0-7）</param>
        /// <param name="currentSectorCount">当前扇区数量（6或8）</param>
        /// <returns>实际应该使用的扇区索引（0-5或0-7）</returns>
        private static int GetActualFoodBindSectorIndex(int userSelectedSector, int currentSectorCount)
        {
            // 检查索引是否在当前扇区数量范围内
            if (userSelectedSector >= currentSectorCount)
            {
                // 如果超出了范围，则使用0号扇区（即显示的1号扇区）
                Log.DebugMsg($"用户选择的扇区索引{userSelectedSector}超出了当前扇区数量{currentSectorCount}，回退到0号扇区");
                return 0;
            }
            
            return userSelectedSector;
        }
        
        public IconRendererCore(
            IconContainerManager containerManager,
            IconPoolManager poolManager,
            CenterTextManager centerTextManager,
            ResponsiveIconSizer iconSizer)
        {
            this.containerManager = containerManager ?? throw new ArgumentNullException(nameof(containerManager));
            this.poolManager = poolManager ?? throw new ArgumentNullException(nameof(poolManager));
            this.centerTextManager = centerTextManager ?? throw new ArgumentNullException(nameof(centerTextManager));
            this.iconSizer = iconSizer ?? throw new ArgumentNullException(nameof(iconSizer));
        }
        
        /// <summary>
        /// 初始化渲染器
        /// </summary>
        /// <param name="localPositions">本地位置数组</param>
        /// <param name="perIconOffsets">每个图标的偏移量</param>
        /// <param name="showCount">是否显示数量</param>
        public void Initialize(Vector2[] localPositions, Vector2[] perIconOffsets = null, bool showCount = false)
        {
            if (localPositions == null) throw new ArgumentNullException(nameof(localPositions));
            
            this.localPositions = localPositions;
            this.perIconOffsets = perIconOffsets;
            this.showCount = showCount;
            
            // 确保容器存在
            containerManager.EnsureContainer();
            containerManager.EnsureCenterTextContainer();
            
            // 预分配图标池
            poolManager.PreallocateIcons(localPositions.Length, iconSizer.CurrentIconSize);
            
            Log.DebugMsg($"[IconRendererCore] 初始化完成. poolSize={poolManager.GetPoolSize()}, iconSize={iconSizer.CurrentIconSize}");
        }
        
        /// <summary>
        /// 渲染所有图标（一次性获取并聚合背包物品）
        /// </summary>
        public void RenderAllIcons()
        {
            if (localPositions == null) return;
            int sectors = localPositions.Length;

            // 初始化时先清空中心文本
            centerTextManager.ClearCenterText();

            IEnumerable rawEntries = null;
            try
            {
                rawEntries = InventoryHelper.GetPlayerAndPetItems();
            }
            catch (Exception ex)
            {
                Log.Error("[IconRendererCore] 调用 InventoryHelper.GetPlayerAndPetItems() 失败", ex);
                poolManager.ClearAllIcons();
                return;
            }

            // 使用 HashSet 去重
            var allItemsSet = new HashSet<Item>(IconRendererHelpers.ReferenceEqualityComparer<Item>.Default);
            if (rawEntries != null)
            {
                foreach (var entry in rawEntries)
                {
                    try
                    {
                        IconRendererHelpers.ExtractItemsFromEntry(entry, allItemsSet);
                    }
                    catch (Exception ex)
                    {
                        Log.DebugMsg("[IconRendererCore] ExtractItemsFromEntry 单个 entry 异常: " + ex);
                    }
                }
            }

            var allItems = allItemsSet.ToList();

            // 构建 TypeID -> items 映射（不区分大小写）
            var itemsByType = new Dictionary<string, List<Item>>(StringComparer.OrdinalIgnoreCase);
            foreach (var it in allItems)
            {
                string tid = IconRendererHelpers.GetItemTypeIdAsString(it)?.Trim() ?? "";
                if (string.IsNullOrEmpty(tid))
                {
                    try { tid = !string.IsNullOrEmpty(it.DisplayName) ? it.DisplayName.Trim() : ""; } catch { tid = ""; }
                    if (string.IsNullOrEmpty(tid)) continue;
                }
                if (!itemsByType.TryGetValue(tid, out var list))
                {
                    list = new List<Item>();
                    itemsByType[tid] = list;
                }
                list.Add(it);
            }

            // 确保图标池大小
            poolManager.PreallocateIcons(sectors, iconSizer.CurrentIconSize);

            // 渲染每个扇区
            for (int i = 0; i < sectors; i++)
            {
                RenderIconForSector_Precomputed(i, itemsByType);
            }

            // 隐藏超出范围的 icon
            poolManager.HideIconsBeyondRange(sectors);
            
            // 确保中心文本容器存在
            containerManager.EnsureCenterTextContainer();
        }
        
        /// <summary>
        /// 为指定扇区渲染预计算的图标
        /// </summary>
        /// <param name="sectorIndex">扇区索引</param>
        /// <param name="itemsByType">按类型ID分组的物品列表字典</param>
        private void RenderIconForSector_Precomputed(int sectorIndex, Dictionary<string, List<Item>> itemsByType)
        {
            // 打印调试信息：当前绘制的图标大小
            Log.DebugMsg($"绘制图标大小: {iconSizer.CurrentIconSize}");

            // 边界检查
            if (localPositions == null) return;
            if (sectorIndex < 0 || sectorIndex >= localPositions.Length) return;

            BindingEntry be = null;
            try
            {
                be = BindingQueries.GetBindingForSector(sectorIndex);
            }
            catch (Exception ex)
            {
                Log.DebugMsg("[IconRendererCore] GetBindingForSector 异常: " + ex);
            }

            List<Item> matchedItems = null;       // 匹配到的物品列表
            string boundTypeId = "";              // 绑定的类型ID
            string displayNameFromBinding = "";   // 从绑定信息中获取的显示名称

            // 处理没有绑定信息的情况
            if (be == null)
            {
                // 使用配置中的FoodBindSectors扇区进行自动绑定食物逻辑
                int userSelectedSector = RadialMenuSetting.FoodBindSectors;
                // 根据当前扇区数量获取实际应该使用的扇区索引
                int foodBindSector = GetActualFoodBindSectorIndex(userSelectedSector, localPositions.Length);
                
                if (sectorIndex == foodBindSector)
                {
                    matchedItems = FoodBinder.TryBindFoodForSector(itemsByType, sectorIndex, out boundTypeId, out displayNameFromBinding);
                }

                if (matchedItems == null || matchedItems.Count == 0)
                {
                    poolManager.HideIcon(sectorIndex);
                    return;
                }
            }
            else
            {
                // 有绑定信息：优先用 itemId 去匹配 itemsByType
                boundTypeId = (be.itemId ?? "").Trim();
                displayNameFromBinding = (!string.IsNullOrEmpty(be.displayName) ? be.displayName.Trim() : "");

                if (string.IsNullOrEmpty(boundTypeId) && string.IsNullOrEmpty(displayNameFromBinding))
                {
                    poolManager.HideIcon(sectorIndex);
                    return;
                }

                // 如果是配置的FoodBindSectors扇区并且绑定是由系统自动绑定（autoBound），尝试检测是否需要替换为更低价值的食物
                int userSelectedSector = RadialMenuSetting.FoodBindSectors;
                // 根据当前扇区数量获取实际应该使用的扇区索引
                int foodBindSector = GetActualFoodBindSectorIndex(userSelectedSector, localPositions.Length);
                
                if (sectorIndex == foodBindSector && be.autoBound)
                {
                    try
                    {
                        var newFood = FoodFinder.FindTargetFood();
                        if (newFood != null)
                        {
                            string newTypeId = "";
                            try { newTypeId = IconRendererHelpers.GetItemTypeIdAsString(newFood) ?? ""; } catch { newTypeId = ""; }
                            string newDisplay = !string.IsNullOrEmpty(newFood.DisplayName) ? newFood.DisplayName.Trim() : "";

                            bool differentByType = !string.IsNullOrEmpty(newTypeId) && !string.Equals(newTypeId, boundTypeId, StringComparison.OrdinalIgnoreCase);
                            bool differentByDisplay = string.IsNullOrEmpty(newTypeId) && !string.IsNullOrEmpty(newDisplay) && !string.Equals(newDisplay, displayNameFromBinding, StringComparison.OrdinalIgnoreCase);

                            if (differentByType || differentByDisplay)
                            {
                                Log.DebugMsg("[IconRendererCore] 第5扇区 autoBound 绑定发现更低价值食物，准备替换绑定：" +
                                            $"旧(Type={boundTypeId}, Name={displayNameFromBinding}) -> 新(Type={newTypeId}, Name={newDisplay})");

                                // 执行自动替换绑定（标记为 autoBound = true）
                                try
                                {
                                    BindingManager.PerformItemBinding(newFood, sectorIndex, true);
                                }
                                catch (Exception ex)
                                {
                                    Log.DebugMsg("[IconRendererCore] 自动替换绑定 PerformItemBinding 抛出异常: " + ex);
                                }

                                // 更新本地标识以便随后匹配 itemsByType
                                boundTypeId = newTypeId;
                                displayNameFromBinding = newDisplay;

                                // *** 新增：替换绑定后也需要提示玩家（当面板被呼出时应看到这条消息）
                                try
                                {
                                    if (CharacterMainControl.Main?.transform != null)
                                    {
                                        Log.DebugMsg("[IconRendererCore] 替换绑定后调用 speakup.ShowDialogue 提示玩家: " + newDisplay);
                                        speakup.ShowRandomDialogue(
                                        CharacterMainControl.Main.transform,
                                        0f,
                                        LocalizationHelper.GetFormatted("Food_AutoBindSector", sectorIndex, displayNameFromBinding),
                                        LocalizationHelper.GetFormatted("Food_PreviousFoodEaten", displayNameFromBinding),
                                        LocalizationHelper.GetFormatted("Food_TiredOfOld", displayNameFromBinding),
                                        LocalizationHelper.GetFormatted("Food_FoundBetter", displayNameFromBinding),
                                        LocalizationHelper.GetFormatted("Food_CheapDelicious", displayNameFromBinding)
                                        );
                                    }                                                         
                                }
                                catch (Exception ex)
                                {
                                    Log.DebugMsg("[IconRendererCore] 替换绑定后调用 speakup.ShowDialogue 异常: " + ex);
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.DebugMsg("[IconRendererCore] 检查/更新第5扇区自动绑定时异常: " + ex);
                    }
                }

                // 通过 typeId 匹配
                try
                {
                    if (!string.IsNullOrEmpty(boundTypeId))
                        itemsByType?.TryGetValue(boundTypeId, out matchedItems);
                }
                catch (Exception ex)
                {
                    Log.DebugMsg("[IconRendererCore] 通过 typeId 匹配时异常: " + ex);
                }

                // 兜底：如果没有通过 typeId 找到，尝试通过 displayName 匹配（忽略大小写）
                if ((matchedItems == null || matchedItems.Count == 0) && !string.IsNullOrEmpty(displayNameFromBinding) && itemsByType != null)
                {
                    foreach (var kv in itemsByType)
                    {
                        foreach (var it in kv.Value)
                        {
                            try
                            {
                                if (!string.IsNullOrEmpty(it.DisplayName) &&
                                    string.Equals(it.DisplayName.Trim(), displayNameFromBinding, StringComparison.OrdinalIgnoreCase))
                                {
                                    matchedItems ??= new List<Item>();
                                    matchedItems.Add(it);
                                }
                            }
                            catch (Exception ex)
                            {
                                Log.DebugMsg("[IconRendererCore] displayName 匹配异常: " + ex);
                            }
                        }
                    }
                }

                // 关键修复：如果绑定存在但是没有匹配到实例，并且是配置的FoodBindSectors扇区，则尝试重新自动绑定食物（覆盖/替换现有绑定）
                if ((matchedItems == null || matchedItems.Count == 0) && sectorIndex == foodBindSector)
                {
                    Log.DebugMsg($"[IconRendererCore] 绑定存在但未匹配到实例，尝试为扇区{sectorIndex}重新自动绑定食物");
                    var fallback = FoodBinder.TryBindFoodForSector(itemsByType, sectorIndex, out boundTypeId, out displayNameFromBinding);
                    if (fallback != null && fallback.Count > 0)
                    {
                        matchedItems = fallback;
                    }
                }

                if (matchedItems == null || matchedItems.Count == 0)
                {
                    poolManager.HideIcon(sectorIndex);
                    return;
                }
            }

            // --- 到此处 matchedItems 至少包含一个物品 ---
            int totalCount = 0;
            Sprite chosenSprite = null;
            string displayNameToUse = displayNameFromBinding;

            foreach (var it in matchedItems)
            {
                try
                {
                    int sc = IconRendererHelpers.GetItemStackCount(it);
                    totalCount += (sc > 0 ? sc : 1);
                    chosenSprite ??= IconRendererHelpers.GetItemSprite(it);

                    if (string.IsNullOrEmpty(displayNameToUse))
                    {
                        if (!string.IsNullOrEmpty(it.DisplayName)) displayNameToUse = it.DisplayName;
                    }
                }
                catch (Exception ex)
                {
                    Log.DebugMsg("[IconRendererCore] 处理 matchedItems 时出错: " + ex);
                }
            }

            if (chosenSprite == null)
            {
                poolManager.HideIcon(sectorIndex);
                return;
            }

            // 获取或预分配图标 entry
            var entry = poolManager.GetOrCreateIconEntry(sectorIndex, iconSizer.CurrentIconSize);

            // 更新 UI
            entry.gameObject.SetActive(true);
            if (entry.image == null) entry.image = entry.gameObject.GetComponent<Image>();
            entry.image.sprite = chosenSprite;
            entry.image.preserveAspect = true;

            entry.rectTransform.sizeDelta = new Vector2(iconSizer.CurrentIconSize, iconSizer.CurrentIconSize);
            Vector2 basePos = localPositions[sectorIndex];
            Vector2 offset = (perIconOffsets != null && sectorIndex < perIconOffsets.Length) ? perIconOffsets[sectorIndex] : Vector2.zero;
            entry.rectTransform.anchoredPosition = basePos + offset;

            if (showCount && entry.countText != null)
            {
                entry.countText.text = totalCount > 1 ? totalCount.ToString() : (totalCount == 1 ? "1" : "");
                entry.countText.gameObject.SetActive(!string.IsNullOrEmpty(entry.countText.text));
            }
            else if (entry.countText != null)
            {
                entry.countText.gameObject.SetActive(false);
            }

            Log.DebugMsg($"开始统计物品：{displayNameToUse}（TypeID={boundTypeId}），当前匹配数量: {matchedItems.Count}，堆叠总数: {totalCount}");
        }
        
        /// <summary>
        /// 更新布局
        /// </summary>
        /// <param name="newLocalPositions">新的本地位置数组</param>
        /// <param name="newPerIconOffsets">新的每个图标偏移量</param>
        /// <param name="newIconSize">新的图标大小</param>
        public void UpdateLayout(Vector2[] newLocalPositions = null, Vector2[] newPerIconOffsets = null, float? newIconSize = null)
        {
            if (newLocalPositions != null) localPositions = newLocalPositions;
            if (newPerIconOffsets != null) perIconOffsets = newPerIconOffsets;
            if (newIconSize.HasValue) iconSizer.SetIconSize(newIconSize.Value);
            
            poolManager.UpdateLayout(localPositions, perIconOffsets, iconSizer.CurrentIconSize);
        }
        
        /// <summary>
        /// 清空所有图标
        /// </summary>
        public void ClearAllIcons()
        {
            poolManager.ClearAllIcons();
            centerTextManager.ClearCenterText();
        }
        
        /// <summary>
        /// 根据扇区索引更新中心文本
        /// </summary>
        /// <param name="sectorIndex">扇区索引，-1表示清空文本</param>
        public void UpdateCenterTextForSector(int sectorIndex)
        {
            centerTextManager.UpdateCenterTextForSector(sectorIndex);
        }
        
        /// <summary>
        /// 检查并更新图标大小（在Update中调用）
        /// </summary>
        /// <returns>如果图标大小已更新则返回true</returns>
        public bool CheckAndUpdateIconSize()
        {
            if (iconSizer.CheckAndUpdateIconSize())
            {
                UpdateLayout(null, null, iconSizer.CurrentIconSize);
                return true;
            }
            return false;
        }
    }
}