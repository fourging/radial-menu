// File: RadialMenu/UI/IconPoolManager.cs
// ---------------------------------------------------------------------------
// 本文件负责管理图标池和图标预分配
// ---------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace RadialMenu.UI
{
    /// <summary>
    /// 管理图标池和图标预分配
    /// </summary>
    public class IconPoolManager
    {
        private readonly Dictionary<int, IconEntry> iconPool = new Dictionary<int, IconEntry>();
        private readonly RectTransform containerRT;
        
        public IconPoolManager(RectTransform containerRT)
        {
            this.containerRT = containerRT ?? throw new System.ArgumentNullException(nameof(containerRT));
        }
        
        /// <summary>
        /// 预分配图标池（避免运行时频繁创建/销毁）
        /// </summary>
        /// <param name="count">需要预分配的图标数量</param>
        /// <param name="iconSize">图标大小</param>
        public void PreallocateIcons(int count, float iconSize)
        {
            if (containerRT == null) return;

            // 保留已有，创建缺失
            for (int i = 0; i < count; i++)
            {
                if (!iconPool.ContainsKey(i))
                {
                    var go = new GameObject($"SectorIcon_{i}", typeof(RectTransform), typeof(Image));
                    go.transform.SetParent(containerRT, false);
                    var rt = go.GetComponent<RectTransform>();
                    rt.sizeDelta = new Vector2(iconSize, iconSize);

                    var img = go.GetComponent<Image>();
                    img.raycastTarget = false;

                    // 创建 CountText 作为子对象（一次性）
                    var txtGO = new GameObject("CountText", typeof(RectTransform));
                    txtGO.transform.SetParent(go.transform, false);
                    var txtRT = txtGO.GetComponent<RectTransform>();
                    txtRT.anchorMin = new Vector2(1f, 0f);
                    txtRT.anchorMax = new Vector2(1f, 0f);
                    txtRT.pivot = new Vector2(1f, 0f);
                    txtRT.anchoredPosition = new Vector2(-4f, 4f);
                    txtRT.sizeDelta = new Vector2(50f, 20f);

                    var countText = txtGO.AddComponent<Text>();
                    countText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
                    countText.alignment = TextAnchor.LowerRight;
                    countText.fontSize = 14;
                    countText.raycastTarget = false;
                    txtGO.SetActive(false);

                    var entry = new IconEntry(go)
                    {
                        countText = countText
                    };

                    iconPool[i] = entry;
                    go.SetActive(false);
                }
            }

            // 如果池比需要多，保留多余但隐藏
            var toRemove = iconPool.Keys.Where(k => k >= count).ToList();
            foreach (var k in toRemove)
            {
                if (iconPool.TryGetValue(k, out var e) && e?.gameObject != null)
                {
                    IconRendererHelpers.SafeDestroy(e.gameObject);
                }
                iconPool.Remove(k);
            }
        }
        
        /// <summary>
        /// 获取指定索引的图标条目
        /// </summary>
        /// <param name="index">图标索引</param>
        /// <returns>图标条目，如果不存在则返回null</returns>
        public IconEntry GetIconEntry(int index)
        {
            return iconPool.TryGetValue(index, out var entry) ? entry : null;
        }
        
        /// <summary>
        /// 获取或创建指定索引的图标条目
        /// </summary>
        /// <param name="index">图标索引</param>
        /// <param name="iconSize">图标大小</param>
        /// <returns>图标条目</returns>
        public IconEntry GetOrCreateIconEntry(int index, float iconSize)
        {
            if (!iconPool.TryGetValue(index, out var entry) || entry == null)
            {
                PreallocateIcons(Math.Max(iconPool.Count, index + 1), iconSize);
                entry = iconPool[index];
            }
            return entry;
        }
        
        /// <summary>
        /// 隐藏指定索引的图标
        /// </summary>
        /// <param name="index">图标索引</param>
        public void HideIcon(int index)
        {
            if (iconPool.TryGetValue(index, out var e) && e?.gameObject != null)
            {
                e.gameObject.SetActive(false);
            }
        }
        
        /// <summary>
        /// 隐藏所有超出指定范围的图标
        /// </summary>
        /// <param name="maxIndex">最大索引</param>
        public void HideIconsBeyondRange(int maxIndex)
        {
            foreach (var kv in iconPool)
            {
                if (kv.Key < 0 || kv.Key >= maxIndex)
                {
                    kv.Value.gameObject.SetActive(false);
                }
            }
        }
        
        /// <summary>
        /// 检查是否有任何可见的图标
        /// </summary>
        /// <returns>如果有可见图标则返回true</returns>
        public bool HasAnyVisibleIcons()
        {
            foreach (var kv in iconPool)
            {
                if (kv.Value?.gameObject != null && kv.Value.gameObject.activeInHierarchy)
                {
                    return true;
                }
            }
            return false;
        }
        
        /// <summary>
        /// 清空所有图标
        /// </summary>
        public void ClearAllIcons()
        {
            foreach (var kv in iconPool)
            {
                if (kv.Value?.gameObject != null) IconRendererHelpers.SafeDestroy(kv.Value.gameObject);
            }
            iconPool.Clear();

            if (containerRT != null)
            {
                for (int i = containerRT.childCount - 1; i >= 0; i--)
                {
                    IconRendererHelpers.SafeDestroy(containerRT.GetChild(i).gameObject);
                }
            }
        }
        
        /// <summary>
        /// 更新图标布局
        /// </summary>
        /// <param name="localPositions">本地位置数组</param>
        /// <param name="perIconOffsets">每个图标的偏移量</param>
        /// <param name="iconSize">图标大小</param>
        public void UpdateLayout(Vector2[] localPositions, Vector2[] perIconOffsets, float iconSize)
        {
            if (localPositions == null) return;

            PreallocateIcons(localPositions.Length, iconSize);

            foreach (var kv in iconPool)
            {
                int idx = kv.Key;
                if (idx < 0 || idx >= localPositions.Length) continue;
                var e = kv.Value;
                if (e == null || e.rectTransform == null) continue;
                e.rectTransform.sizeDelta = new Vector2(iconSize, iconSize);
                Vector2 basePos = localPositions[idx];
                Vector2 offset = (perIconOffsets != null && idx < perIconOffsets.Length) ? perIconOffsets[idx] : Vector2.zero;
                e.rectTransform.anchoredPosition = basePos + offset;
            }
        }
        
        /// <summary>
        /// 获取当前图标池的大小
        /// </summary>
        /// <returns>图标池大小</returns>
        public int GetPoolSize()
        {
            return iconPool.Count;
        }
    }
}