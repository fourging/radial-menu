// File: RadialMenu/UI/RadialMenuIconRenderer.cs
// ---------------------------------------------------------------------------
// 重构后的主类，整合各个功能模块
// ---------------------------------------------------------------------------

using System;
using UnityEngine;
using RadialMenu.Logic;

namespace RadialMenu.UI
{
    /// <summary>
    /// 径向菜单图标渲染器主类
    /// 整合各个功能模块，提供统一的接口
    /// </summary>
    public sealed class RadialMenuIconRenderer : MonoBehaviour
    {
        public RectTransform? ParentRect { get; private set; }
        
        // 功能模块
        private IconContainerManager containerManager;
        private IconPoolManager poolManager;
        private CenterTextManager centerTextManager;
        private ResponsiveIconSizer iconSizer;
        private IconRendererCore rendererCore;
        
        /// <summary>
        /// 初始化渲染器，并可选择性地预分配图标池
        /// </summary>
        public void Initialize(RectTransform parentRect, Vector2[] localPositions, float iconSize = 48f, Vector2[] perIconOffsets = null, bool showCount = false, bool responsiveSizing = true)
        {
            if (parentRect == null) throw new ArgumentNullException(nameof(parentRect));
            if (localPositions == null) throw new ArgumentNullException(nameof(localPositions));

            ParentRect = parentRect;
            
            // 初始化各个功能模块
            containerManager = new IconContainerManager(parentRect);
            iconSizer = new ResponsiveIconSizer(iconSize, responsiveSizing);
            
            // 确保容器存在后再创建其他管理器
            containerManager.EnsureContainer();
            containerManager.EnsureCenterTextContainer();
            
            poolManager = new IconPoolManager(containerManager.ContainerRT);
            centerTextManager = new CenterTextManager(containerManager.CenterNameText, containerManager.CenterCountText);
            rendererCore = new IconRendererCore(containerManager, poolManager, centerTextManager, iconSizer);
            
            // 初始化核心渲染器
            rendererCore.Initialize(localPositions, perIconOffsets, showCount);
            
            Log.DebugMsg($"[RadialMenuIconRenderer] 初始化完成. iconSize={iconSizer.CurrentIconSize}");
        }
        
        private void Update()
        {
            // 检查并更新图标大小（如果需要）
            rendererCore?.CheckAndUpdateIconSize();
        }
        
        /// <summary>
        /// 渲染所有图标
        /// </summary>
        public void RenderAllIcons()
        {
            rendererCore?.RenderAllIcons();
        }
        
        /// <summary>
        /// 更新布局
        /// </summary>
        /// <param name="newLocalPositions">新的本地位置数组</param>
        /// <param name="newPerIconOffsets">新的每个图标偏移量</param>
        /// <param name="newIconSize">新的图标大小</param>
        public void UpdateLayout(Vector2[] newLocalPositions = null, Vector2[] newPerIconOffsets = null, float? newIconSize = null)
        {
            rendererCore?.UpdateLayout(newLocalPositions, newPerIconOffsets, newIconSize);
        }
        
        /// <summary>
        /// 清空所有图标
        /// </summary>
        public void ClearAllIcons()
        {
            rendererCore?.ClearAllIcons();
        }
        
        /// <summary>
        /// 根据扇区索引更新中心文本
        /// </summary>
        /// <param name="sectorIndex">扇区索引，-1表示清空文本</param>
        public void UpdateCenterTextForSector(int sectorIndex)
        {
            rendererCore?.UpdateCenterTextForSector(sectorIndex);
        }
        
        /// <summary>
        /// 获取当前图标大小
        /// </summary>
        /// <returns>当前图标大小</returns>
        public float GetCurrentIconSize()
        {
            return iconSizer?.CurrentIconSize ?? 0f;
        }
        
        /// <summary>
        /// 设置是否启用响应式大小调整
        /// </summary>
        /// <param name="enabled">是否启用</param>
        public void SetResponsiveSizing(bool enabled)
        {
            if (iconSizer != null)
            {
                iconSizer.ResponsiveSizing = enabled;
            }
        }
        
        /// <summary>
        /// 手动设置图标大小
        /// </summary>
        /// <param name="newSize">新的图标大小</param>
        public void SetIconSize(float newSize)
        {
            if (iconSizer != null)
            {
                iconSizer.SetIconSize(newSize);
                rendererCore?.UpdateLayout(null, null, newSize);
            }
        }
        
        /// <summary>
        /// 强制重新计算图标大小（基于当前分辨率）
        /// </summary>
        public void RecalculateIconSize()
        {
            if (iconSizer != null)
            {
                iconSizer.RecalculateIconSize();
                rendererCore?.UpdateLayout(null, null, iconSizer.CurrentIconSize);
            }
        }
        
        private void OnDestroy()
        {
            // 清理资源
            rendererCore?.ClearAllIcons();
            rendererCore = null;
            poolManager = null;
            centerTextManager = null;
            iconSizer = null;
            containerManager = null;
        }
    }
}