// File: RadialMenu/UI/IconContainerManager.cs
// ---------------------------------------------------------------------------
// 本文件负责管理图标容器和中心文本容器的创建和管理
// ---------------------------------------------------------------------------

using UnityEngine;
using UnityEngine.UI;

namespace RadialMenu.UI
{
    /// <summary>
    /// 管理图标容器和中心文本容器的创建和管理
    /// </summary>
    public class IconContainerManager
    {
        private const string containerName = "RadialMenuIconsContainer";
        private const string centerTextContainerName = "RadialMenuCenterTextContainer";
        
        public RectTransform ContainerRT { get; private set; }
        public RectTransform CenterTextContainerRT { get; private set; }
        public Text CenterNameText { get; private set; }
        public Text CenterCountText { get; private set; }
        
        private readonly RectTransform parentRect;
        
        public IconContainerManager(RectTransform parentRect)
        {
            this.parentRect = parentRect ?? throw new System.ArgumentNullException(nameof(parentRect));
        }
        
        /// <summary>
        /// 确保图标容器存在
        /// </summary>
        public void EnsureContainer()
        {
            if (parentRect == null) return;
            Transform existing = parentRect.Find(containerName);
            if (existing != null)
            {
                ContainerRT = existing as RectTransform;
                if (ContainerRT == null)
                {
                    IconRendererHelpers.SafeDestroy(existing.gameObject);
                    CreateContainer();
                }
            }
            else
            {
                CreateContainer();
            }
        }
        
        /// <summary>
        /// 创建图标容器
        /// </summary>
        private void CreateContainer()
        {
            GameObject container = new GameObject(containerName, typeof(RectTransform));
            container.transform.SetParent(parentRect, false);
            ContainerRT = container.GetComponent<RectTransform>();
            ContainerRT.anchorMin = Vector2.zero;
            ContainerRT.anchorMax = Vector2.one;
            ContainerRT.sizeDelta = Vector2.zero;
            ContainerRT.anchoredPosition = Vector2.zero;
        }
        
        /// <summary>
        /// 确保中心文本容器存在
        /// </summary>
        public void EnsureCenterTextContainer()
        {
            if (parentRect == null) return;
            Transform existing = parentRect.Find(centerTextContainerName);
            if (existing != null)
            {
                CenterTextContainerRT = existing as RectTransform;
                if (CenterTextContainerRT == null)
                {
                    IconRendererHelpers.SafeDestroy(existing.gameObject);
                    CreateCenterTextContainer();
                }
                else
                {
                    // 如果容器已存在，确保文本组件也被正确获取
                    var nameText = CenterTextContainerRT.Find("CenterNameText");
                    if (nameText != null)
                    {
                        CenterNameText = nameText.GetComponent<Text>();
                    }
                    
                    var countText = CenterTextContainerRT.Find("CenterCountText");
                    if (countText != null)
                    {
                        CenterCountText = countText.GetComponent<Text>();
                    }
                    
                    // 如果文本组件缺失，需要重新创建
                    if (CenterNameText == null || CenterCountText == null)
                    {
                        IconRendererHelpers.SafeDestroy(existing.gameObject);
                        CreateCenterTextContainer();
                    }
                }
            }
            else
            {
                CreateCenterTextContainer();
            }
        }
        
        /// <summary>
        /// 创建中心文本容器
        /// </summary>
        private void CreateCenterTextContainer()
        {
            // 创建中心文本容器
            GameObject container = new GameObject(centerTextContainerName, typeof(RectTransform));
            container.transform.SetParent(parentRect, false);
            CenterTextContainerRT = container.GetComponent<RectTransform>();
            CenterTextContainerRT.anchorMin = new Vector2(0.5f, 0.5f);
            CenterTextContainerRT.anchorMax = new Vector2(0.5f, 0.5f);
            CenterTextContainerRT.pivot = new Vector2(0.5f, 0.5f);
            CenterTextContainerRT.sizeDelta = new Vector2(400f, 100f); // 足够大的区域容纳文本
            CenterTextContainerRT.anchoredPosition = Vector2.zero;

            // 创建物品名称文本
            GameObject nameGO = new GameObject("CenterNameText", typeof(RectTransform));
            nameGO.transform.SetParent(CenterTextContainerRT, false);
            var nameRT = nameGO.GetComponent<RectTransform>();
            nameRT.anchorMin = new Vector2(0.5f, 0.6f); // 上半部分
            nameRT.anchorMax = new Vector2(0.5f, 0.6f);
            nameRT.pivot = new Vector2(0.5f, 0.5f);
            nameRT.sizeDelta = new Vector2(380f, 40f);
            nameRT.anchoredPosition = Vector2.zero;

            CenterNameText = nameGO.AddComponent<Text>();
            CenterNameText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            CenterNameText.alignment = TextAnchor.MiddleCenter;
            CenterNameText.fontSize = 24;
            CenterNameText.color = Color.white;
            CenterNameText.raycastTarget = false;

            // 创建物品数量文本
            GameObject countGO = new GameObject("CenterCountText", typeof(RectTransform));
            countGO.transform.SetParent(CenterTextContainerRT, false);
            var countRT = countGO.GetComponent<RectTransform>();
            countRT.anchorMin = new Vector2(0.5f, 0.3f); // 下半部分
            countRT.anchorMax = new Vector2(0.5f, 0.3f);
            countRT.pivot = new Vector2(0.5f, 0.5f);
            countRT.sizeDelta = new Vector2(380f, 30f);
            countRT.anchoredPosition = Vector2.zero;

            CenterCountText = countGO.AddComponent<Text>();
            CenterCountText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            CenterCountText.alignment = TextAnchor.MiddleCenter;
            CenterCountText.fontSize = 18;
            CenterCountText.color = Color.white;
            CenterCountText.raycastTarget = false;
        }
    }
}