// File: RadialMenu/UI/IconEntry.cs
using UnityEngine;
using UnityEngine.UI;

namespace RadialMenu.UI
{
    // 内部结构：缓存每个扇区对应的 icon 对象与常用组件引用
    public class IconEntry
    {
        public GameObject gameObject;
        public RectTransform rectTransform;
        public Image image;
        public Text countText; // 若项目使用 TextMeshPro，可手动替换此处

        public IconEntry(GameObject go)
        {
            gameObject = go;
            rectTransform = go.GetComponent<RectTransform>();
            image = go.GetComponent<Image>();
            countText = go.transform.Find("CountText")?.GetComponent<Text>();
        }
    }
}