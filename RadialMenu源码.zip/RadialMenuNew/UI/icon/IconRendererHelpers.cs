// File: RadialMenu/UI/IconRendererHelpers.cs
// ---------------------------------------------------------------------------
// 本文件主要提供图标渲染相关的辅助函数，用于：
// 1. 从任意数据结构中安全提取 Item 对象（递归展开）
// 2. 通过反射读取 Item 的属性（如 TypeID、StackCount、Icon 等）
// 3. 提供安全销毁 GameObject 的方法
// 4. 内部使用缓存与容错机制，保证在反射失败时仍能返回合理结果
// ---------------------------------------------------------------------------

using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
using ItemStatsSystem;
using System.Collections.Concurrent;
using RadialMenu.Logic;

namespace RadialMenu.UI
{
    public static class IconRendererHelpers
    {
        // Item 类型缓存，避免多次 typeof(Item)
        private static readonly Type itemType = typeof(Item);

        // 针对不同 Item 类型缓存其 TypeID 读取委托，提高性能
        private static readonly ConcurrentDictionary<Type, Func<Item, string>> _typeIdGetterCache = new ConcurrentDictionary<Type, Func<Item, string>>();

        // ============================================================================
        // 提取物品对象（递归解包各种容器结构）
        // ============================================================================
        /// <summary>
        /// 从任意对象（可能是单个 Item、集合、复杂结构体或匿名对象）中
        /// 递归提取所有 Item 实例到 collector 中。
        /// 该函数会自动识别：
        ///  - Item
        ///  - IEnumerable（递归处理）
        ///  - 带有 Item 字段/属性的对象
        ///  - 复杂对象中嵌套的 Item 集合
        /// </summary>
        public static void ExtractItemsFromEntry(object entry, HashSet<Item> collector)
        {
            if (entry == null) return;

            void AddIfNotContains(Item itm)
            {
                if (itm == null) return;
                collector.Add(itm);
            }

            // 情况1：直接是 Item 对象
            if (entry is Item it)
            {
                try
                {
                    // 尝试展开其内部嵌套物品（例如包内物品）
                    foreach (var ni in GetAllNestedItemsSafe(it))
                        AddIfNotContains(ni);
                }
                catch (Exception ex)
                {
                    Log.DebugMsg("[RadialMenuIconRenderer] 展开 Item 时异常: " + ex);
                    AddIfNotContains(it);
                }
                return;
            }

            // 情况2：是一个可枚举对象（例如 List<Item>、数组）
            if (entry is IEnumerable enumerable && !(entry is string))
            {
                foreach (var sub in enumerable)
                {
                    try
                    {
                        if (sub is Item subItem)
                        {
                            foreach (var ni in GetAllNestedItemsSafe(subItem))
                                AddIfNotContains(ni);
                        }
                        else
                        {
                            ExtractItemsFromEntry(sub, collector);
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.DebugMsg("[RadialMenuIconRenderer] 处理 IEnumerable 子元素异常: " + ex);
                    }
                }
                return;
            }

            // 情况3：尝试从属性名推断（Item/item/Value）
            var t = entry.GetType();
            var prop = t.GetProperty("Item") ?? t.GetProperty("item") ?? t.GetProperty("Value");
            if (prop != null)
            {
                try
                {
                    var v = prop.GetValue(entry);
                    ExtractItemsFromEntry(v, collector);
                    return;
                }
                catch (Exception ex)
                {
                    Log.DebugMsg("[RadialMenuIconRenderer] 通过属性读取 Item 异常: " + ex);
                }
            }

            // 情况4：尝试从字段名推断（Item/item/Item1/Value）
            var fld = t.GetField("Item") ?? t.GetField("item") ?? t.GetField("Item1") ?? t.GetField("Value");
            if (fld != null)
            {
                try
                {
                    var v = fld.GetValue(entry);
                    ExtractItemsFromEntry(v, collector);
                    return;
                }
                catch (Exception ex)
                {
                    Log.DebugMsg("[RadialMenuIconRenderer] 通过字段读取 Item 异常: " + ex);
                }
            }

            // 情况5：遍历所有公开属性，递归寻找 Item 或集合类型
            foreach (var p in t.GetProperties(BindingFlags.Public | BindingFlags.Instance))
            {
                try
                {
                    if (itemType.IsAssignableFrom(p.PropertyType))
                    {
                        var v = p.GetValue(entry) as Item;
                        if (v != null)
                        {
                            AddIfNotContains(v);
                            foreach (var ni in GetAllNestedItemsSafe(v))
                                AddIfNotContains(ni);
                            return;
                        }
                    }
                    if (typeof(IEnumerable).IsAssignableFrom(p.PropertyType) && p.PropertyType != typeof(string))
                    {
                        var v = p.GetValue(entry) as IEnumerable;
                        if (v != null)
                        {
                            ExtractItemsFromEntry(v, collector);
                            return;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Log.DebugMsg("[RadialMenuIconRenderer] 反射属性处理异常: " + ex);
                }
            }

            // 情况6：遍历所有公开字段
            foreach (var f in t.GetFields(BindingFlags.Public | BindingFlags.Instance))
            {
                try
                {
                    if (itemType.IsAssignableFrom(f.FieldType))
                    {
                        var v = f.GetValue(entry) as Item;
                        if (v != null)
                        {
                            AddIfNotContains(v);
                            foreach (var ni in GetAllNestedItemsSafe(v))
                                AddIfNotContains(ni);
                            return;
                        }
                    }
                    if (typeof(IEnumerable).IsAssignableFrom(f.FieldType) && f.FieldType != typeof(string))
                    {
                        var v = f.GetValue(entry) as IEnumerable;
                        if (v != null)
                        {
                            ExtractItemsFromEntry(v, collector);
                            return;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Log.DebugMsg("[RadialMenuIconRenderer] 反射字段处理异常: " + ex);
                }
            }
        }

        // ============================================================================
        // 安全展开物品内部嵌套内容
        // ============================================================================
        /// <summary>
        /// 尝试调用 InventoryHelper.GetAllNestedItems（若存在），
        /// 否则使用备用的 DFS 算法遍历 Item.Inventory 与 Item.Slots。
        /// 保证即使反射失败也能安全返回物品层级内容。
        /// </summary>
        public static IEnumerable<Item> GetAllNestedItemsSafe(Item item)
        {
            if (item == null) yield break;

            object reflectResult = null!;
            try
            {
                // 通过反射查找内部方法 GetAllNestedItems
                var invHelperType = typeof(InventoryHelper);
                var mi = invHelperType.GetMethod("GetAllNestedItems", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Public);
                if (mi != null)
                {
                    var parameters = mi.GetParameters();
                    object[] args = null;
                    if (parameters.Length == 1) args = new object[] { item };
                    else if (parameters.Length == 2) args = new object[] { item, null };
                    else if (parameters.Length == 0) args = new object[] { };

                    if (args != null)
                        reflectResult = mi.Invoke(null, args);
                }
            }
            catch (Exception ex)
            {
                Log.DebugMsg("[RadialMenuIconRenderer] 反射调用 GetAllNestedItems 失败: " + ex);
                reflectResult = null;
            }

            // 如果反射结果有效，优先返回
            if (reflectResult != null)
            {
                if (reflectResult is IEnumerable<Item> colItems)
                {
                    foreach (var i in colItems) yield return i;
                    yield break;
                }
                if (reflectResult is IEnumerable colEnum)
                {
                    foreach (var o in colEnum) if (o is Item it) yield return it;
                    yield break;
                }
            }

            // ------------------- 手动 DFS 遍历 -------------------
            List<Item> results = new List<Item>();
            try
            {
                var visited = new HashSet<Item>(ReferenceEqualityComparer<Item>.Default);
                var stack = new Stack<Item>();
                stack.Push(item);

                while (stack.Count > 0)
                {
                    var cur = stack.Pop();
                    if (cur == null || visited.Contains(cur)) continue;
                    visited.Add(cur);
                    results.Add(cur);

                    // 遍历子物品容器
                    try
                    {
                        if (cur.Inventory != null)
                        {
                            foreach (var nested in cur.Inventory)
                            {
                                if (nested != null && !visited.Contains(nested))
                                    stack.Push(nested);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.DebugMsg("[RadialMenuIconRenderer] 访问 cur.Inventory 异常: " + ex);
                    }

                    // 遍历槽位中的物品
                    try
                    {
                        if (cur.Slots != null)
                        {
                            foreach (var slot in cur.Slots)
                            {
                                if (slot?.Content != null && !visited.Contains(slot.Content))
                                    stack.Push(slot.Content);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.DebugMsg("[RadialMenuIconRenderer] 访问 cur.Slots 异常: " + ex);
                    }
                }
            }
            catch (Exception ex)
            {
                Log.DebugMsg("[RadialMenuIconRenderer] DFS 展开异常: " + ex);
                if (!results.Contains(item)) results.Add(item);
            }

            foreach (var it in results) yield return it;
        }



        // ============================================================================
        // 获取物品的 TypeID（用于区分不同物品类型）
        // ============================================================================
        public static string GetItemTypeIdAsString(Item item)
        {
            if (item == null) return string.Empty;

            try
            {
                var t = item.GetType();

                // 从缓存中获取快速访问委托
                var getter = _typeIdGetterCache.GetOrAdd(t, CreateTypeIdGetterForType);
                string raw = null;
                try
                {
                    raw = getter?.Invoke(item);
                }
                catch (Exception ex)
                {
                    // 如果委托执行失败则使用反射兜底
                    Log.DebugMsg("[RadialMenuIconRenderer] typeId getter 调用失败，回退反射读取: " + ex.Message);
                    raw = FallbackReflectTypeId(item, t);
                }

                if (!string.IsNullOrEmpty(raw)) return raw.Trim();

                // 若仍无结果，则使用 DisplayName 代替（兼容旧逻辑）
                if (!string.IsNullOrEmpty(item.DisplayName)) return item.DisplayName.Trim();
            }
            catch (Exception ex)
            {
                Log.Error("[RadialMenuIconRenderer] GetItemTypeIdAsString 总体异常", ex);
            }

            return string.Empty;
        }

        // ============================================================================
        // 创建指定类型的 TypeID 获取委托（反射一次后缓存）
        // ============================================================================
        private static Func<Item, string> CreateTypeIdGetterForType(Type t)
        {
            try
            {
                var propNames = new[] { "TypeID", "TypeId", "typeId", "ID", "Id", "id" };
                foreach (var name in propNames)
                {
                    var prop = t.GetProperty(name, BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase);
                    if (prop != null && prop.CanRead)
                    {
                        return (Item it) =>
                        {
                            try { return prop.GetValue(it)?.ToString(); }
                            catch { return null; }
                        };
                    }
                }

                foreach (var name in propNames)
                {
                    var fld = t.GetField(name, BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase);
                    if (fld != null)
                    {
                        return (Item it) =>
                        {
                            try { return fld.GetValue(it)?.ToString(); }
                            catch { return null; }
                        };
                    }
                }
            }
            catch (Exception ex)
            {
                Log.DebugMsg("[RadialMenuIconRenderer] CreateTypeIdGetterForType 反射失败: " + ex.Message);
            }

            // 如果没有匹配字段，返回空委托
            return (Item it) => null;
        }

        // 极端情况下使用的备用反射
        private static string FallbackReflectTypeId(Item item, Type t)
        {
            try
            {
                var prop = t.GetProperty("TypeID", BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase);
                if (prop != null)
                {
                    var v = prop.GetValue(item);
                    if (v != null) return v.ToString().Trim();
                }
                var fld = t.GetField("TypeID", BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase);
                if (fld != null)
                {
                    var v = fld.GetValue(item);
                    if (v != null) return v.ToString().Trim();
                }
            }
            catch (Exception ex)
            {
                Log.DebugMsg("[RadialMenuIconRenderer] FallbackReflectTypeId 异常: " + ex.Message);
            }
            return null;
        }

        // ============================================================================
        // 获取堆叠数量
        // ============================================================================
        public static int GetItemStackCount(Item item)
        {
            if (item == null) return 0;
            try
            {
                var t = item.GetType();
                var prop = t.GetProperty("StackCount", BindingFlags.Public | BindingFlags.Instance)
                        ?? t.GetProperty("Count", BindingFlags.Public | BindingFlags.Instance);
                if (prop != null)
                {
                    var v = prop.GetValue(item);
                    if (v != null) return Convert.ToInt32(v);
                }
                var fld = t.GetField("StackCount", BindingFlags.Public | BindingFlags.Instance)
                        ?? t.GetField("count", BindingFlags.Public | BindingFlags.Instance);
                if (fld != null)
                {
                    var v = fld.GetValue(item);
                    if (v != null) return Convert.ToInt32(v);
                }
            }
            catch (Exception ex)
            {
                Log.DebugMsg("[RadialMenuIconRenderer] GetItemStackCount 反射异常: " + ex);
            }
            return 0;
        }

        // ============================================================================
        // 获取物品图标 Sprite
        // ============================================================================
        public static Sprite GetItemSprite(Item item)
        {
            if (item == null) return null;
            try
            {
                var t = item.GetType();
                var prop = t.GetProperty("Icon", BindingFlags.Public | BindingFlags.Instance)
                        ?? t.GetProperty("icon", BindingFlags.Public | BindingFlags.Instance);
                if (prop != null && prop.GetValue(item) is Sprite s)
                    return s;

                var fld = t.GetField("Icon", BindingFlags.Public | BindingFlags.Instance)
                        ?? t.GetField("icon", BindingFlags.Public | BindingFlags.Instance);
                if (fld != null && fld.GetValue(item) is Sprite s2)
                    return s2;
            }
            catch (Exception ex)
            {
                Log.Error("[RadialMenuIconRenderer] GetItemSprite 反射失败", ex);
            }
            return null;
        }

        // ============================================================================
        // 安全销毁 GameObject（支持编辑器模式）
        // ============================================================================
        public static void SafeDestroy(GameObject go)
        {
            if (go == null) return;
#if UNITY_EDITOR
            if (!Application.isPlaying)
            {
                UnityEngine.Object.DestroyImmediate(go);
                return;
            }
#endif
            UnityEngine.Object.Destroy(go);
        }

        // ============================================================================
        // 按引用比较对象（防止引用相同的 Item 被重复计入）
        // ============================================================================
        public sealed class ReferenceEqualityComparer<T> : IEqualityComparer<T> where T : class
        {
            public static ReferenceEqualityComparer<T> Default { get; } = new ReferenceEqualityComparer<T>();
            public bool Equals(T x, T y) => ReferenceEquals(x, y);
            public int GetHashCode(T obj) => System.Runtime.CompilerServices.RuntimeHelpers.GetHashCode(obj);
        }
    }
}
