using System;
using System.Collections.Generic;
using SodaCraft.Localizations;
using UnityEngine;
using RadialMenu.Logic;

namespace RadialMenu.Patches;

/// <summary>
/// Mod 本地化辅助类
/// 管理 Mod 的多语言文本
/// </summary>
public static class LocalizationHelper
{
    // 本地化键名前缀，避免与游戏原有键冲突
    private const string KeyPrefix = "EfDEnhanced_";

    // 本地化文本数据
    private static readonly Dictionary<SystemLanguage, Dictionary<string, string>> LocalizationData = [];

    /// <summary>
    /// 语言变更事件 - UI 组件可订阅此事件以在语言改变时刷新显示
    /// </summary>
    public static event Action<SystemLanguage>? OnLanguageChanged;

    /// <summary>
    /// 初始化本地化系统
    /// </summary>
    public static void Initialize()
    {
        try
        {
            Log.Info("Initializing localization system...");

            // 注册语言切换事件
            LocalizationManager.OnSetLanguage += LanguageChangedHandler;

            // 加载所有语言的翻译
            LoadTranslations();

            // 应用当前语言的翻译
            ApplyTranslations(LocalizationManager.CurrentLanguage);

            Log.Info($"Localization initialized for language: {LocalizationManager.CurrentLanguage}");
        }
        catch (System.Exception ex)
        {
            Log.Info($"Failed to initialize localization: {ex}");
        }
    }

    /// <summary>
    /// 清理本地化系统
    /// </summary>
    public static void Cleanup()
    {
        try
        {
            LocalizationManager.OnSetLanguage -= LanguageChangedHandler;

            // 移除所有覆盖的文本
            foreach (var langData in LocalizationData.Values)
            {
                foreach (var key in langData.Keys)
                {
                    LocalizationManager.RemoveOverrideText(GetFullKey(key));
                }
            }

            Log.Error( "Localization system cleaned up");
        }
        catch (System.Exception ex)
        {
            Log.Error($"Failed to cleanup localization: {ex}");
        }
    }

    /// <summary>
    /// 语言切换事件处理 - 同时触发公共事件供 UI 组件订阅
    /// </summary>
    private static void LanguageChangedHandler(SystemLanguage newLanguage)
    {
        try
        {
            Log.Info($"Language changed to: {newLanguage}");
            ApplyTranslations(newLanguage);

            // 触发公共事件，通知所有订阅者
            OnLanguageChanged?.Invoke(newLanguage);
        }
        catch (System.Exception ex)
        {
            Log.Error($"Failed to handle language change: {ex}");
        }
    }

    /// <summary>
    /// 加载所有语言的翻译数据
    /// </summary>
    private static void LoadTranslations()
    {
        // 简体中文
        LocalizationData[SystemLanguage.ChineseSimplified] = new Dictionary<string, string>
        {
            // 设置界面
            { "Settings_Title", "环形菜单设置" },
            
            // 配置项描述
            { "Config_FoodBindSectors", "自动绑定食物的扇区编号" },
            { "Config_ignoreDurabilityValue", "低于多少耐久的急救箱自动略过圆盘使用" },
            { "Config_showLowValueFood", "提示低价值物品是否包含食物" },
            { "Config_quickUseLastItemQ", "是否开启短按Q触发快速使用上次物品功能" },
            { "Config_iconSize", "图标尺寸" },
            { "Config_iconDistanceFactor", "图标距离圆心的比例" },
            { "Config_uiScalePercent", "背景UI缩放百分比" },
            { "Config_innerDeadZoneCoefficient", "内圈死区系数" },
            { "Config_outerDeadZoneCoefficient", "外圈死区系数" },
            { "Config_longPressQWaitDuration", "呼出圆盘长按时间" },
            { "Config_UI8style", "8扇区UI方案" },
            { "Config_UI6style", "6扇区UI方案" },
            { "Config_sectorCount", "扇区数量" },
            { "Config_isBulletTimeEnabled", "是否开启子弹时间" },
            { "Config_bulletTimeMultiplier", "子弹时间游戏速度倍率" },
            { "Config_radialMenuActivationKey", "呼出圆盘使用的按键" },
            
            // UI提示信息
            { "UI_ItemCount", "数量: {0}" },
            { "UI_BindingNotAllowed", "这个不让绑定" },
            { "UI_InstallModConfig", "请安装 ModConfig 并重启游戏！" },
            { "UI_DefaultStyle", "默认" },
            { "UI_StyleOption", "{0}方案" },
            { "UI_NoStyleDetected", "未检测到{0}扇区的背景套装，使用默认选项" },
            
            // 日志信息
            { "Log_RadialMenuInit", "环形菜单初始化开始..." },
            { "Log_RadialMenuComplete", "环形菜单初始化完成" },
            { "Log_BindingComplete", "已将绑定持久化：扇区={0}，TypeID={1}，DisplayName={2}，autoBound={3}" },
            { "Log_IconDistanceUpdated", "图标距离因子更新为 {0}，已重新计算图标位置" },
            { "Log_StyleUnavailable", "当前样式 {0} 对于 {1} 扇区不可用，使用默认样式 {2}" },
            { "Log_LoadingStyle", "加载 {0} 扇区背景，使用样式: {1}" },
            { "Log_SectorAngle", "计算了 {0} 个扇区的图标位置，每个扇区角度: {1}°" },
            
            // 物品使用相关提示
            { "Use_ExplosionArt", "爆炸就是艺术！" },
            { "Use_EatItem", "吃 {0}！" },
            { "Use_EquipItem", "装备 {0}！" },
            { "Use_UseItem", "使用 {0}！" },
            { "Use_HealthRecovered", "补充生命值！" },
            { "Use_Ouch", "好痛！得赶紧治疗一下" },
            { "Use_ReplaceAfterUse", "用完这次就换新的了" },
            { "Use_HealthRemaining", "还能回{0}血量" },
            { "Use_DrinkItem", "喝 {0}" },
            { "Use_ColaOverflow", "呲！糟糕，可乐溢出来了！" },
            { "Use_ColaDrinking", "吨吨吨吨吨……" },
            { "Use_TasteItem", "偷偷尝一口 {0}～" },
            { "Use_ColaByeBye", "可乐一开，烦恼拜拜。" },
            { "Use_Cheers", "干杯！" },
            { "Use_DrinkFirst", "先干为敬！" },
            { "Use_DrinkForgetWorries", "喝了这杯忘掉烦恼～" },
            { "Use_FoodTasty", "{0}真好次！" },
            { "Use_SoFragrant", "艾玛真香！" },
            { "Use_DontEatDuckPoop", "别让鸭鸭吃粑粑啊！" },
            { "Use_AutoBindBurger", "已自动绑定老八秘制小汉堡！" },
            { "Use_IsThisPoop", "竟然是粑粑吗？？你先吃！" },
            { "Use_FoundPoop", "发现一坨{0}在背包里！臭死了" },
            { "Use_HealthFull", "血量已经满了" },
            
            // 绑定相关提示
            { "Binding_Success", "已绑定：{0}" },
            { "Binding_Success_Short", "已绑定{0}" },
            { "Binding_Failed", "绑定失败：{0}" },
            { "Item_RemainingCount", "背包内剩余数量 {0}" },
            { "Item_NoMoreItems_1", "背包里没有这个物品了哦！" },
            { "Item_NoMoreItems_2", "这个物品已经用完啦！" },
            { "Item_NoMoreItems_3", "你已经没有这个物品了！" },
            { "Item_NoMoreItems_4", "用光光啦！" },
            { "Item_NoMoreItems_5", "没有辣！" },
            { "Item_NoMoreItems_6", "花光啦！" },
            
            // 输入处理相关提示
            { "Input_SelectItemFirst", "请先选择一个物品再开始绑定" },
            { "Input_NoRadialHere", "这里不准呼出圆盘菜单哦！" },
            { "Input_NoLowValueItem", "没有找到不划算的物品" },
            { "Input_LowestValueItem", "价重比最低的是{0}！" },
            { "Input_SuggestDrop", "建议先丢掉{0}！" },
            { "Input_CannotCarry", "背不动了，先把{0}扔了吧～" },
            { "Input_NotWorthMoney", "{0}？这东西不怎么值钱的样子？" },
            { "Input_HeavyDrop", "重死了！快把{0}扔了！" },
            { "Input_CannotCarryAlt", "背不动了，先把{0}扔了吧～" },
            { "Input_LeastWorth", "{0}最不值钱～" },
            { "Input_AuthorRequest", "作者鸭：求求给环形菜单点个赞吧，努力了五天现学C#才做出来的，谢谢你！" },
            
            // 食物绑定相关提示
            { "Food_AutoBindSector", "已为扇区 {0} 自动绑定食物：{1}" },
            { "Food_PreviousFoodEaten", "之前的食物吃光了，现在吃这个 {0} ！" },
            { "Food_TiredOfOld", "早就吃腻了，终于换成我喜欢的{0}了！" },
            { "Food_FoundBetter", "发现更好吃的{0}，已经换好了！" },
            { "Food_CheapDelicious", "{0}便宜又美味！" },
        };

        // 繁体中文
        LocalizationData[SystemLanguage.ChineseTraditional] = new Dictionary<string, string>
        {
            // 設置介面
            { "Settings_Title", "環形菜單設置" },
            
            // 配置項描述
            { "Config_FoodBindSectors", "自動綁定食物的扇區編號" },
            { "Config_ignoreDurabilityValue", "低於多少耐久的急救箱自動略過圓盤使用" },
            { "Config_showLowValueFood", "提示低價值物品是否包含食物" },
            { "Config_quickUseLastItemQ", "是否開啟短按Q觸發快速使用上次物品功能" },
            { "Config_iconSize", "圖標尺寸" },
            { "Config_iconDistanceFactor", "圖標距離圓心的比例" },
            { "Config_uiScalePercent", "背景UI縮放百分比" },
            { "Config_innerDeadZoneCoefficient", "內圈死區係數" },
            { "Config_outerDeadZoneCoefficient", "外圈死區係數" },
            { "Config_longPressQWaitDuration", "呼出圓盤長按時間" },
            { "Config_UI8style", "8扇區UI方案" },
            { "Config_UI6style", "6扇區UI方案" },
            { "Config_sectorCount", "扇區數量" },
            { "Config_isBulletTimeEnabled", "是否開啟子彈時間" },
            { "Config_bulletTimeMultiplier", "子彈時間遊戲速度倍率" },
            { "Config_radialMenuActivationKey", "呼出圓盤使用的按鍵" },
            
            // UI提示信息
            { "UI_ItemCount", "數量: {0}" },
            { "UI_BindingNotAllowed", "這個不讓綁定" },
            { "UI_InstallModConfig", "請安裝 ModConfig 並重啟遊戲！" },
            { "UI_DefaultStyle", "默認" },
            { "UI_StyleOption", "{0}方案" },
            { "UI_NoStyleDetected", "未檢測到{0}扇區的背景套裝，使用默認選項" },
            
            // 日誌信息
            { "Log_RadialMenuInit", "環形菜單初始化開始..." },
            { "Log_RadialMenuComplete", "環形菜單初始化完成" },
            { "Log_BindingComplete", "已將綁定持久化：扇區={0}，TypeID={1}，DisplayName={2}，autoBound={3}" },
            { "Log_IconDistanceUpdated", "圖標距離因子更新為 {0}，已重新計算圖標位置" },
            { "Log_StyleUnavailable", "當前樣式 {0} 對於 {1} 扇區不可用，使用默認樣式 {2}" },
            { "Log_LoadingStyle", "加載 {0} 扇區背景，使用樣式: {1}" },
            { "Log_SectorAngle", "計算了 {0} 個扇區的圖標位置，每個扇區角度: {1}°" },
            
            // 綁定相關提示
            { "Binding_Success", "已綁定：{0}" },
            { "Binding_Success_Short", "已綁定{0}" },
            { "Binding_Failed", "綁定失敗：{0}" },
            { "Item_RemainingCount", "背包內剩餘數量 {0}" },
            { "Item_NoMoreItems_1", "背包裡沒有這個物品了哦！" },
            { "Item_NoMoreItems_2", "這個物品已經用完啦！" },
            { "Item_NoMoreItems_3", "你已經沒有這個物品了！" },
            { "Item_NoMoreItems_4", "用光光啦！" },
            { "Item_NoMoreItems_5", "沒有辣！" },
            { "Item_NoMoreItems_6", "花光啦！" },
        };

        // 英语
        LocalizationData[SystemLanguage.English] = new Dictionary<string, string>
        {
            // Settings
            { "Settings_Title", "Radial Menu Settings" },
            
            // Configuration descriptions
            { "Config_FoodBindSectors", "Auto-bind food sector number" },
            { "Config_ignoreDurabilityValue", "Auto-skip medkits below durability threshold" },
            { "Config_showLowValueFood", "Show if low-value items contain food" },
            { "Config_quickUseLastItemQ", "Enable quick use last item with short Q press" },
            { "Config_iconSize", "Icon size" },
            { "Config_iconDistanceFactor", "Icon distance from center ratio" },
            { "Config_uiScalePercent", "Background UI scale percentage" },
            { "Config_innerDeadZoneCoefficient", "Inner dead zone coefficient" },
            { "Config_outerDeadZoneCoefficient", "Outer dead zone coefficient" },
            { "Config_longPressQWaitDuration", "Long press duration to show menu" },
            { "Config_UI8style", "8-sector UI style" },
            { "Config_UI6style", "6-sector UI style" },
            { "Config_sectorCount", "Sector count" },
            { "Config_isBulletTimeEnabled", "Enable bullet time" },
            { "Config_bulletTimeMultiplier", "Bullet time game speed multiplier" },
            { "Config_radialMenuActivationKey", "Radial menu activation key" },
            
            // UI messages
            { "UI_ItemCount", "Count: {0}" },
            { "UI_BindingNotAllowed", "This item cannot be bound" },
            { "UI_InstallModConfig", "Please install ModConfig and restart the game!" },
            { "UI_DefaultStyle", "Default" },
            { "UI_StyleOption", "{0} Style" },
            { "UI_NoStyleDetected", "No {0}-sector background pack detected, using default option" },
            
            // Log messages
            { "Log_RadialMenuInit", "Radial menu initialization started..." },
            { "Log_RadialMenuComplete", "Radial menu initialization complete" },
            { "Log_BindingComplete", "Binding persisted: sector={0}, TypeID={1}, DisplayName={2}, autoBound={3}" },
            { "Log_IconDistanceUpdated", "Icon distance factor updated to {0}, icon positions recalculated" },
            { "Log_StyleUnavailable", "Current style {0} not available for {1} sectors, using default style {2}" },
            { "Log_LoadingStyle", "Loading {0} sector background, using style: {1}" },
            { "Log_SectorAngle", "Calculated icon positions for {0} sectors, each sector angle: {1}°" },
            
            // Binding related messages
            { "Binding_Success", "Bound: {0}" },
            { "Binding_Success_Short", "Bound {0}" },
            { "Binding_Failed", "Binding failed: {0}" },
            { "Item_RemainingCount", "Remaining count in backpack: {0}" },
            { "Item_NoMoreItems_1", "No more of this item in backpack!" },
            { "Item_NoMoreItems_2", "This item has been used up!" },
            { "Item_NoMoreItems_3", "You don't have this item anymore!" },
            { "Item_NoMoreItems_4", "All used up!" },
            { "Item_NoMoreItems_5", "None left!" },
            { "Item_NoMoreItems_6", "All gone!" },
            
            // Item usage related messages
            { "Use_ExplosionArt", "Explosion is art!" },
            { "Use_EatItem", "Eat {0}!" },
            { "Use_EquipItem", "Equip {0}!" },
            { "Use_UseItem", "Use {0}!" },
            { "Use_HealthRecovered", "Health restored!" },
            { "Use_Ouch", "Ouch! Need to heal quickly" },
            { "Use_ReplaceAfterUse", "Replace with new one after this use" },
            { "Use_HealthRemaining", "Can restore {0} health" },
            { "Use_DrinkItem", "Drink {0}" },
            { "Use_ColaOverflow", "Psst! Oops, cola overflowed!" },
            { "Use_ColaDrinking", "Glug glug glug..." },
            { "Use_TasteItem", "Secretly taste {0}~" },
            { "Use_ColaByeBye", "Cola opens, worries bye bye." },
            { "Use_Cheers", "Cheers!" },
            { "Use_DrinkFirst", "Drink first out of respect!" },
            { "Use_DrinkForgetWorries", "Drink this cup and forget worries~" },
            { "Use_FoodTasty", "{0} is so tasty!" },
            { "Use_SoFragrant", "Wow, so fragrant!" },
            { "Use_DontEatDuckPoop", "Don't let the duck eat poop!" },
            { "Use_AutoBindBurger", "Auto-bound Lao Ba's secret burger!" },
            { "Use_IsThisPoop", "Is this poop?? You eat first!" },
            { "Use_FoundPoop", "Found a pile of {0} in backpack! So stinky" },
            { "Use_HealthFull", "Health is already full" },
            
            // Input handling related messages
            { "Input_SelectItemFirst", "Please select an item first before starting binding" },
            { "Input_NoRadialHere", "No radial menu allowed here!" },
            { "Input_NoLowValueItem", "No low-value items found" },
            { "Input_LowestValueItem", "Lowest price-to-weight ratio is {0}!" },
            { "Input_SuggestDrop", "Suggest dropping {0} first!" },
            { "Input_CannotCarry", "Too heavy to carry, drop {0} first~" },
            { "Input_NotWorthMoney", "{0}? This thing doesn't seem worth much money?" },
            { "Input_HeavyDrop", "So heavy! Quick, drop {0}!" },
            { "Input_CannotCarryAlt", "Too heavy to carry, drop {0} first~" },
            { "Input_LeastWorth", "{0} is least worth money~" },
            { "Input_AuthorRequest", "Author Duck: Please give Radial Menu a like, worked hard for 5 days learning C# to make this, thank you!" },
            
            // Food binding related messages
            { "Food_AutoBindSector", "Auto-bound food for sector {0}: {1}" },
            { "Food_PreviousFoodEaten", "Previous food eaten, now eating this {0}!" },
            { "Food_TiredOfOld", "Tired of old food, finally changed to my favorite {0}!" },
            { "Food_FoundBetter", "Found better tasting {0}, already changed!" },
            { "Food_CheapDelicious", "{0} is cheap and delicious!" },
        };

        Log.Info($"Loaded translations for {LocalizationData.Count} languages");
    }

    /// <summary>
    /// 应用指定语言的翻译
    /// </summary>
    private static void ApplyTranslations(SystemLanguage language)
    {
        // 如果没有该语言的翻译，使用英语作为后备
        if (!LocalizationData.ContainsKey(language))
        {
            Log.Warn($"No translations found for {language}, falling back to English");
            language = SystemLanguage.English;
        }

        var translations = LocalizationData[language];
        foreach (var kvp in translations)
        {
            string fullKey = GetFullKey(kvp.Key);
            LocalizationManager.SetOverrideText(fullKey, kvp.Value);
        }

        Log.Info( $"Applied {translations.Count} translations for {language}");
    }

    /// <summary>
    /// 获取完整的本地化键名
    /// </summary>
    private static string GetFullKey(string shortKey)
    {
        return KeyPrefix + shortKey;
    }

    /// <summary>
    /// 获取本地化文本（便捷方法）
    /// </summary>
    public static string Get(string key)
    {
        return LocalizationManager.GetPlainText(GetFullKey(key));
    }

    /// <summary>
    /// 获取格式化的本地化文本
    /// </summary>
    public static string GetFormatted(string key, params object[] args)
    {
        string text = Get(key);
        try
        {
            return string.Format(text, args);
        }
        catch (System.Exception ex)
        {
            Log.Error($"Failed to format localization string '{key}': {ex.Message}");
            return text;
        }
    }

    /// <summary>
    /// 为 Text 组件自动更新本地化文本
    /// 使用方式: LocalizationHelper.SetLocalizedText(textComponent, "localization_key");
    /// </summary>
    public static void SetLocalizedText(UnityEngine.UI.Text textComponent, string localizationKey)
    {
        if (textComponent == null) return;

        textComponent.text = Get(localizationKey);

        // 订阅语言变更事件，当语言改变时自动更新文本
        OnLanguageChanged += (lang) =>
        {
            if (textComponent != null && !string.IsNullOrEmpty(localizationKey))
            {
                textComponent.text = Get(localizationKey);
            }
        };
    }

    /// <summary>
    /// 为 TextMeshProUGUI 组件自动更新本地化文本
    /// 使用方式: LocalizationHelper.SetLocalizedText(tmpText, "localization_key");
    /// </summary>
    public static void SetLocalizedText(TMPro.TextMeshProUGUI textComponent, string localizationKey)
    {
        if (textComponent == null) return;

        textComponent.text = Get(localizationKey);

        // 订阅语言变更事件，当语言改变时自动更新文本
        OnLanguageChanged += (lang) =>
        {
            if (textComponent != null && !string.IsNullOrEmpty(localizationKey))
            {
                textComponent.text = Get(localizationKey);
            }
        };
    }
}

