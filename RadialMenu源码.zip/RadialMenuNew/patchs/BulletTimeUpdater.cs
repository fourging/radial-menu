// File: BulletTimeUpdater.cs
using UnityEngine;
using RadialMenu.Patches;
using RadialMenu.Logic;
using RadialMenu.ConfigAndAPI;

namespace RadialMenu.Patches
{
    public class BulletTimeUpdater : MonoBehaviour
    {
        void Awake()
        {
            Log.DebugMsg("BulletTimeUpdater Awake - 常驻更新器已创建");
        }

        void Update()
        {
            try
            {
                // 如果子弹时间启用，确保时间比例被维持
                if (RadialMenuSetting.IsBulletTimeEnabled && BulletTimeManager.IsBulletTimeActive)
                {
                    BulletTimeManager.UpdateBulletTime();
                    // 打印调试（频繁日志可能刷屏，测试时可保留）
                    Log.DebugMsg($"保持子弹时间: Time.timeScale={Time.timeScale}, fixedDelta={Time.fixedDeltaTime}");
                }
            }
            catch (System.Exception ex)
            {
                Log.Error("BulletTimeUpdater.Update 内发生异常", ex);
            }
        }

        void OnDestroy()
        {
            Log.DebugMsg("BulletTimeUpdater 被销毁（如果这是在退出或重新加载场景，则正常）");
        }
    }
}
