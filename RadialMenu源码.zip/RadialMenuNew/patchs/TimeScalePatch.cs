using HarmonyLib;
using UnityEngine;
using System;
using System.Reflection;
using System.Collections.Generic;
using RadialMenu.Logic;
using RadialMenu.ConfigAndAPI;

namespace RadialMenu.Patches
{
    /// <summary>
    /// 子弹时间管理器，负责控制游戏时间缩放
    /// </summary>
    public static class BulletTimeManager
    {
        private static bool _isBulletTimeActive = false;
        private static float _originalTimeScale = 1.0f;
        private static float _originalFixedDeltaTime = 0.02f;
        
        /// <summary>
        /// 是否启用了子弹时间
        /// </summary>
        public static bool IsBulletTimeActive => _isBulletTimeActive;
        
        /// <summary>
        /// 启用子弹时间
        /// </summary>
        public static void EnableBulletTime()
        {
            if (_isBulletTimeActive) return;
            
            try
            {
                // 保存原始时间设置
                _originalTimeScale = Time.timeScale;
                _originalFixedDeltaTime = Time.fixedDeltaTime;
                
                // 从配置获取子弹时间倍率
                float bulletTimeScale = RadialMenuSetting.BulletTimeMultiplier;
                
                // 应用子弹时间
                Time.timeScale = bulletTimeScale;
                Time.fixedDeltaTime = 0.02f * bulletTimeScale;
                
                _isBulletTimeActive = true;
                Log.DebugMsg($"子弹时间已启用，倍率: {bulletTimeScale}, Time.timeScale: {Time.timeScale}");
            }
            catch (Exception ex)
            {
                Log.Error("启用子弹时间时发生异常", ex);
            }
        }
        
        /// <summary>
        /// 禁用子弹时间，恢复正常时间
        /// </summary>
        public static void DisableBulletTime()
        {
            if (!_isBulletTimeActive) return;
            
            try
            {
                // 恢复正常时间设置
                Time.timeScale = _originalTimeScale;
                Time.fixedDeltaTime = _originalFixedDeltaTime;
                
                _isBulletTimeActive = false;
                Log.DebugMsg($"子弹时间已禁用，恢复正常时间，Time.timeScale: {Time.timeScale}");
            }
            catch (Exception ex)
            {
                Log.Error("禁用子弹时间时发生异常", ex);
            }
        }
        
        /// <summary>
        /// 强制恢复正常时间（安全措施）
        /// </summary>
        public static void ForceResetTime()
        {
            try
            {
                Time.timeScale = 1.0f;
                Time.fixedDeltaTime = 0.02f;
                _isBulletTimeActive = false;
                Log.DebugMsg("强制重置时间到正常状态");
            }
            catch (Exception ex)
            {
                Log.Error("强制重置时间时发生异常", ex);
            }
        }
        
        /// <summary>
        /// 更新子弹时间状态，确保时间设置正确
        /// </summary>
        public static void UpdateBulletTime()
        {
            try
            {
                if (_isBulletTimeActive)
                {
                    // 从配置获取子弹时间倍率
                    float bulletTimeScale = RadialMenuSetting.BulletTimeMultiplier;
                    
                    // 确保子弹时间设置保持不变
                    if (Math.Abs(Time.timeScale - bulletTimeScale) > 0.001f)
                    {
                        Log.DebugMsg($"检测到时间缩放被修改为: {Time.timeScale}，强制重置为子弹时间倍率: {bulletTimeScale}");
                        Time.timeScale = bulletTimeScale;
                    }
                    
                    float expectedFixedDelta = 0.02f * bulletTimeScale;
                    if (Math.Abs(Time.fixedDeltaTime - expectedFixedDelta) > 0.0001f)
                    {
                        Log.DebugMsg($"检测到固定时间步长被修改为: {Time.fixedDeltaTime}，强制重置为: {expectedFixedDelta}");
                        Time.fixedDeltaTime = expectedFixedDelta;
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error("更新子弹时间状态时发生异常", ex);
            }
        }
    }
    
    /// <summary>
    /// MonoBehaviour更新补丁已禁用 - 现在使用 BulletTimeUpdater 来维持子弹时间状态
    /// </summary>
    // [HarmonyPatch(typeof(MonoBehaviour), "Update")]
    // public static class MonoBehaviourUpdatePatch
    // {
    //     /// <summary>
    //     /// Postfix 方法，在每帧更新后检查子弹时间状态
    //     /// </summary>
    //     [HarmonyPostfix]
    //     public static void Postfix(MonoBehaviour __instance)
    //     {
    //         try
    //         {
    //             // 只在子弹时间激活时执行检查
    //             if (ModBehaviour.BulletTimeEnabled)
    //             {
    //                 BulletTimeManager.UpdateBulletTime();
    //             }
    //         }
    //         catch (Exception ex)
    //         {
    //             Log.Error("MonoBehaviourUpdatePatch.Postfix 发生异常", ex);
    //         }
    //     }
    // }
}

