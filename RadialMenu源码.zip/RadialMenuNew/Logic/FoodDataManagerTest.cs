using System;
using System.Linq;

namespace RadialMenu.Logic
{
    /// <summary>
    /// 食物数据管理器测试类
    /// 用于验证数据存储和查询功能
    /// </summary>
    public static class FoodDataManagerTest
    {
        /// <summary>
        /// 运行所有测试
        /// </summary>
        public static void RunAllTests()
        {
            try
            {
                Log.DebugMsg("[FoodDataManagerTest] 开始运行测试...");
                
                TestBasicQuery();
                TestNonExistentItem();
                TestAllDataIntegrity();
                
                Log.DebugMsg("[FoodDataManagerTest] 所有测试完成");
            }
            catch (Exception ex)
            {
                Log.Error("[FoodDataManagerTest] 测试过程中发生异常", ex);
            }
        }

        /// <summary>
        /// 测试基本查询功能
        /// </summary>
        private static void TestBasicQuery()
        {
            Log.DebugMsg("[FoodDataManagerTest] 测试基本查询功能...");
            
            // 测试已知的数据
            var honeyEnergy = FoodDataManager.GetFoodEnergy(70); // 蜂蜜
            var honeyWater = FoodDataManager.GetFoodWater(70);
            
            if (honeyEnergy == 100 && honeyWater == -60)
            {
                Log.DebugMsg("[FoodDataManagerTest] ✓ 蜂蜜数据查询正确: 能量=100, 水分=-60");
            }
            else
            {
                Log.DebugMsg($"[FoodDataManagerTest] ✗ 蜂蜜数据查询错误: 期望能量=100,水分=-60, 实际能量={honeyEnergy},水分={honeyWater}");
            }

            var waterEnergy = FoodDataManager.GetFoodEnergy(428); // 瓶装水
            var waterWater = FoodDataManager.GetFoodWater(428);
            
            if (waterEnergy == 0 && waterWater == 60)
            {
                Log.DebugMsg("[FoodDataManagerTest] ✓ 瓶装水数据查询正确: 能量=0, 水分=60");
            }
            else
            {
                Log.DebugMsg($"[FoodDataManagerTest] ✗ 瓶装水数据查询错误: 期望能量=0,水分=60, 实际能量={waterEnergy},水分={waterWater}");
            }

            // 测试完整数据对象查询
            var foodData = FoodDataManager.GetFoodData(115); // 酸奶
            if (foodData != null && foodData.DisplayName == "酸奶" && foodData.Energy == 40 && foodData.Water == 20)
            {
                Log.DebugMsg("[FoodDataManagerTest] ✓ 酸奶完整数据查询正确");
            }
            else
            {
                Log.DebugMsg($"[FoodDataManagerTest] ✗ 酸奶完整数据查询错误");
            }
        }

        /// <summary>
        /// 测试不存在的物品查询
        /// </summary>
        private static void TestNonExistentItem()
        {
            Log.DebugMsg("[FoodDataManagerTest] 测试不存在的物品查询...");
            
            var nonExistentEnergy = FoodDataManager.GetFoodEnergy(99999);
            var nonExistentWater = FoodDataManager.GetFoodWater(99999);
            var nonExistentData = FoodDataManager.GetFoodData(99999);
            var containsNonExistent = FoodDataManager.ContainsFoodData(99999);
            
            if (nonExistentEnergy == 0 && nonExistentWater == 0 && nonExistentData == null && !containsNonExistent)
            {
                Log.DebugMsg("[FoodDataManagerTest] ✓ 不存在物品查询处理正确");
            }
            else
            {
                Log.DebugMsg("[FoodDataManagerTest] ✗ 不存在物品查询处理错误");
            }
        }

        /// <summary>
        /// 测试所有数据完整性
        /// </summary>
        private static void TestAllDataIntegrity()
        {
            Log.DebugMsg("[FoodDataManagerTest] 测试所有数据完整性...");
            
            var allFoodData = FoodDataManager.GetAllFoodData().ToList();
            var expectedCount = 28; // 食物数据.txt中有28条数据（不包括标题行）
            
            if (allFoodData.Count == expectedCount)
            {
                Log.DebugMsg($"[FoodDataManagerTest] ✓ 数据数量正确: {allFoodData.Count}");
            }
            else
            {
                Log.DebugMsg($"[FoodDataManagerTest] ✗ 数据数量错误: 期望{expectedCount}, 实际{allFoodData.Count}");
            }

            // 检查是否有重复的TypeID
            var typeIds = allFoodData.Select(fd => fd.TypeID).ToList();
            var distinctTypeIds = typeIds.Distinct().ToList();
            
            if (typeIds.Count == distinctTypeIds.Count)
            {
                Log.DebugMsg("[FoodDataManagerTest] ✓ 没有重复的TypeID");
            }
            else
            {
                Log.DebugMsg("[FoodDataManagerTest] ✗ 存在重复的TypeID");
            }

            // 检查几个关键数据点
            var keyTests = new[]
            {
                (12, "焗豆罐头", 40, 0),
                (68, "巧克力", 55, -10),
                (105, "可可奶", 20, 25),
                (883, "蛋白粉", 100, -30),
                (1256, "灵魂私酒", 50, -100)
            };

            foreach (var (typeId, expectedName, expectedEnergy, expectedWater) in keyTests)
            {
                var data = FoodDataManager.GetFoodData(typeId);
                if (data != null && data.DisplayName == expectedName && data.Energy == expectedEnergy && data.Water == expectedWater)
                {
                    Log.DebugMsg($"[FoodDataManagerTest] ✓ {expectedName}数据正确");
                }
                else
                {
                    Log.DebugMsg($"[FoodDataManagerTest] ✗ {expectedName}数据错误");
                }
            }
        }
    }
}