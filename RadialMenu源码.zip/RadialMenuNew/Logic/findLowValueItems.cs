// File: Logic/FindLowPriceToWeightItems.cs
using System;
using System.Collections.Generic;
using System.Linq;
using RadialMenu.Logic;
using ItemStatsSystem;
using Duckov.UI;
using RadialMenu.ConfigAndAPI;
using UnityEngine;

namespace RadialMenu.Logic
{
    /// <summary>
    /// 查找玩家背包中"价格 ÷ 重量"比值最低的物品（价重比最低 = 最不划算）。
    /// 支持热加载：根据 RadialMenuSetting.ShowLowValueFood 决定是否把 Food 类型物品纳入候选。
    /// 说明：为保证热加载立即生效，方法在运行时读取 RadialMenuSetting（简单且可靠）。
    /// 如果你更在意性能，可启用静态缓存并订阅 RadialMenuSetting 的事件回调（见下方注释）。
    /// </summary>
    public static class FindLowPriceToWeightItems
    {
        // ---------- 可选：缓存 + 订阅模式（默认不开启）
        // 优点：在频繁调用且对性能敏感的场景下，可以减少每次对 RadialMenuSetting 的访问开销。
        // 缺点：需要额外确保订阅回调在主线程或安全地更新缓存。
        //
        // 如果想启用：把 `USE_CACHED_CONFIG = true` 并确保 RadialMenuSetting 可用且在运行时会触发回调。
        private const bool USE_CACHED_CONFIG = false;

        private static volatile bool _cached_showLowValueFood = true;
        private static volatile bool _cacheInitialized = false;

        static FindLowPriceToWeightItems()
        {
            if (!USE_CACHED_CONFIG) return;

            try
            {
                // 初始化缓存（如果 RadialMenuSetting 尚未初始化，这里可能仍然取默认）。
                _cached_showLowValueFood = RadialMenuSetting.ShowLowValueFood;
                _cacheInitialized = true;

                // 订阅配置变更回调：当配置更改时，更新本地缓存
                RadialMenuSetting.OnShowLowValueFoodChanged += (value) =>
                {
                    try
                    {
                        _cached_showLowValueFood = value;
                        _cacheInitialized = true;
                    }
                    catch { /* 忽略 */ }
                };
            }
            catch (Exception ex)
            {
                Log.Warn($"FindLowPriceToWeightItems: 无法初始化配置缓存: {ex.Message}");
                _cacheInitialized = false;
            }
        }

        public static Item? GetLowestPriceToWeightItem(out float lowestRatio)
        {
            lowestRatio = float.PositiveInfinity;

            // 决定是否包含 Food 类型物品：两种方式任选其一
            bool showLowValueFood;
            if (USE_CACHED_CONFIG)
            {
                if (!_cacheInitialized)
                {
                    // fallback：直接读取配置
                    showLowValueFood = RadialMenuSetting.ShowLowValueFood;
                    _cached_showLowValueFood = showLowValueFood;
                    _cacheInitialized = true;
                }
                else
                {
                    showLowValueFood = _cached_showLowValueFood;
                }
            }
            else
            {
                // 直接读取配置（最简单、最可靠的热加载方式）
                showLowValueFood = RadialMenuSetting.ShowLowValueFood;
            }

            try
            {
                var items = InventoryHelper.GetPlayerAndPetItems();
                if (items == null || items.Count == 0)
                {
                    Log.DebugMsg("GetLowestPriceToWeightItem: 未找到任何物品。");
                    return null;
                }

                // 先收集那些“禁止进入内部遍历”的容器：
                // 条件 1: Tags 同时含 "Weapon" 和 "Gun"（认为这类物品的内部不应被遍历）
                // 条件 2: TypeID == 882 （你的注释提到这是某种收纳包）
                var excludedContainers = new HashSet<Item>();
                foreach (var it in items)
                {
                    if (it == null) continue;

                    try
                    {
                        bool hasWeapon = false;
                        bool hasGun = false;

                        if (it.Tags != null && it.Tags.Count > 0)
                        {
                            foreach (var t in it.Tags)
                            {
                                var name = GetTagNameSafe(t);
                                if (string.Equals(name, "Weapon", StringComparison.OrdinalIgnoreCase)) hasWeapon = true;
                                if (string.Equals(name, "Gun", StringComparison.OrdinalIgnoreCase)) hasGun = true;
                                // 注意：这里不把 Food 参与 isWeaponAndGun 的判断（语义更清晰）
                            }
                        }

                        bool isWeaponAndGun = hasWeapon && hasGun;

                        if (isWeaponAndGun || it.TypeID == 882)
                        {
                            excludedContainers.Add(it);
                        }
                    }
                    catch
                    {
                        // 忽略单个读取错误
                    }
                }

                Item? worstItem = null;

                foreach (var item in items)
                {
                    if (item == null) continue;

                    try
                    {
                        // 如果该物品位于任意 excludedContainers 的内部（但本身不是容器），则跳过它
                        if (IsInsideExcludedContainer(item, excludedContainers))
                        {
                            continue;
                        }

                        // 如果配置要求“不要显示低价值的食物”，则跳过所有带 Food 标签的物品
                        if (!showLowValueFood)
                        {
                            bool isFood = false;
                            if (item.Tags != null)
                            {
                                foreach (var t in item.Tags)
                                {
                                    if (string.Equals(GetTagNameSafe(t), "Food", StringComparison.OrdinalIgnoreCase))
                                    {
                                        isFood = true;
                                        break;
                                    }
                                }
                            }
                            if (isFood)
                                continue;
                        }

                        // 计算比值
                        float oneWeight = SafeFloat(item.SelfWeight);
                        float totalWeight = SafeFloat(item.TotalWeight);
                        float value = SafeFloat(item.Value);
                        int stackCount = Math.Max(item.StackCount, 1);
                        float totalValue;

                        try
                        {
                            totalValue = item.GetTotalRawValue();
                        }
                        catch
                        {
                            totalValue = value * stackCount;
                        }

                        bool stackable = item.Stackable;

                        float ratio;

                        if (stackable)
                        {
                            if (totalWeight <= 0f || totalValue <= 0f) continue;
                            ratio = totalValue / totalWeight;
                        }
                        else
                        {
                            if (oneWeight <= 0f || value <= 0f) continue;
                            ratio = value / oneWeight;
                        }

                        if (float.IsNaN(ratio)) continue;

                        if (ratio < lowestRatio)
                        {
                            lowestRatio = ratio;
                            worstItem = item;
                        }
                    }
                    catch (Exception itEx)
                    {
                        Log.Error($"GetLowestPriceToWeightItem: 计算物品 {item?.DisplayName ?? "Unknown"} 时出错", itEx);
                    }
                }

                if (worstItem != null)
                {
                    Log.Info($"FindLowPriceToWeightItems: 找到最低价重比物品 -> {worstItem.DisplayName}，比值 = {lowestRatio}");
                }
                else
                {
                    Log.DebugMsg("FindLowPriceToWeightItems: 未能确定最低比值物品。");
                }

                return worstItem;
            }
            catch (Exception ex)
            {
                Log.Error("GetLowestPriceToWeightItem: 遍历背包物品时发生异常。", ex);
                return null;
            }
        }

        public static string FindLowestPriceToWeightItemDescription()
        {
            var item = GetLowestPriceToWeightItem(out var ratio);
            if (item == null)
                return "未找到符合条件的物品。";

            bool stackable = item.Stackable;
            string stackInfo = stackable
                ? $"(堆叠数量={item.StackCount}, 总价={SafeGetTotalValue(item)}, 总重={item.TotalWeight})"
                : $"(单件, 价格={item.Value}, 重量={item.SelfWeight})";

            return $"最低价重比物品: {item.DisplayName} {stackInfo}, 比值={ratio}";
        }

        private static float SafeGetTotalValue(Item item)
        {
            try { return item.GetTotalRawValue(); }
            catch { return item.Value * Math.Max(item.StackCount, 1); }
        }

        #region 辅助函数（基于已知 API）

        // 尝试安全读取 tag 的 name（tag 对象在 log 中是有 .name 字段）
        private static string GetTagNameSafe(object tag)
        {
            if (tag == null) return string.Empty;
            try
            {
                var t = tag.GetType();
                var prop = t.GetProperty("name");
                if (prop != null)
                {
                    var v = prop.GetValue(tag);
                    return v?.ToString() ?? string.Empty;
                }
                var field = t.GetField("name");
                if (field != null)
                {
                    var v = field.GetValue(tag);
                    return v?.ToString() ?? string.Empty;
                }

                return tag.ToString() ?? string.Empty;
            }
            catch
            {
                return tag.ToString() ?? string.Empty;
            }
        }

        private static bool IsInsideExcludedContainer(Item item, HashSet<Item> excludedContainers)
        {
            if (item == null || excludedContainers == null || excludedContainers.Count == 0) return false;
            if (excludedContainers.Contains(item)) return false; // 容器自身不算“在其内部”

            Item currentParent = item.ParentItem;
            int depth = 0;
            while (currentParent != null && depth < 20)
            {
                if (excludedContainers.Contains(currentParent)) return true;
                currentParent = currentParent.ParentItem;
                depth++;
            }

            return false;
        }

        private static float SafeFloat(float f) => f; // 占位：如果需要对异常值/特殊情况处理可在此统一处理

        #endregion
    }
}
