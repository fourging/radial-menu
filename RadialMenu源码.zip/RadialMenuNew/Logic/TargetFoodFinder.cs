using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using ItemStatsSystem;
using RadialMenu.UI;

namespace RadialMenu.Logic
{
    /// <summary>
    /// 食物查找工具类（优化版）
    /// 主要思路：
    /// 1) 根据玩家当前水/能量缺失比例计算需求权重（越缺的维度权重越高）
    /// 2) 将每个候选食物的能量/水分按玩家最大值归一化，得到对缺失的贡献度
    /// 3) 合成“效用值”，再除以物品价值（性价比），对不可用或有负面影响的项施加惩罚
    /// 4) 特例：TypeID==115 当两维同时较高缺失时优先返回（保持原行为）
    /// 5) 保持“可用优先 -> 否则降级返回最低价值”的后备策略
    /// </summary>
    public static class FoodFinder
    {
        // 调参常量（可根据感觉微调）
        private const float DualDeficitThreshold = 0.25f;    // 双维同时缺失阈值（你原来用 0.25）
        private const float UnusablePenaltyFactor = 0.6f;    // 不可用物品最终分数倍率（低于可用优先）
        private const float NegativeEffectPenaltyScale = 2.5f; // 当物品对当前更需要维度有负面影响时的惩罚强度
        private const float MinAcceptableScore = 0.0001f;    // 防止除零或极小分数问题

        public static Item FindTargetFood()
        {
            try
            {
                // 拉取玩家与宠物背包条目并展开为 Item 列表
                IEnumerable itemsRaw = InventoryHelper.GetPlayerAndPetItems();
                if (itemsRaw == null)
                {
                    Log.DebugMsg("[FindTargetFood] 未获取到物品数据");
                    return null!;
                }

                var allItems = new List<Item>();
                foreach (var entry in itemsRaw)
                {
                    try { ItemUseController.ExtractItemsFromEntry(entry, allItems); }
                    catch (Exception ex)
                    {
                        Log.DebugMsg($"[FindTargetFood] 忽略展开失败的条目：{ex.Message}");
                    }
                }

                // 只考虑带 Food 标签的物品
                var candidates = allItems
                    .Where(i => i != null && i.Tags != null && i.Tags.Contains("Food"))
                    .ToList();

                if (candidates.Count == 0)
                {
                    Log.DebugMsg("[FindTargetFood] 未找到带有 Food 标签的物品");
                    return null!;
                }

                // 可用候选（UsageUtilities 判定）
                var usableCandidates = candidates
                    .Where(i => i.UsageUtilities != null && i.UsageUtilities.IsUsable(i, CharacterMainControl.Main))
                    .ToList();

                // 安全物品价值获取（值越小表示更便宜）
                float SafeValue(Item i) => (i != null && i.Value > 0f) ? i.Value : float.MaxValue;

                // 读取玩家当前水/能量与最大值，计算损失比例
                float curWater = 0f, maxWater = 1f, curEnergy = 0f, maxEnergy = 1f;
                try
                {
                    var main = CharacterMainControl.Main;
                    if (main != null)
                    {
                        curWater = main.CurrentWater;
                        maxWater = Math.Max(1f, main.MaxWater);
                        curEnergy = main.CurrentEnergy;
                        maxEnergy = Math.Max(1f, main.MaxEnergy);
                    }
                    else
                    {
                        Log.DebugMsg("[FindTargetFood] CharacterMainControl.Main 为 null，使用默认值");
                    }
                }
                catch (Exception ex)
                {
                    Log.DebugMsg($"[FindTargetFood] 读取玩家属性失败：{ex.Message}，将使用默认值");
                }

                float waterDeficit = Math.Max(0f, maxWater - curWater);
                float energyDeficit = Math.Max(0f, maxEnergy - curEnergy);

                float waterDeficitRatio = waterDeficit / Math.Max(1f, maxWater);
                float energyDeficitRatio = energyDeficit / Math.Max(1f, maxEnergy);

                Log.DebugMsg($"[FindTargetFood] 当前水/能量: {curWater}/{maxWater}，{curEnergy}/{maxEnergy}；损失比: water={waterDeficitRatio:F3}, energy={energyDeficitRatio:F3}");

                // 特例：TypeID == 115，当两维损失都超过阈值时优先返回（可用优先，存在则降级返回）
                if (waterDeficitRatio > DualDeficitThreshold && energyDeficitRatio > DualDeficitThreshold)
                {
                    var usable115 = usableCandidates.FirstOrDefault(i => i.TypeID == 115);
                    if (usable115 != null)
                    {
                        Log.DebugMsg("[FindTargetFood] 特例：找到可用的 TypeID==115，优先返回");
                        return usable115;
                    }

                    var exist115 = candidates.FirstOrDefault(i => i.TypeID == 115);
                    if (exist115 != null)
                    {
                        Log.DebugMsg("[FindTargetFood] 特例：TypeID==115 存在但不可用，降级返回（可能不可用）");
                        return exist115;
                    }

                    Log.DebugMsg("[FindTargetFood] 特例：TypeID==115 未找到，继续常规选择");
                }

                // 计算需求权重（越缺的维度权重越高）
                float totalDeficitRatio = waterDeficitRatio + energyDeficitRatio;
                float weightWater = totalDeficitRatio > 0f ? waterDeficitRatio / totalDeficitRatio : 0.5f;
                float weightEnergy = totalDeficitRatio > 0f ? energyDeficitRatio / totalDeficitRatio : 0.5f;

                // 评分函数：根据对当前缺失的贡献度与价值计算最终分数（分数越高越优先）
                Item best = null!;
                float bestScore = float.NegativeInfinity;

                IEnumerable<Item> evaluateSet = candidates; // 优先在所有候选中评分，后续会优先选择可用的高分项
                foreach (var it in evaluateSet)
                {
                    try
                    {
                        // 尝试从你的 FoodDataManager 获取该物品的能量/水分数值
                        var fd = FoodDataManager.GetFoodData(it.TypeID);
                        int foodEnergy = fd?.Energy ?? 0;
                        int foodWater = fd?.Water ?? 0;

                        // 将食物的数值归一化到玩家最大值上，便于比较（限制区间 -1 .. +1）
                        float energyNorm = maxEnergy > 0f ? (float)foodEnergy / maxEnergy : 0f;
                        float waterNorm = maxWater > 0f ? (float)foodWater / maxWater : 0f;

                        // 贡献：正向贡献按 0..1 截断，负向贡献保留用于惩罚
                        float energyPos = Clamp01(energyNorm);
                        float waterPos = Clamp01(waterNorm);

                        // 对缺失的匹配程度（按权重合并）
                        float benefit = weightEnergy * energyPos + weightWater * waterPos;

                        // 负面影响惩罚：当当前更需要某维度，而物品对该维度是负值时强烈惩罚
                        float penalty = 0f;
                        // 若玩家非常缺水，但物品会减水，惩罚更重
                        if (waterNorm < 0f && weightWater > 0.15f)
                        {
                            penalty += Math.Abs(waterNorm) * NegativeEffectPenaltyScale * weightWater;
                        }
                        if (energyNorm < 0f && weightEnergy > 0.15f)
                        {
                            penalty += Math.Abs(energyNorm) * NegativeEffectPenaltyScale * weightEnergy;
                        }

                        // 基础 raw score（可以为负）
                        float rawScore = benefit - penalty;

                        // 如果物品不可用，打折（降级）
                        bool usable = it.UsageUtilities != null && it.UsageUtilities.IsUsable(it, CharacterMainControl.Main);
                        if (!usable)
                            rawScore *= UnusablePenaltyFactor;

                        // 特例提升：TypeID==115 且双维都高缺失时，加成（保持你原先逻辑）
                        if (it.TypeID == 115 && waterDeficitRatio > DualDeficitThreshold && energyDeficitRatio > DualDeficitThreshold)
                            rawScore += 1.0f;

                        // 把价格考虑进来：性价比 = rawScore / (value + 1)
                        // 注意：价值越小越便宜，分母越小更有利
                        float value = SafeValue(it);
                        if (value <= 0f || float.IsInfinity(value) || float.IsNaN(value))
                            value = 1000f; // 一个较大的默认“高成本”，避免异常影响选择

                        float finalScore = rawScore / (value + 1f);

                        // 记录可用项优先：若两个 finalScore 非常接近，优先选择可用的
                        // 通过给 finalScore 的可用项加一个微小偏移实现优先级
                        if (usable)
                            finalScore += 1e-4f;

                        // 记录最优
                        if (finalScore > bestScore)
                        {
                            bestScore = finalScore;
                            best = it;
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.DebugMsg($"[FindTargetFood] 评分单个物品时出错（TypeID={it.TypeID}）：{ex.Message}");
                    }
                }

                // 若找到了正分或非极小分项且可用 -> 返回
                if (best != null)
                {
                    // 如果最佳项不可用，但存在可用项且分数接近，则优先可用项（保险逻辑）
                    if (!(best.UsageUtilities != null && best.UsageUtilities.IsUsable(best, CharacterMainControl.Main)))
                    {
                        var usableBest = candidates
                            .Where(i => i.UsageUtilities != null && i.UsageUtilities.IsUsable(i, CharacterMainControl.Main))
                            .OrderByDescending(i =>
                            {
                                // 重新用较简单规则在可用集里挑最合适的（性价比）
                                var fd = FoodDataManager.GetFoodData(i.TypeID);
                                float e = fd?.Energy ?? 0;
                                float w = fd?.Water ?? 0;
                                float eN = maxEnergy > 0 ? e / maxEnergy : 0;
                                float wN = maxWater > 0 ? w / maxWater : 0;
                                float benefit = weightEnergy * Clamp01(eN) + weightWater * Clamp01(wN);
                                float val = SafeValue(i);
                                if (val <= 0 || float.IsInfinity(val) || float.IsNaN(val)) val = 1000f;
                                return benefit / (val + 1f);
                            })
                            .FirstOrDefault();

                        if (usableBest != null)
                        {
                            Log.DebugMsg($"[FindTargetFood] 最优项不可用，切换到可用集中的最佳项：{usableBest.DisplayName}");
                            return usableBest;
                        }
                    }

                    Log.DebugMsg($"[FindTargetFood] 选中项：{best.DisplayName}（score={bestScore:F6}）");
                    return best;
                }

                // 回退：如果没有评分出的候选，保持原有行为：优先返回可用中价值最低的
                if (usableCandidates.Count > 0)
                {
                    var fallback = usableCandidates.OrderBy(SafeValue).First();
                    Log.DebugMsg($"[FindTargetFood] 回退到可用中最便宜项：{fallback.DisplayName}");
                    return fallback;
                }

                var fallback2 = candidates.OrderBy(SafeValue).FirstOrDefault();
                if (fallback2 != null)
                {
                    Log.DebugMsg($"[FindTargetFood] 无可用项，降级返回最便宜项：{fallback2.DisplayName}");
                    return fallback2;
                }

                Log.DebugMsg("[FindTargetFood] 未能选出食物，返回 null");
                return null!;
            }
            catch (Exception ex)
            {
                Log.Error("[FindTargetFood] 查找食物时发生异常", ex);
                return null!;
            }
        }

        private static float Clamp01(float v) => v < 0f ? 0f : (v > 1f ? 1f : v);
    }
}
