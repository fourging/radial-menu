// 文件路径: D:\CODE\DUCKOVMODS\RADIALMENU\Logic\data\BindingQueries.cs
using System;
using System.Collections.Generic;


namespace RadialMenu.Logic
{
    public static class BindingQueries
    {
        private static readonly object es3Lock = new object(); // 复用 Persistence 中的 lock（这里独立以防循环）

        public static BindingEntry? GetBindingForSector(int sector)
        {
            return BindingPersistence.LoadBindingFromES3(sector);
        }

        public static bool TryGetBindingForSector(int sector, out BindingEntry? entry)
        {
            var e = BindingPersistence.LoadBindingFromES3(sector);
            if (e != null)
            {
                entry = e;
                return true;
            }
            entry = null;
            return false;
        }

        public static BindingEntry? FindBindingByItemId(string itemId)
        {
            lock (es3Lock)
            {
                try
                {
                    string filePath = BindingPersistence.GetBindingsFilePath();
                    var sectors = ES3.KeyExists(BindingPersistence.SectorListKey, filePath) ? ES3.Load<List<int>>(BindingPersistence.SectorListKey, filePath) : new List<int>();
                    foreach (var s in sectors)
                    {
                        var e = BindingPersistence.LoadBindingFromES3(s);
                        if (e != null && !string.IsNullOrEmpty(e.itemId) && e.itemId == itemId)
                            return e;
                    }
                }
                catch (Exception ex)
                {
                    Log.Error("[BindingManager] FindBindingByItemId 失败", ex);
                }
                return null;
            }
        }

        public static Dictionary<int, BindingEntry> GetAllBindings()
        {
            var dict = new Dictionary<int, BindingEntry>();
            lock (es3Lock)
            {
                try
                {
                    string filePath = BindingPersistence.GetBindingsFilePath();
                    var sectors = ES3.KeyExists(BindingPersistence.SectorListKey, filePath) ? ES3.Load<List<int>>(BindingPersistence.SectorListKey, filePath) : new List<int>();
                    foreach (var s in sectors)
                    {
                        var e = BindingPersistence.LoadBindingFromES3(s);
                        if (e != null)
                            dict[s] = e;
                    }
                }
                catch (Exception ex)
                {
                    Log.Error("[BindingManager] GetAllBindings 失败", ex);
                }
            }
            return dict;
        }

        public static void ClearBindingForSector(int sector)
        {
            BindingPersistence.DeleteBindingFromES3(sector);
            Log.Info($"[BindingManager] 已清除扇区 {sector} 的绑定（ES3）");
        }

        public static void ClearAllBindings()
        {
            lock (es3Lock)
            {
                try
                {
                    string filePath = BindingPersistence.GetBindingsFilePath();
                    var sectors = ES3.KeyExists(BindingPersistence.SectorListKey, filePath) ? ES3.Load<List<int>>(BindingPersistence.SectorListKey, filePath) : new List<int>();
                    foreach (var s in sectors)
                    {
                        BindingPersistence.DeleteBindingFromES3(s);
                    }
                    ES3.DeleteKey(BindingPersistence.SectorListKey, filePath);
                    Log.Info("[BindingManager] 已清除全部绑定（ES3）");
                }
                catch (Exception ex)
                {
                    Log.Error("[BindingManager] ClearAllBindings 失败", ex);
                }
            }
        }
    }
}