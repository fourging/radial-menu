using System;
using System.Collections;
using UnityEngine;
using RadialMenu.UI;
using RadialMenu.Logic.Utils;
using ItemStatsSystem;
using Duckov.UI;
using RadialMenu.Patches;


namespace RadialMenu.Logic
{
    /// <summary>
    /// BindingManager —— 主入口（绑定流程、构建 Entry）
    /// </summary>
    public static class BindingManager
    {
        public static void StartBind(MonoBehaviour caller, RadialMenu.UI.RadialMenu menu)
        {
            if (caller == null)
            {
                Log.Error("[BindingManager] StartBind: caller 为 null，无法启动协程");
                return;
            }
            if (menu == null)
            {
                Log.Error("[BindingManager] StartBind: menu 为 null，无法启动绑定");
                return;
            }

            caller.StartCoroutine(BindSelectedItemToSectorCoroutine(menu));
        }

        private static IEnumerator BindSelectedItemToSectorCoroutine(RadialMenu.UI.RadialMenu menu)
        {
            if (View.ActiveView is not LootView)
            {
                Log.DebugMsg("[BindingManager] 当前界面不是 LootView，取消绑定流程。");
                yield break;
            }

            Item selectedItem = ItemUIUtilities.SelectedItem;
            if (selectedItem == null)
            {
                Log.DebugMsg("[BindingManager] 当前没有选中物品，取消绑定流程。");
                yield break;
            }

            if (!BindingHelpers.IsValidForBinding(selectedItem))
            {
                speakup.ShowDialogue(LocalizationHelper.Get("UI_BindingNotAllowed"), CharacterMainControl.Main.transform, duration: 2f);
                Log.Info($"[BindingManager] 物品不满足可绑定类型，取消绑定。物品：{selectedItem.DisplayName}");
                yield break;
            }

            Log.Info($"[BindingManager] 开始绑定流程，物品：{selectedItem.DisplayName}");

            bool selectionConfirmed = false;
            int confirmedIndex = -1;

            Action<int> onConfirmed = (idx) =>
            {
                selectionConfirmed = true;
                confirmedIndex = idx;
                Log.DebugMsg($"[BindingManager] 捕获到 OnSectorConfirmed：{idx}");
            };

            Action onClosed = () =>
            {
                Log.DebugMsg("[BindingManager] 捕获到 OnMenuClosed");
            };

            try
            {
                menu.OnSectorConfirmed += onConfirmed;
                menu.OnMenuClosed += onClosed;
            }
            catch (Exception ex)
            {
                Log.Error("[BindingManager] 订阅 RadialMenu 事件时出错", ex);
            }

            menu.ShowMenu();

            while (menu.IsMenuActive)
                yield return null;

            try
            {
                menu.OnSectorConfirmed -= onConfirmed;
                menu.OnMenuClosed -= onClosed;
            }
            catch (Exception ex)
            {
                Log.Error("[BindingManager] 解绑 RadialMenu 事件时出错", ex);
            }

            int finalIndex = -1;
            if (selectionConfirmed)
            {
                finalIndex = confirmedIndex;
            }
            else
            {
                try
                {
                    finalIndex = menu.LastConfirmedSector;
                }
                catch (Exception ex)
                {
                    Log.Error("[BindingManager] 读取 menu.LastConfirmedSector 失败", ex);
                }
            }

            if (finalIndex < 0)
            {
                Log.Info("[BindingManager] 菜单关闭但未选择扇区，取消绑定。");
                yield break;
            }

            PerformItemBinding(selectedItem, finalIndex);
        }

        public static void PerformItemBinding(Item selectedItem, int sectorIndex, bool autoBound = false)
        {
            try
            {
                // 在绑定物品时关闭物品详情页面
                int closedCount = UIHelper.CloseAllItemDetailsWindows();
                if (closedCount > 0)
                {
                    Log.Info($"[BindingManager] 绑定物品时自动关闭了 {closedCount} 个物品详情页面");
                }

                var entry = BuildBindingEntry(selectedItem, sectorIndex, autoBound);
                BindingPersistence.SaveBindingToES3(entry);

                Log.Info($"[BindingManager] 已将绑定持久化（ES3）：扇区={entry.sectorIndex}，TypeID={entry.itemId}，DisplayName={entry.displayName}，autoBound={entry.autoBound}");
            }
            catch (Exception ex)
            {
                Log.Error("[BindingManager] 写入 ES3 绑定时发生异常", ex);
            }
        }

        private static BindingEntry BuildBindingEntry(Item selectedItem, int sectorIndex, bool autoBound)
        {
            string typeIdStr = BindingHelpers.TryGetItemTypeId(selectedItem);
            string displayName = !string.IsNullOrEmpty(selectedItem.DisplayName)
                ? selectedItem.DisplayName
                : (typeIdStr ?? "unknown");

            int instanceId = 0;
            try
            {
                instanceId = selectedItem.GetInstanceID();
            }
            catch { }

            string snapshot = BindingHelpers.BuildItemSnapshot(selectedItem);

            return new BindingEntry
            {
                sectorIndex = sectorIndex,
                itemId = typeIdStr ?? "unknown",
                item = null, // 不持久化 Item 对象
                displayName = displayName,
                timestamp = DateTime.UtcNow.ToString("o"),
                instanceId = instanceId,
                itemSnapshot = snapshot,
                autoBound = autoBound
            };
        }
    }
}