using System;
using ItemStatsSystem;

namespace RadialMenu.Logic
{
    /// <summary>
    /// 内存中的绑定条目（注意：item 字段为 NonSerialized，不会被 ES3 持久化）
    /// </summary>
    [Serializable]
    public class BindingEntry
    {
        public int sectorIndex;
        public string itemId = "";        // 表示 TypeID（字符串形式）
        [NonSerialized]
        public Item? item;                // 运行时引用（不持久化）
        public string displayName = "";
        public string timestamp = "";

        // 额外的持久化字段（由 BindingManager 存储为独立 ES3 key）
        public int instanceId = 0;        // 运行时 Instance ID（仅用于会话内尝试恢复）
        public string itemSnapshot = "";  // 可选：保存文本快照（例如 ITEM DETAILS）
        public bool autoBound;    // 新增：是否由系统自动绑定（true = 系统自动绑定，可被自动更新）
    }
}