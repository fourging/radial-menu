// 文件路径: D:\CODE\DUCKOVMODS\RADIALMENU\Logic\data\BindingPersistence.cs
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEngine;
using System.Text;

namespace RadialMenu.Logic
{
    public static class BindingPersistence
    {
        // ES3 keys
        public const string SectorListKey = "RadialMenu.Bindings.Sectors"; // 存储 List<int> 的主键
        private const string BindingKeyPrefix = "RadialMenu.Binding.";     // 完整 key: RadialMenu.Binding.{sector}.{field}

        private static readonly object es3Lock = new object(); // 保护 ES3 操作（保险）

        // 常量：文件名（可改）
        private const string BindingsFileName = "RadialMenu.Bindings.es3";

        /// <summary>
        /// 返回要用于 ES3 的绝对文件路径（优先：mod dll 文件夹）
        /// 如果无法从 assembly 获取到文件夹（某些环境），回退到 Application.persistentDataPath
        /// </summary>
        public static string GetBindingsFilePath()
        {
            // 优先 persistentDataPath
            try
            {
                var pdp = Application.persistentDataPath;
                if (!string.IsNullOrEmpty(pdp))
                {
                    if (!Directory.Exists(pdp)) Directory.CreateDirectory(pdp);
                    return Path.Combine(pdp, BindingsFileName);
                }
            }
            catch { }

            try
            {
                // 1. 尝试用当前执行的 assembly 路径（适用于大多数 mod 案例）
                var asmLocation = Assembly.GetExecutingAssembly().Location;
                if (!string.IsNullOrEmpty(asmLocation))
                {
                    var asmDir = Path.GetDirectoryName(asmLocation);
                    if (!string.IsNullOrEmpty(asmDir))
                    {
                        // 确保目录存在（通常存在，因为 dll 在该目录）
                        if (!System.IO.Directory.Exists(asmDir))
                            System.IO.Directory.CreateDirectory(asmDir);

                        return Path.Combine(asmDir, BindingsFileName);
                    }
                }
            }
            catch (Exception ex)
            {
                Log.DebugMsg($"[BindingManager] GetBindingsFilePath: 无法从 Assembly 获取路径，原因: {ex.Message}");
            }

            // 2. 兜底到 persistentDataPath（几乎总可写）
            try
            {
                var pdp = Application.persistentDataPath;
                var dir = pdp ?? Application.dataPath; // 最后兜底到 dataPath
                if (!System.IO.Directory.Exists(dir))
                    System.IO.Directory.CreateDirectory(dir);
                return Path.Combine(dir, BindingsFileName);
            }
            catch (Exception ex)
            {
                // 极端情况下，如果连创建都失败，返回文件名（ES3 将使用默认位置）
                Log.Error("[BindingManager] GetBindingsFilePath: 回退路径失败，使用默认文件名", ex);
                return BindingsFileName;
            }
        }

        private static string GetFilePath() => GetBindingsFilePath();  // 简化调用

        public static void DeleteBindingFromES3(int sector)
        {
            lock (es3Lock)
            {
                try
                {
                    string filePath = GetFilePath();
                    string baseKey = BindingKeyPrefix + sector.ToString() + ".";

                    ES3.DeleteKey(baseKey + "TypeID", filePath);
                    ES3.DeleteKey(baseKey + "DisplayName", filePath);
                    ES3.DeleteKey(baseKey + "Timestamp", filePath);
                    ES3.DeleteKey(baseKey + "InstanceID", filePath);
                    ES3.DeleteKey(baseKey + "ItemSnapshot", filePath);
                    ES3.DeleteKey(baseKey + "AutoBound", filePath);

                    // 更新 Sector 列表
                    try
                    {
                        var sectors = ES3.KeyExists(SectorListKey, filePath) ? ES3.Load<List<int>>(SectorListKey, filePath) : new List<int>();
                        if (sectors.Remove(sector))
                        {
                            ES3.Save(SectorListKey, sectors, filePath);
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.Error("[BindingManager] 更新 SectorList 时失败", ex);
                    }
                }
                catch (Exception ex)
                {
                    Log.Error("[BindingManager] DeleteBindingFromES3 失败", ex);
                }
            }
        }

        public static void SaveBindingToES3(BindingEntry entry)
        {
            lock (es3Lock)
            {
                try
                {
                    string filePath = GetFilePath();

                    // 更新 Sector 列表（安全加载）
                    List<int> sectors;
                    try
                    {
                        sectors = ES3.KeyExists(SectorListKey, filePath) ? ES3.Load<List<int>>(SectorListKey, filePath) : new List<int>();
                    }
                    catch
                    {
                        sectors = new List<int>();
                    }

                    if (!sectors.Contains(entry.sectorIndex))
                    {
                        sectors.Add(entry.sectorIndex);
                        try { ES3.Save(SectorListKey, sectors, filePath); } catch (Exception ex) { Log.Error("[BindingManager] 保存 SectorList 失败", ex); }
                    }

                    string baseKey = BindingKeyPrefix + entry.sectorIndex.ToString() + ".";

                    // 写入（包含 autoBound）
                    ES3.Save(baseKey + "TypeID", entry.itemId, filePath);
                    ES3.Save(baseKey + "DisplayName", entry.displayName, filePath);
                    ES3.Save(baseKey + "Timestamp", entry.timestamp, filePath);
                    ES3.Save(baseKey + "InstanceID", entry.instanceId, filePath);
                    ES3.Save(baseKey + "ItemSnapshot", entry.itemSnapshot ?? "", filePath);
                    ES3.Save(baseKey + "AutoBound", entry.autoBound, filePath); // 新增：保存 autoBound

                    // 立即读取回并打印（包含 autoBound）
                    string readTypeId = SafeLoadString(baseKey + "TypeID", "unknown", filePath);
                    string readDisplayName = SafeLoadString(baseKey + "DisplayName", "", filePath);
                    string readTimestamp = SafeLoadString(baseKey + "Timestamp", "", filePath);
                    int readInstanceId = SafeLoadInt(baseKey + "InstanceID", 0, filePath);
                    string readSnapshot = SafeLoadString(baseKey + "ItemSnapshot", "", filePath);
                    bool readAutoBound = ES3.Load<bool>(baseKey + "AutoBound", filePath, false); // 新增：读取 autoBound

                    var info = new StringBuilder();
                    info.AppendLine("\n[BindingManager] Saved Binding (ES3 snapshot) =========");
                    info.AppendLine($"Sector: {entry.sectorIndex}");
                    info.AppendLine($"TypeID (stored): {readTypeId}");
                    info.AppendLine($"DisplayName (stored): {readDisplayName}");
                    info.AppendLine($"Timestamp (stored): {readTimestamp}");
                    info.AppendLine($"InstanceID (stored): {readInstanceId}");
                    info.AppendLine($"AutoBound (stored): {readAutoBound}"); // 新增：打印 autoBound
                    if (!string.IsNullOrEmpty(readSnapshot))
                    {
                        info.AppendLine("--- ItemSnapshot ---");
                        info.AppendLine(readSnapshot);
                    }
                    info.AppendLine("============================================\n");

                    Log.Info(info.ToString());
                }
                catch (Exception ex)
                {
                    Log.Error("[BindingManager] SaveBindingToES3 失败", ex);
                }
            }
        }

        public static BindingEntry? LoadBindingFromES3(int sector)
        {
            lock (es3Lock)
            {
                try
                {
                    string filePath = GetFilePath();
                    string baseKey = BindingKeyPrefix + sector.ToString() + ".";

                    // 如果没有 TypeID 键，说明该扇区未绑定（稳健判断）
                    if (!ES3.KeyExists(baseKey + "TypeID", filePath))
                    {
                        return null;
                    }

                    var entry = new BindingEntry();
                    entry.sectorIndex = sector;

                    entry.itemId = SafeLoadString(baseKey + "TypeID", "unknown", filePath);
                    entry.displayName = SafeLoadString(baseKey + "DisplayName", "", filePath);
                    entry.timestamp = SafeLoadString(baseKey + "Timestamp", "", filePath);
                    entry.instanceId = SafeLoadInt(baseKey + "InstanceID", 0, filePath);
                    entry.itemSnapshot = SafeLoadString(baseKey + "ItemSnapshot", "", filePath);
                    entry.autoBound = ES3.Load<bool>(baseKey + "AutoBound", filePath, false); // 新增：加载 autoBound，默认值 false

                    entry.item = null;

                    return entry;
                }
                catch (Exception ex)
                {
                    Log.Error("[BindingManager] LoadBindingFromES3 失败", ex);
                    return null;
                }
            }
        }

        // ---------------------- ES3 安全加载辅助 ----------------------
        private static string SafeLoadString(string key, string defaultValue, string filePath)
        {
            try
            {
                if (!ES3.KeyExists(key, filePath)) return defaultValue;
                try
                {
                    return ES3.Load<string>(key, filePath);
                }
                catch
                {
                    // 兼容性兜底：如果 Load 抛出错误，返回默认
                    return defaultValue;
                }
            }
            catch (Exception ex)
            {
                Log.Error($"[BindingManager] SafeLoadString 读取 {key} 失败", ex);
                return defaultValue;
            }
        }

        private static int SafeLoadInt(string key, int defaultValue, string filePath)
        {
            try
            {
                if (!ES3.KeyExists(key, filePath)) return defaultValue;
                try
                {
                    return ES3.Load<int>(key, filePath);
                }
                catch
                {
                    return defaultValue;
                }
            }
            catch (Exception ex)
            {
                Log.Error($"[BindingManager] SafeLoadInt 读取 {key} 失败", ex);
                return defaultValue;
            }
        }
    }
}