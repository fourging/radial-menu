using System;
using System.Text;
using ItemStatsSystem;

namespace RadialMenu.Logic
{
    /// <summary>
    /// 判断是不是支持绑定的物品类型
    /// </summary>
    public static class BindingHelpers
    {
        public static bool IsValidForBinding(Item item)
        {
            try
            {
                if (item == null) return false;
                if (ItemTypeChecker.IsMedicine(item)) return true;
                if (ItemTypeChecker.IsFood(item)) return true;
                if (ItemTypeChecker.IsExplosive(item)) return true;
                return false;
            }
            catch (Exception ex)
            {
                Log.Error("[BindingManager] 判断物品类型失败", ex);
                return false;
            }
        }

        public static string TryGetItemTypeId(Item item)
        {
            try
            {
                if (item == null) return "unknown";
                var typeIdProp = item.GetType().GetProperty("TypeID");
                if (typeIdProp != null)
                {
                    var typeIdObj = typeIdProp.GetValue(item);
                    if (typeIdObj != null)
                        return typeIdObj.ToString();
                }

                var typeIdField = item.GetType().GetField("TypeID");
                if (typeIdField != null)
                {
                    var typeIdObj = typeIdField.GetValue(item);
                    if (typeIdObj != null)
                        return typeIdObj.ToString();
                }

                if (!string.IsNullOrEmpty(item.DisplayName)) return item.DisplayName;
                return "unknown";
            }
            catch (Exception ex)
            {
                Log.Error("[BindingManager] 尝试获取物品 TypeID 失败", ex);
                return "unknown";
            }
        }

        public static string BuildItemSnapshot(Item selectedItem)
        {
            try
            {
                if (selectedItem == null) return "";
                var sb = new StringBuilder();
                sb.AppendLine("Snapshot:");
                sb.AppendLine($"DisplayName: {selectedItem.DisplayName}");
                try { sb.AppendLine($"TypeID: {selectedItem.TypeID}"); } catch { }
                try { sb.AppendLine($"InstanceID: {selectedItem.GetInstanceID()}"); } catch { }
                return sb.ToString();
            }
            catch
            {
                return "";
            }
        }
    }
}