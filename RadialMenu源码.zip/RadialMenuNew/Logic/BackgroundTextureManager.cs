using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using RadialMenu.Logic;

namespace RadialMenu.Logic
{
    /// <summary>
    /// 背景纹理管理器 - 负责检测、加载和管理不同扇区数量的背景图片套装
    /// </summary>
    public static class BackgroundTextureManager
    {
        // 缓存已检测的背景套装
        private static Dictionary<int, List<string>> _detectedStyles = new Dictionary<int, List<string>>();
        private static Dictionary<string, List<string>> _styleFiles = new Dictionary<string, List<string>>();
        
        // 背景图片路径缓存
        private static string _textureBasePath = "";
        
        /// <summary>
        /// 初始化背景纹理管理器，检测所有可用的背景套装
        /// </summary>
        public static void Initialize()
        {
            try
            {
                // 获取纹理基础路径
                _textureBasePath = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) ?? ".";
                _textureBasePath = Path.Combine(_textureBasePath, "texture");
                
                Log.DebugMsg($"BackgroundTextureManager: 初始化，纹理路径: {_textureBasePath}");
                
                // 清除缓存
                _detectedStyles.Clear();
                _styleFiles.Clear();
                
                // 检测6扇区和8扇区的背景套装
                DetectStylesForSectorCount(6);
                DetectStylesForSectorCount(8);
                
                Log.DebugMsg($"BackgroundTextureManager: 检测完成，6扇区套装: {_detectedStyles[6]?.Count ?? 0}个，8扇区套装: {_detectedStyles[8]?.Count ?? 0}个");
            }
            catch (Exception ex)
            {
                Log.Error("BackgroundTextureManager 初始化失败", ex);
            }
        }
        
        /// <summary>
        /// 检测指定扇区数量的可用背景套装
        /// </summary>
        /// <param name="sectorCount">扇区数量（6或8）</param>
        private static void DetectStylesForSectorCount(int sectorCount)
        {
            try
            {
                string sectorDir = Path.Combine(_textureBasePath, $"{sectorCount}sectors");
                
                if (!Directory.Exists(sectorDir))
                {
                    Log.DebugMsg($"BackgroundTextureManager: 目录不存在 {sectorDir}");
                    _detectedStyles[sectorCount] = new List<string>();
                    return;
                }
                
                // 获取所有PNG文件
                var allFiles = Directory.GetFiles(sectorDir, "*.png")
                    .Select(Path.GetFileNameWithoutExtension)
                    .ToList();
                
                // 提取套装标识符（A、B、C等）
                var styleIdentifiers = allFiles
                    .Where(name => name.Length >= 2 && char.IsLetter(name[0]) && char.IsDigit(name[1]))
                    .Select(name => name[0].ToString().ToUpper())
                    .Distinct()
                    .ToList();
                
                // 验证每个套装的完整性
                var validStyles = new List<string>();
                foreach (var style in styleIdentifiers)
                {
                    if (IsStyleComplete(sectorCount, style, allFiles))
                    {
                        validStyles.Add(style);
                        CacheStyleFiles(sectorCount, style, sectorDir);
                    }
                    else
                    {
                        Log.DebugMsg($"BackgroundTextureManager: 套装 {style} 不完整，已跳过");
                    }
                }
                
                _detectedStyles[sectorCount] = validStyles;
                
                Log.DebugMsg($"BackgroundTextureManager: {sectorCount}扇区检测到 {validStyles.Count} 个有效套装: {string.Join(", ", validStyles)}");
            }
            catch (Exception ex)
            {
                Log.Error($"BackgroundTextureManager: 检测{sectorCount}扇区套装失败", ex);
                _detectedStyles[sectorCount] = new List<string>();
            }
        }
        
        /// <summary>
        /// 检查指定套装是否完整（包含所有必需的文件）
        /// </summary>
        /// <param name="sectorCount">扇区数量</param>
        /// <param name="style">套装标识符</param>
        /// <param name="allFiles">所有文件名列表</param>
        /// <returns>是否完整</returns>
        private static bool IsStyleComplete(int sectorCount, string style, List<string> allFiles)
        {
            try
            {
                // 检查背景文件
                string backgroundFile = $"{style}{sectorCount}background";
                if (!allFiles.Any(name => name.Equals(backgroundFile, StringComparison.OrdinalIgnoreCase)))
                {
                    Log.DebugMsg($"BackgroundTextureManager: 缺少背景文件 {backgroundFile}");
                    return false;
                }
                
                // 检查所有扇区文件
                for (int i = 0; i < sectorCount; i++)
                {
                    string sectorFile = $"{style}{sectorCount}sector{i}";
                    if (!allFiles.Any(name => name.Equals(sectorFile, StringComparison.OrdinalIgnoreCase)))
                    {
                        Log.DebugMsg($"BackgroundTextureManager: 缺少扇区文件 {sectorFile}");
                        return false;
                    }
                }
                
                return true;
            }
            catch (Exception ex)
            {
                Log.Error($"BackgroundTextureManager: 检查套装{style}完整性失败", ex);
                return false;
            }
        }
        
        /// <summary>
        /// 缓存套装文件路径
        /// </summary>
        /// <param name="sectorCount">扇区数量</param>
        /// <param name="style">套装标识符</param>
        /// <param name="sectorDir">扇区目录</param>
        private static void CacheStyleFiles(int sectorCount, string style, string sectorDir)
        {
            try
            {
                var files = new List<string>();
                
                // 添加背景文件
                string backgroundFile = $"{style}{sectorCount}background.png";
                string backgroundPath = Path.Combine(sectorDir, backgroundFile);
                if (File.Exists(backgroundPath))
                {
                    files.Add(backgroundPath);
                }
                
                // 添加所有扇区文件
                for (int i = 0; i < sectorCount; i++)
                {
                    string sectorFile = $"{style}{sectorCount}sector{i}.png";
                    string sectorPath = Path.Combine(sectorDir, sectorFile);
                    if (File.Exists(sectorPath))
                    {
                        files.Add(sectorPath);
                    }
                }
                
                string cacheKey = $"{sectorCount}_{style}";
                _styleFiles[cacheKey] = files;
                
                Log.DebugMsg($"BackgroundTextureManager: 缓存套装 {cacheKey}，共 {files.Count} 个文件");
            }
            catch (Exception ex)
            {
                Log.Error($"BackgroundTextureManager: 缓存套装{style}文件失败", ex);
            }
        }
        
        /// <summary>
        /// 获取指定扇区数量的可用套装列表
        /// </summary>
        /// <param name="sectorCount">扇区数量</param>
        /// <returns>套装标识符列表</returns>
        public static List<string> GetAvailableStyles(int sectorCount)
        {
            if (_detectedStyles.ContainsKey(sectorCount))
            {
                return new List<string>(_detectedStyles[sectorCount]);
            }
            return new List<string>();
        }
        
        /// <summary>
        /// 获取指定套装的背景文件路径
        /// </summary>
        /// <param name="sectorCount">扇区数量</param>
        /// <param name="style">套装标识符</param>
        /// <returns>背景文件路径，如果不存在则返回null</returns>
        public static string GetBackgroundPath(int sectorCount, string style)
        {
            string cacheKey = $"{sectorCount}_{style}";
            if (_styleFiles.ContainsKey(cacheKey) && _styleFiles[cacheKey].Count > 0)
            {
                return _styleFiles[cacheKey][0]; // 第一个文件是背景
            }
            return null;
        }
        
        /// <summary>
        /// 获取指定套装的所有扇区文件路径
        /// </summary>
        /// <param name="sectorCount">扇区数量</param>
        /// <param name="style">套装标识符</param>
        /// <returns>扇区文件路径列表</returns>
        public static List<string> GetSectorPaths(int sectorCount, string style)
        {
            string cacheKey = $"{sectorCount}_{style}";
            if (_styleFiles.ContainsKey(cacheKey) && _styleFiles[cacheKey].Count > 1)
            {
                // 跳过第一个文件（背景），返回其余的扇区文件
                return _styleFiles[cacheKey].Skip(1).ToList();
            }
            return new List<string>();
        }
        
        /// <summary>
        /// 检查指定套装是否可用
        /// </summary>
        /// <param name="sectorCount">扇区数量</param>
        /// <param name="style">套装标识符</param>
        /// <returns>是否可用</returns>
        public static bool IsStyleAvailable(int sectorCount, string style)
        {
            return GetAvailableStyles(sectorCount).Contains(style);
        }
        
        /// <summary>
        /// 获取默认套装（第一个可用的套装）
        /// </summary>
        /// <param name="sectorCount">扇区数量</param>
        /// <returns>默认套装标识符，如果没有可用套装则返回"A"</returns>
        public static string GetDefaultStyle(int sectorCount)
        {
            var styles = GetAvailableStyles(sectorCount);
            return styles.Count > 0 ? styles[0] : "A";
        }
    }
}