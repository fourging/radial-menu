using System;
using System.Collections.Generic;
using System.Linq;

namespace RadialMenu.Logic
{
    /// <summary>
    /// 食物数据管理类
    /// 负责存储和管理所有食物数据，提供通过TypeID查询的方法
    /// </summary>
    public static class FoodDataManager
    {
        /// <summary>
        /// 食物数据字典，以TypeID为键
        /// </summary>
        private static readonly Dictionary<int, FoodData> _foodDataDict;

        /// <summary>
        /// 静态构造函数，初始化食物数据
        /// </summary>
        static FoodDataManager()
        {
            _foodDataDict = new Dictionary<int, FoodData>();
            InitializeFoodData();
        }

        /// <summary>
        /// 初始化食物数据，将数据硬编码到字典中
        /// </summary>
        private static void InitializeFoodData()
        {
            // 从食物数据.txt中读取的数据
            var foodDataList = new List<FoodData>
            {
                new FoodData("焗豆罐头", 40, 0, 12),
                new FoodData("油浸金枪鱼罐头", 45, -20, 19),
                new FoodData("水浸金枪鱼罐头", 35, -10, 18),
                new FoodData("巧克力", 55, -10, 68),
                new FoodData("可乐", 30, 35, 14),
                new FoodData("苏打饼干", 15, -5, 13),
                new FoodData("红条香烟", 0, 0, 22),
                new FoodData("能量棒", 75, -15, 69),
                new FoodData("蜂蜜", 100, -60, 70),
                new FoodData("番茄酱", 45, -20, 71),
                new FoodData("鸭蛋", 35, 0, 84),
                new FoodData("可可奶", 20, 25, 105),
                new FoodData("苏打水", 0, 40, 106),
                new FoodData("水壶", 0, 50, 107),
                new FoodData("蛋糕", 45, -10, 132),
                new FoodData("酸奶", 40, 20, 115),
                new FoodData("胡萝卜", 20, 10, 133),
                new FoodData("土豆", 40, 0, 403),
                new FoodData("瓶装水", 0, 50, 428),
                new FoodData("饺子", 40, 0, 449),
                new FoodData("蛋白粉", 100, -30, 883),
                new FoodData("苹果", 5, 10, 888),
                new FoodData("伏特加", 10, -50, 29),
                new FoodData("蘑菇", 15, 5, 878),
                new FoodData("自制糖果", 5, -3, 1180),
                new FoodData("棒棒糖", 5, -3, 1181),
                new FoodData("灵魂私酒", 50, -100, 1256),
                new FoodData("威士忌", 10, -60, 108)
            };

            // 将数据添加到字典中
            foreach (var foodData in foodDataList)
            {
                _foodDataDict[foodData.TypeID] = foodData;
            }
        }

        /// <summary>
        /// 通过TypeID获取食物数据
        /// </summary>
        /// <param name="typeID">食物类型ID</param>
        /// <returns>食物数据，如果不存在则返回null</returns>
        public static FoodData? GetFoodData(int typeID)
        {
            _foodDataDict.TryGetValue(typeID, out var foodData);
            return foodData;
        }

        /// <summary>
        /// 通过TypeID获取食物的能量值
        /// </summary>
        /// <param name="typeID">食物类型ID</param>
        /// <returns>能量值，如果不存在则返回0</returns>
        public static int GetFoodEnergy(int typeID)
        {
            var foodData = GetFoodData(typeID);
            return foodData?.Energy ?? 0;
        }

        /// <summary>
        /// 通过TypeID获取食物的水分值
        /// </summary>
        /// <param name="typeID">食物类型ID</param>
        /// <returns>水分值，如果不存在则返回0</returns>
        public static int GetFoodWater(int typeID)
        {
            var foodData = GetFoodData(typeID);
            return foodData?.Water ?? 0;
        }

        /// <summary>
        /// 检查是否存在指定TypeID的食物数据
        /// </summary>
        /// <param name="typeID">食物类型ID</param>
        /// <returns>如果存在返回true，否则返回false</returns>
        public static bool ContainsFoodData(int typeID)
        {
            return _foodDataDict.ContainsKey(typeID);
        }

        /// <summary>
        /// 获取所有食物数据
        /// </summary>
        /// <returns>所有食物数据的集合</returns>
        public static IEnumerable<FoodData> GetAllFoodData()
        {
            return _foodDataDict.Values.ToList();
        }
    }
}