using System;

namespace RadialMenu.Logic
{
    /// <summary>
    /// 食物数据模型类
    /// 存储食物的基本信息，包括显示名称、能量值、水分值和类型ID
    /// </summary>
    public class FoodData
    {
        /// <summary>
        /// 食物显示名称
        /// </summary>
        public string DisplayName { get; set; } = string.Empty;

        /// <summary>
        /// 能量值
        /// </summary>
        public int Energy { get; set; }

        /// <summary>
        /// 水分值
        /// </summary>
        public int Water { get; set; }

        /// <summary>
        /// 类型ID
        /// </summary>
        public int TypeID { get; set; }

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="displayName">显示名称</param>
        /// <param name="energy">能量值</param>
        /// <param name="water">水分值</param>
        /// <param name="typeID">类型ID</param>
        public FoodData(string displayName, int energy, int water, int typeID)
        {
            DisplayName = displayName;
            Energy = energy;
            Water = water;
            TypeID = typeID;
        }

        /// <summary>
        /// 默认构造函数
        /// </summary>
        public FoodData()
        {
        }
    }
}