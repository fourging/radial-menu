using System;
using System.Collections.Generic;
using System.Linq;
using ItemStatsSystem;
using Duckov.UI;



namespace RadialMenu.Logic;
/// <summary>
/// 检查物品是否为投掷爆炸物，食物，药品。
/// </summary>
public static class ItemTypeChecker
{
    /// <summary>
    /// 检查物品是否为投掷爆炸物
    /// </summary>
    public static bool IsExplosive(Item item)
    {
        // 记录进入方法的调试信息
        Log.DebugMsg("ItemTypeChecker.IsExplosive - 开始检查物品是否为投掷爆炸物");
        bool result = item.Tags.Contains("Explosive");
        Log.DebugMsg($"ItemTypeChecker.IsExplosive - 检查完成，结果: {result} (物品标签包含Explosive: {result})");
        return result;
    }

    /// <summary>
    /// 检查物品是否为药品
    /// </summary>
    public static bool IsMedicine(Item item)
    {
        Log.DebugMsg("ItemTypeChecker.IsMedicine - 开始检查物品是否为药品");
        bool result = item.Tags.Contains("Medic");
        Log.DebugMsg($"ItemTypeChecker.IsExplosive - 检查完成，结果: {result} (物品标签包含Explosive: {result})");
        return result;
    }

    /// <summary>
    /// 检查物品是否为食物
    /// </summary>
    public static bool IsFood(Item item)
    {
        // 记录进入方法的调试信息
        Log.DebugMsg("ItemTypeChecker.IsFood - 开始检查物品是否为食物");
        bool result = item.Tags.Contains("Food");
        Log.DebugMsg($"ItemTypeChecker.IsExplosive - 检查完成，结果: {result} (物品标签包含Explosive: {result})");
        return result;
    }
}

/// <summary>
/// 获取玩家背包中的物品
/// </summary>
public static class InventoryHelper
{
    /// <summary>
    /// 获取玩家与宠物的 Inventory 数据
    /// </summary>
    /// <returns>包含玩家和宠物背包 Inventory 的元组，如果失败则返回 null</returns>
    private static (Inventory playerInventory, Inventory petInventory)? GetPlayerAndPetInventories()
    {
        try
        {
            var main = CharacterMainControl.Main;
            if (main?.CharacterItem == null)
            {
                Log.Warn("CharacterMainControl.Main 或 CharacterItem 为 null");
                return null;
            }

            var playerInv = main.CharacterItem.Inventory;
            var petInv = PetProxy.PetInventory;

            return (playerInv, petInv);
        }
        catch (Exception ex)
        {
            Log.Error("获取玩家与宠物背包失败", ex);
            return null;
        }
    }

    /// <summary>
    /// 获取玩家与宠物的所有物品（包括背包中的嵌套物品）
    /// </summary>
    public static List<Item> GetPlayerAndPetItems()
    {
        var data = GetPlayerAndPetInventories();
        if (data == null)
        {
            Log.DebugMsg("获取不到背包数据，返回空物品列表");
            return new List<Item>();
        }

        var (playerInv, petInv) = data.Value;
        var allItems = new List<Item>();

        if (playerInv != null)
            allItems.AddRange(playerInv.Content);

        if (petInv != null)
            allItems.AddRange(petInv.Content);

        Log.DebugMsg($"初始获取玩家物品数: {playerInv?.Content?.Count ?? 0}, 宠物物品数: {petInv?.Content?.Count ?? 0}");

        // 递归展开所有嵌套物品
        var result = new List<Item>();
        var visited = new HashSet<Item>();
        foreach (var item in allItems)
        {
            result.AddRange(GetAllNestedItems(item, visited));
        }

        Log.Info($"成功获取所有物品（含嵌套），总数量: {result.Count}");
        return result;
    }

    /// <summary>
    /// 递归获取物品内部的所有嵌套物品（例如背包里的背包）
    /// </summary>
    private static List<Item> GetAllNestedItems(Item item, HashSet<Item>? visited = null)
    {
        if (item == null)
        {
            Log.DebugMsg("尝试处理空物品，返回空列表");
            return new List<Item>();
        }

        visited ??= new HashSet<Item>();

        if (visited.Contains(item))
        {
            // 输出调试日志，提示循环引用（但不中断流程）
            Log.DebugMsg($"检测到循环引用物品: {item.DisplayName}，已跳过");
            return new List<Item>();
        }

        visited.Add(item);

        var result = new List<Item> { item };

        try
        {
            // 处理物品自带的Inventory中的嵌套物品
            if (item.Inventory != null)
            {
                //Log.DebugMsg($"解析物品[{item.DisplayName}]的Inventory，包含{item.Count}个子物品");
                foreach (var nested in item.Inventory)
                {
                    if (nested != null)
                        result.AddRange(GetAllNestedItems(nested, visited));
                }
            }

            // 处理物品插槽中的嵌套物品
            if (item.Slots != null)
            {
                Log.DebugMsg($"解析物品[{item.DisplayName}]的Slots，包含{item.Slots.Count}个插槽");
                foreach (var slot in item.Slots)
                {
                    if (slot?.Content != null)
                        result.AddRange(GetAllNestedItems(slot.Content, visited));
                }
            }
        }
        catch (Exception ex)
        {
            // 使用Log模块输出错误日志，包含物品名称和异常信息
            Log.Error($"递归解析物品失败: {item.DisplayName}", ex);
        }

        return result;
    }
}


/// <summary>
/// 尝试输出当前选中物品的信息
/// </summary>
public static class ItemInspectHelper
{
    /// <summary>
    /// 尝试输出当前选中物品的信息
    /// </summary>
    public static void TryInspectSelectedItem()
    {
        // 确认界面是 LootView（物品界面）
        if (View.ActiveView is not LootView)
        {
            Log.DebugMsg("[ItemInspect] 当前界面不是 LootView，忽略操作。");
            return;
        }

        // 获取当前选中物品
        var item = ItemUIUtilities.SelectedItem;
        if (item == null)
        {
            Log.DebugMsg("[ItemInspect] 当前没有选中物品。");
            return;
        }

        try
        {
            Log.Info("=== 物品信息 ===");
            Log.Info($"名称: {item.DisplayName}");

            // 尝试读取通用字段
            var id = item.GetString("Id", "未知");
            var count = item.GetInt("Count", 1);
            var weight = item.GetFloat("Weight", 0f);
            var stackable = item.GetBool("IsStackable", false);

            Log.Info($"ID: {id}");
            Log.Info($"数量: {count}");
            Log.Info($"重量: {weight}");
            Log.Info($"是否可堆叠: {stackable}");

            // 标签信息
            var tags = item.Tags != null
                ? string.Join(", ", item.Tags.Select(t => t.ToString()))
                : "无";
            Log.Info($"标签: {tags}");

            // 检查嵌套物品
            var subCount = item.Inventory?.Content?.Count ?? 0;
            if (subCount > 0)
                Log.Info($"包含子物品数: {subCount}");
            else
                Log.DebugMsg("无子物品。");

            // 占位逻辑：这里可以放你长按 Q 的绑定调用
            Log.DebugMsg("[ItemInspect] 这里可以触发长按 Q 圆盘逻辑");
        }
        catch (Exception ex)
        {
            Log.Error("[ItemInspect] 输出物品信息失败", ex);
        }
    }
}


    /// <summary>
/// 物品计数模块（ItemCounter）
/// 负责根据物品的显示名或 TypeID 统计玩家与宠物当前持有的总数量（包含堆叠）
/// </summary>
public static class ItemCounter
{
    /// <summary>
    /// 统计指定 displayName 的物品数量（含堆叠数量）
    /// </summary>
    public static int CountItemsByDisplayName(string displayName)
    {
        if (string.IsNullOrEmpty(displayName))
        {
            Log.Warn("CountItemsByDisplayName 调用时传入了空的 displayName");
            return 0;
        }

        try
        {
            var allItems = InventoryHelper.GetPlayerAndPetItems();

            if (allItems == null || allItems.Count == 0)
            {
                Log.DebugMsg("未从背包中获取到任何物品，计数结果为 0");
                return 0;
            }

            Log.DebugMsg($"开始统计物品：{displayName}，当前背包物品总数: {allItems.Count}");

            int total = 0;
            int matchCount = 0;

            foreach (var item in allItems)
            {
                if (item == null) continue;

                if (string.Equals(item.DisplayName, displayName, StringComparison.OrdinalIgnoreCase))
                {
                    int count = Math.Max(item.StackCount, 1);
                    total += count;
                    matchCount++;
                    Log.DebugMsg($"匹配物品 [{item.DisplayName}]，堆叠数={item.StackCount}，当前累计={total}");
                }
            }

            Log.Info($"物品 [{displayName}] 计数完成，匹配到 {matchCount} 个条目，总数量={total}");
            return total;
        }
        catch (Exception ex)
        {
            Log.Error($"统计物品 [{displayName}] 数量时出错", ex);
            return 0;
        }
    }

    /// <summary>
    /// 统计指定 TypeID 的物品数量（含堆叠数量）
    /// </summary>
    /// <param name="typeId">要统计的物品 TypeID</param>
    /// <returns>总数量（含堆叠）</returns>
    public static int CountItemsByTypeID(int typeId)
    {
        if (typeId <= 0)
        {
            Log.Warn($"CountItemsByTypeID 调用时传入了非法的 typeId: {typeId}");
            return 0;
        }

        try
        {
            var allItems = InventoryHelper.GetPlayerAndPetItems();

            if (allItems == null || allItems.Count == 0)
            {
                Log.DebugMsg("未从背包中获取到任何物品，计数结果为 0");
                return 0;
            }

            Log.DebugMsg($"开始统计 TypeID={typeId} 的物品，当前背包物品总数: {allItems.Count}");

            int total = 0;
            int matchCount = 0;

            foreach (var item in allItems)
            {
                if (item == null) continue;

                if (item.TypeID == typeId)
                {
                    int count = Math.Max(item.StackCount, 1);
                    total += count;
                    matchCount++;

                    Log.DebugMsg($"匹配物品 TypeID={item.TypeID}, 名称=[{item.DisplayName}]，堆叠数={item.StackCount}，当前累计={total}");
                }
            }

            Log.Info($"TypeID={typeId} 的物品计数完成，匹配到 {matchCount} 个条目，总数量={total}");
            return total;
        }
        catch (Exception ex)
        {
            Log.Error($"统计 TypeID={typeId} 的物品数量时出错", ex);
            return 0;
        }
    }

        /// <summary>
    /// 统计指定Tags的物品数量（含堆叠数量）
    /// </summary>
    /// <param name="targetTags">要统计的物品 TypeID</param>
    /// <returns>总数量（含堆叠）</returns>
    public static int CountItemsByTags(string targetTags)
    {
        if (targetTags == null)
        {
            Log.Warn($"CountItemsBytargetTags 调用时未传入 targetTags");
            return 0;
        }

        try
        {
            var allItems = InventoryHelper.GetPlayerAndPetItems();

            if (allItems == null || allItems.Count == 0)
            {
                Log.DebugMsg("未从背包中获取到任何物品，计数结果为 0");
                return 0;
            }

            Log.DebugMsg($"开始统计 Tags包含{targetTags} 的物品，当前背包物品总数: {allItems.Count}");

            int total = 0;
            int matchCount = 0;

            foreach (var item in allItems)
            {
                if (item == null) continue;

                if (item.Tags.Contains(targetTags))
                {
                    int count = Math.Max(item.StackCount, 1);
                    total += count;
                    matchCount++;

                    Log.DebugMsg($"匹配物品 Tags = {targetTags}, 名称=[{item.DisplayName}]，堆叠数={item.StackCount}，当前累计={total}");
                }
            }

            Log.Info($"Tags = {targetTags} 的物品计数完成，匹配到 {matchCount} 个条目，总数量={total}");
            return total;
        }
        catch (Exception ex)
        {
            Log.Error($"统计 Tags = {targetTags} 的物品数量时出错", ex);
            return 0;
        }
    }

}


