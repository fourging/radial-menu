using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using ItemStatsSystem;
using RadialMenu.UI;
using RadialMenu.ConfigAndAPI;
using RadialMenu.Patches;

namespace RadialMenu.Logic
{
    /// <summary>
    /// 管理和执行玩家使用物品的统一逻辑,先检测是什么类型的物品，再执行对应的使用逻辑
    /// </summary>
    public static class ItemUseController
    {
        /// <summary>
        /// 使用指定物品
        /// </summary>
        public static bool UseItem(Item item)
        {
            var character = CharacterMainControl.Main;
            if (item == null)
            {
                Log.Warn("物品为空，无法使用");
                return false;
            }

            if (character == null)
            {
                Log.Warn("角色为空，无法使用物品");
                return false;
            }

            try
            {
                if (ItemTypeChecker.IsMedicine(item))
                    return UseMedicine(item, character);

                if (ItemTypeChecker.IsFood(item))
                    return UseFood(item, character);

                if (ItemTypeChecker.IsExplosive(item))
                {
                    character.ChangeHoldItem(item);
                    Log.Info($"投掷爆炸物：{item.DisplayName}");

                    speakup.ShowRandomDialogue(
                        CharacterMainControl.Main.transform,
                        1f,
                        LocalizationHelper.Get("Use_ExplosionArt"),
                        LocalizationHelper.GetFormatted("Use_EatItem", item.DisplayName),
                        LocalizationHelper.GetFormatted("Use_EquipItem", item.DisplayName)
                    );

                    return true;
                }

                Log.Warn($"物品 {item.DisplayName} 无法使用");
                return false;
            }
            catch (Exception ex)
            {
                Log.Error($"使用物品时发生错误：{ex.Message}", ex);
                return false;
            }
        }

        /// <summary>
        /// 使用药品逻辑
        /// </summary>
        private static bool UseMedicine(Item item, CharacterMainControl character)
        {
            try
            {
                if (item.UsageUtilities != null && item.UsageUtilities.IsUsable(item, character))
                {
                    if (item.DisplayName.Contains("急救箱"))
                    {
                        IEnumerable itemsRaw = InventoryHelper.GetPlayerAndPetItems();
                        if (itemsRaw == null) return false;

                        var allItems = new List<Item>();
                        foreach (var entry in itemsRaw)
                        {
                            try { ExtractItemsFromEntry(entry, allItems); } catch { }
                        }

                        var candidates = allItems
                            .Where(i => i != null && string.Equals(i.DisplayName, item.DisplayName, StringComparison.Ordinal))
                            .ToList();

                        Item toUse = null!;
                        if (candidates.Count > 0)
                        {
                            Log.DebugMsg($"候选急救箱Durability列表：{string.Join(", ", candidates.Select(i => i.Durability.ToString()))}");
                            
                            // 获取配置的忽略耐久度阈值
                            float ignoreDurabilityThreshold = RadialMenuSetting.IgnoreDurabilityValue;
                            Log.DebugMsg($"忽略耐久度阈值：{ignoreDurabilityThreshold}");
                            
                            // 先获取所有可用的急救箱
                            var usableCandidates = candidates
                                .Where(i => i.UsageUtilities != null && i.UsageUtilities.IsUsable(i, character))
                                .ToList();
                            
                            // 过滤掉耐久度低于阈值的急救箱
                            var filteredCandidates = usableCandidates
                                .Where(i => i.Durability >= ignoreDurabilityThreshold)
                                .OrderBy(i => i.Durability)
                                .ToList();
                            
                            // 如果有符合耐久度要求的急救箱，选择耐久度最低的那个
                            if (filteredCandidates.Count > 0)
                            {
                                toUse = filteredCandidates.First();
                                Log.DebugMsg($"选择符合耐久度要求的急救箱：{toUse.DisplayName}（Durability={toUse.Durability}）");
                            }
                            // 如果所有急救箱都低于阈值，选择耐久度最高的那个
                            else if (usableCandidates.Count > 0)
                            {
                                toUse = usableCandidates.OrderByDescending(i => i.Durability).First();
                                Log.DebugMsg($"所有急救箱都低于阈值，选择耐久度最高的：{toUse.DisplayName}（Durability={toUse.Durability}）");
                            }
                            // 如果没有可用的急救箱，回退到原始逻辑
                            else
                            {
                                toUse = candidates.OrderBy(i => i.Durability).FirstOrDefault();
                                Log.DebugMsg($"没有可用的急救箱，回退到原始逻辑：{toUse?.DisplayName}（Durability={toUse?.Durability}）");
                            }
                        }

                        toUse ??= item;

                        character.UseItem(toUse);
                        speakup.ShowRandomDialogue(
                            character.transform,
                            delay: 0f,
                            LocalizationHelper.GetFormatted("Use_UseItem", toUse.DisplayName),
                            LocalizationHelper.Get("Use_HealthRecovered"),
                            LocalizationHelper.Get("Use_Ouch")
                        );
                        if (toUse.TypeID == 15)
                        {
                            float remainingAttempts = toUse.Durability/ 40;
                            if (remainingAttempts == 0)
                                {
                                    speakup.ShowDialogue(LocalizationHelper.Get("Use_ReplaceAfterUse"));
                                }
                            else
                                {
                                    float healthRecovery = remainingAttempts * 35;
                                    speakup.ShowDialogue(LocalizationHelper.GetFormatted("Use_HealthRemaining", healthRecovery), delay:1f);
                                    // speakup.ShowDialogue($"还能用{remainingAttempts}次,共{healthRecovery}血量");
                                }
                        }
                        else if (toUse.TypeID == 16)
                        {
                            float remainingAttempts = toUse.Durability / 25;
                            if (remainingAttempts == 0)
                                {
                                    speakup.ShowDialogue(LocalizationHelper.Get("Use_ReplaceAfterUse"));
                                }
                            else
                                {
                                    float healthRecovery = remainingAttempts * 20;
                                    // speakup.ShowDialogue($"还能用{remainingAttempts}次,共{healthRecovery}血量");
                                    speakup.ShowDialogue(LocalizationHelper.GetFormatted("Use_HealthRemaining", healthRecovery), delay:1f);
                                }
                        }
                        else if (toUse.TypeID == 17)
                        {
                            float remainingAttempts = toUse.Durability / 25;
                                if (remainingAttempts == 0)
                                {
                                    speakup.ShowDialogue(LocalizationHelper.Get("Use_ReplaceAfterUse"));
                                }
                            else
                                {                            
                                    float healthRecovery = remainingAttempts * 12;
                                    // speakup.ShowDialogue($"还能用{remainingAttempts}次,共{healthRecovery}血量");
                                    speakup.ShowDialogue(LocalizationHelper.GetFormatted("Use_HealthRemaining", healthRecovery), delay:1f);
                                }
                        }
                        Log.Info($"使用急救箱：{toUse.DisplayName}（Durability={toUse.Durability}）");
                    }
                    else
                    {
                        character.UseItem(item);
                        speakup.ShowDialogue(LocalizationHelper.GetFormatted("Use_UseItem", item.DisplayName + "ing"), character.transform, 2f, delay: 1f);
                        Log.Info($"使用药品：{item.DisplayName}");
                    }

                    return true;
                }

                Log.Warn($"药品 {item.DisplayName} 无法使用");
                speakup.ShowDialogue(LocalizationHelper.Get("Use_HealthFull"), character.transform, 2f);
                return false;
            }
            catch (Exception ex)
            {
                Log.Error($"使用药品时出错：{ex.Message}", ex);
                return false;
            }
        }

        /// <summary>
        /// 使用食物逻辑
        /// </summary>
        private static bool UseFood(Item item, CharacterMainControl character)
        {
            try
            {
                if (item.UsageUtilities != null && item.UsageUtilities.IsUsable(item, character))
                {
                    character.UseItem(item);

                    if (item.Tags.Contains("Food"))
                    {
                        speakup.ShowRandomDialogue(
                            character.transform,
                            1f,
                            LocalizationHelper.GetFormatted("Use_EatItem", item.DisplayName),
                            LocalizationHelper.GetFormatted("Use_FoodTasty", item.DisplayName),
                            LocalizationHelper.GetFormatted("Use_TasteItem", item.DisplayName),
                            LocalizationHelper.Get("Use_SoFragrant")
                        );
                    }
                    else if (item.DisplayName.Contains("可乐"))
                    {
                        speakup.ShowRandomDialogue(
                            character.transform,
                            1f,
                            "“呲”！糟糕，可乐溢出来了！",
                            "吨吨吨吨吨……",
                            $"偷偷尝一口 {item.DisplayName}～",
                            "可乐一开，烦恼拜拜。"
                        );
                    }
                    else if (item.DisplayName.Contains("酒"))
                    {
                        speakup.ShowRandomDialogue(
                            character.transform,
                            1f,
                            LocalizationHelper.Get("Use_Cheers"),
                            LocalizationHelper.Get("Use_DrinkFirst"),
                            LocalizationHelper.Get("Use_DrinkForgetWorries")
                        );
                    }
                    else if (item.TypeID == 939)
                    {
                        speakup.ShowRandomDialogue(
                        CharacterMainControl.Main.transform,
                        0f,
                        LocalizationHelper.Get("Use_DontEatDuckPoop"),
                        LocalizationHelper.Get("Use_AutoBindBurger"),
                        LocalizationHelper.Get("Use_IsThisPoop"),
                        LocalizationHelper.GetFormatted("Use_FoundPoop", item.DisplayName)
                    );
                    }

                    else
                    {
                        speakup.ShowDialogue(LocalizationHelper.GetFormatted("Use_DrinkItem", item.DisplayName), character.transform, 2f, delay: 1f);
                    }

                    Log.Info($"食用了食物：{item.DisplayName}");
                    return true;
                }

                Log.Warn($"食物 {item.DisplayName} 无法使用");
                return false;
            }
            catch (Exception ex)
            {
                Log.Error($"使用食物时出错：{ex.Message}", ex);
                return false;
            }
        }

        /// <summary>
        /// 安全提取物品（递归）
        /// </summary>
        public static void ExtractItemsFromEntry(object entry, List<Item> collector)
        {
            if (entry == null) return;

            if (entry is Item item)
            {
                if (!collector.Contains(item))
                    collector.Add(item);

                try
                {
                    foreach (var i in GetAllNestedItemsSafe(item))
                    {
                        if (i != null && !collector.Contains(i))
                            collector.Add(i);
                    }
                }
                catch { }
                return;
            }

            if (entry is IEnumerable enumerable && !(entry is string))
            {
                foreach (var e in enumerable)
                {
                    try { ExtractItemsFromEntry(e, collector); } catch { }
                }
                return;
            }

            var t = entry.GetType();
            PropertyInfo? prop = t.GetProperty("Item") ?? t.GetProperty("item") ?? t.GetProperty("Value");
            if (prop != null)
            {
                try
                {
                    var v = prop.GetValue(entry);
                    ExtractItemsFromEntry(v, collector);
                    return;
                }
                catch { }
            }

            FieldInfo? fld = t.GetField("Item") ?? t.GetField("item") ?? t.GetField("Item1") ?? t.GetField("Value");
            if (fld != null)
            {
                try
                {
                    var v = fld.GetValue(entry);
                    ExtractItemsFromEntry(v, collector);
                    return;
                }
                catch { }
            }

            foreach (var p in t.GetProperties(BindingFlags.Public | BindingFlags.Instance))
            {
                if (typeof(Item).IsAssignableFrom(p.PropertyType))
                {
                    try
                    {
                        var v = p.GetValue(entry) as Item;
                        if (v != null) { ExtractItemsFromEntry(v, collector); return; }
                    }
                    catch { }
                }
                else if (typeof(IEnumerable).IsAssignableFrom(p.PropertyType) && p.PropertyType != typeof(string))
                {
                    try
                    {
                        var v = p.GetValue(entry) as IEnumerable;
                        if (v != null) { ExtractItemsFromEntry(v, collector); return; }
                    }
                    catch { }
                }
            }

            foreach (var f in t.GetFields(BindingFlags.Public | BindingFlags.Instance))
            {
                if (typeof(Item).IsAssignableFrom(f.FieldType))
                {
                    try
                    {
                        var v = f.GetValue(entry) as Item;
                        if (v != null) { ExtractItemsFromEntry(v, collector); return; }
                    }
                    catch { }
                }
                else if (typeof(IEnumerable).IsAssignableFrom(f.FieldType) && f.FieldType != typeof(string))
                {
                    try
                    {
                        var v = f.GetValue(entry) as IEnumerable;
                        if (v != null) { ExtractItemsFromEntry(v, collector); return; }
                    }
                    catch { }
                }
            }
        }

        private static IEnumerable<Item> GetAllNestedItemsSafe(Item parent)
        {
            yield return parent;
        }
    }
}