using UnityEngine;
using RadialMenu.Logic.Utils;

namespace RadialMenu.Logic.Utils
{
    /// <summary>
    /// UIHelper使用示例类
    /// 展示如何在项目中调用关闭物品详情页面的方法
    /// </summary>
    public static class UIHelperExample
    {
        /// <summary>
        /// 示例：在特定条件下关闭物品详情页面
        /// 比如在打开径向菜单时自动关闭物品详情页面
        /// </summary>
        public static void CloseItemDetailsOnRadialMenuOpen()
        {
            // 检查是否存在活跃的物品详情页面
            if (UIHelper.HasActiveItemDetailsWindow())
            {
                Log.Info("检测到活跃的物品详情页面，正在关闭...");
                
                // 关闭所有物品详情页面
                int closedCount = UIHelper.CloseAllItemDetailsWindows();
                
                if (closedCount > 0)
                {
                    Log.Info($"已自动关闭 {closedCount} 个物品详情页面，以便显示径向菜单");
                }
            }
        }
        
        /// <summary>
        /// 示例：在特定按键组合下关闭物品详情页面
        /// 比如按ESC键时关闭物品详情页面
        /// </summary>
        public static void HandleEscapeKey()
        {
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                // 尝试关闭物品详情页面
                int closedCount = UIHelper.CloseAllItemDetailsWindows();
                
                if (closedCount > 0)
                {
                    Log.Info($"通过ESC键关闭了 {closedCount} 个物品详情页面");
                }
            }
        }
        
        /// <summary>
        /// 示例：在游戏暂停时关闭物品详情页面
        /// </summary>
        public static void CloseItemDetailsOnPause()
        {
            if (GameManager.Paused)
            {
                int closedCount = UIHelper.CloseAllItemDetailsWindows();
                
                if (closedCount > 0)
                {
                    Log.Info($"游戏暂停时自动关闭了 {closedCount} 个物品详情页面");
                }
            }
        }
    }
}