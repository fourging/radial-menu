# UIHelper 使用说明

## 概述

`UIHelper` 是一个静态工具类，提供了与UI相关的实用方法，主要用于处理游戏中的物品详情页面。

## 主要方法

### CloseAllItemDetailsWindows()

关闭所有活跃的物品详情页面。

**返回值：**
- `int`: 成功关闭的窗口数量，如果没有找到窗口则返回0

**使用示例：**
```csharp
using RadialMenu.Logic.Utils;

// 直接调用关闭所有物品详情页面
int closedCount = UIHelper.CloseAllItemDetailsWindows();
Log.Info($"关闭了 {closedCount} 个物品详情页面");
```

### HasActiveItemDetailsWindow()

检查是否存在活跃的物品详情页面。

**返回值：**
- `bool`: 如果存在活跃的物品详情页面则返回true，否则返回false

**使用示例：**
```csharp
using RadialMenu.Logic.Utils;

// 检查是否有活跃的物品详情页面
if (UIHelper.HasActiveItemDetailsWindow())
{
    Log.Info("检测到活跃的物品详情页面");
    // 执行相关逻辑
}
```

## 实际应用场景

### 1. 在打开径向菜单时自动关闭物品详情页面

在 `RadialInputHandler.cs` 中已经集成了这个功能：

```csharp
// 在打开径向菜单前自动关闭物品详情页面
UIHelper.CloseAllItemDetailsWindows();
```

### 2. 在绑定物品到扇区时自动关闭物品详情页面

在 `BindingManager.cs` 和 `RadialMenu.Bindings.cs` 中都集成了这个功能：

```csharp
// 在绑定物品时关闭物品详情页面
int closedCount = UIHelper.CloseAllItemDetailsWindows();
if (closedCount > 0)
{
    Log.Info($"绑定物品时自动关闭了 {closedCount} 个物品详情页面");
}
```

这样当玩家在背包中选中物品并长按Q触发绑定时，物品详情页面会自动关闭。

### 3. 在游戏暂停时关闭物品详情页面

```csharp
if (GameManager.Paused)
{
    UIHelper.CloseAllItemDetailsWindows();
}
```

### 4. 在特定按键组合下关闭物品详情页面

```csharp
if (Input.GetKeyDown(KeyCode.Escape))
{
    UIHelper.CloseAllItemDetailsWindows();
}
```

## 注意事项

1. 这些方法通过反射查找 `ItemDetailsDisplay` 类型，因此依赖于游戏的原生UI结构
2. 方法内部已经包含了异常处理，不会因为找不到类型或实例而崩溃
3. 所有操作都会通过 `Log` 类记录相应的日志信息
4. 这些方法是线程安全的，可以在任何地方调用

## 扩展

如果需要添加更多UI相关的实用方法，可以直接在 `UIHelper` 类中添加新的静态方法。