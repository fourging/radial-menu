using System;
using System.Linq;
using UnityEngine;
using Duckov.UI;
using Duckov.Modding;

namespace RadialMenu.Logic.Utils
{
    /// <summary>
    /// UI辅助工具类，提供各种UI相关的实用方法
    /// </summary>
    public static class UIHelper
    {
        /// <summary>
        /// 关闭所有物品详情页面
        /// 通过反射查找ItemDetailsDisplay类型并关闭所有实例
        /// </summary>
        /// <returns>成功关闭的窗口数量，如果没有找到窗口则返回0</returns>
        public static int CloseAllItemDetailsWindows()
        {
            int closedCount = 0;
            
            try
            {
                // 查找ItemDetailsDisplay类型
                var itemDetailsType = typeof(Duckov.UI.ItemUIUtilities).Assembly.GetTypes()
                    .FirstOrDefault(t => t.Name == "ItemDetailsDisplay");
                
                if (itemDetailsType != null)
                {
                    // 查找所有ItemDetailsDisplay实例
                    var instances = UnityEngine.Object.FindObjectsOfType(itemDetailsType);
                    
                    if (instances.Length > 0)
                    {
                        foreach (var instance in instances)
                        {
                            if (instance is Component component)
                            {
                                component.gameObject.SetActive(false);
                                closedCount++;
                                Log.Info($"已关闭物品详情窗口: {component.gameObject.name}");
                            }
                        }
                        
                        Log.Info($"成功关闭了 {closedCount} 个物品详情窗口");
                    }
                    else
                    {
                        Log.DebugMsg("未找到ItemDetailsDisplay实例，没有需要关闭的窗口");
                    }
                }
                else
                {
                    Log.Warn("未找到ItemDetailsDisplay类型");
                }
            }
            catch (Exception ex)
            {
                Log.Error("关闭物品详情窗口时发生错误", ex);
            }
            
            return closedCount;
        }
        
        /// <summary>
        /// 检查是否存在活跃的物品详情页面
        /// </summary>
        /// <returns>如果存在活跃的物品详情页面则返回true，否则返回false</returns>
        public static bool HasActiveItemDetailsWindow()
        {
            try
            {
                // 查找ItemDetailsDisplay类型
                var itemDetailsType = typeof(Duckov.UI.ItemUIUtilities).Assembly.GetTypes()
                    .FirstOrDefault(t => t.Name == "ItemDetailsDisplay");
                
                if (itemDetailsType != null)
                {
                    // 查找所有ItemDetailsDisplay实例
                    var instances = UnityEngine.Object.FindObjectsOfType(itemDetailsType);
                    
                    // 检查是否有活跃的实例
                    foreach (var instance in instances)
                    {
                        if (instance is Component component && component.gameObject.activeInHierarchy)
                        {
                            return true;
                        }
                    }
                }
                
                return false;
            }
            catch (Exception ex)
            {
                Log.Error("检查物品详情窗口状态时发生错误", ex);
                return false;
            }
        }
    }
}